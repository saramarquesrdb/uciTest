<h1>Hipotecas product icons</h1>
<h3>To change the product icon, modify the class:</h3>
<p>icon--seguro_pagos</p>
<p>icon--seguro_vida</p>
<p>icon--seguro_generico</p>
<p>icon--hipoteca_reunificaciondeudas</p>
<p>icon--hipoteca_compradecasa</p>
<p>icon--hipoteca_casasobreplano</p>
<p>icon--hipoteca_casamasreforma</p>
<p>icon--hipoteca_cambiocasa</p>
<h1>UCI product icons</h1>
<h3>To change the product icon, modify the class:</h3>
<p>icon--default-seguro_pagos</p>
<p>icon--default-seguro_vida</p>
<p>icon--default-seguro_generico</p>
<p>icon--default-hipoteca_reunificaciondeudas</p>
<p>icon--default-hipoteca_compradecasa</p>
<p>icon--default-hipoteca_casasobreplano</p>
<p>icon--default-hipoteca_casamasreforma</p>
<p>icon--default-hipoteca_cambiocasa</p>