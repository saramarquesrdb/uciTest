import stepsNav from './steps/init';
import initRequiredFields from './fields/required';
import formSubmitPreloader from '../../Common/formSubmitPreloader';
import googleIdUtmContent from './fields/googleIdUtmContent';
import consentimientos from './fields/consentimientos';

const initSitecoreForms = () => {
  document.querySelectorAll('form[action^="/formbuilder"]').forEach(form => {
    stepsNav(form);
    googleIdUtmContent(form);
    //initRequiredFields(form);

    const validators = [
      consentimientos(form, 'email-primer-titular',    'email-segundo-titular',    'messageErrorEmailEqual'),
      consentimientos(form, 'telefono-primer-titular', 'telefono-segundo-titular', 'messageErrorPhoneEqual'),
    ];


    form.addEventListener('submit', e => {
      const allOk = validators.every(v => v());
      if (!allOk) {
        e.preventDefault();
        e.stopImmediatePropagation();
        return;
      }


      // Si todo OK, muestra el preloader y sigue con el submit
      formSubmitPreloader(form, '.form-wrapper', [
        'body',
        '.header',
        '.splitter_header-before',
      ]);
    });
  });
};

export default initSitecoreForms;
