import getClosestElement from "@/js/Helpers/getClosestElement";

export class Steps {
    constructor(form, navigation) {
        this.form = form;
        this.navigation = navigation;
        this.layout = navigation.element.getAttribute('data-layout');
        this.init();
    }

    init() {
        this.initContainers();
        this.initEventListeners();
    }

    // Creates a container for every step and moves the appropriate inputs inside
    initContainers() {
        // Creates a wrapper for the steps
        const wrapper = document.createElement('div');
        wrapper.className = "steps-wrapper columns-form";
        this.form.appendChild(wrapper);

        // Set the step for recaptcha text
        const recaptchaText = this.form.querySelector('.legal.recaptcha');
        if (recaptchaText) {
            recaptchaText.dataset.step = this.navigation.stepsCount;
        }

        // For each step
        for (let i = 1; i <= this.navigation.stepsCount; i++) {
            // Moves the input fields into the container (creates the container if it's not created yet)
            const fields = this.form.querySelectorAll(`[data-step="${i}"]`);
            fields.forEach(element => {

                const stepClassName = `step-${i}`;
                let stepContainer = this.form.querySelector(`.${stepClassName}`);

                if (!stepContainer) {
                    const container = document.createElement('div');
                    container.classList.add(stepClassName);
                    container.classList.add('row')
                    container.style.display = 'none';
                    container.dataset.ctrStep = i;
                    wrapper.appendChild(container);
                    stepContainer = container;
                }


                const parent = element.closest('[class*="col-sm-"]')
                const regex = /col-sm-(\d+)/;
                const match = parent.className.match(regex);

                const column = document.createElement('div');
                column.className = `col-xs-12 col-sm-${match[1]}`
                column.appendChild(element);

                for (const attr of parent.attributes) {
                    if (attr.name.startsWith('data-')) {
                        column.setAttribute(attr.name, attr.value);
                    }
                }

                wrapper.querySelector(`.${stepClassName}`).appendChild(column);
                stepContainer.classList.add('columns-form-list') // for the error messages to work
            });

            // PREV - NEXT - SUBMIT buttons
            //
            // 1. Creates the wrapper for the buttons
            const inStepNav = document.createElement('div');
            inStepNav.className = 'steps-nav__in-step';

            // 2. Creates the previous button when needed
            let prev = null;
            if (this.layout == 'button') {
                prev = document.createElement('button');
                prev.className = 'btn';
                const label = this.navigation.element.getAttribute('data-prev')
                prev.innerHTML = label; // comes from sitecore in a data
                if (!label) {
                    prev.style.display = 'none';
                }
                prev.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.navigation.goTo(i - 1);
                });
            }

            // 3. Creates the next button
            const next = document.createElement('button');
            next.className = this.layout == 'button' ? 'btn' : 'btn btn_secondary';
            next.innerHTML = this.navigation.element.getAttribute('data-next'); // comes from sitecore in a data
            next.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.layout == 'text') {
                    if (!this.reviewStepValidation(i, true)) {
                        return;
                    }
                }

                this.navigation.goTo(i + 1);
            });

            // 4. Finds the original submit button and attaches step validation proccess to it 
            const submit = this.form.querySelector('[type="submit"]');
            if (submit) {
                submit.innerHTML = this.navigation.element.getAttribute('data-submit'); // comes from sitecore in a data
                submit.addEventListener('click', (e) => {
                    let valid = true;
                    for (let j = 1; j <= this.navigation.stepsCount; j++) {
                        if (!this.reviewStepValidation(j, true, true)) {
                            valid = false;
                        }
                    }

                    if (!valid) {
                        e.preventDefault();
                    }
                })
            }

            // Finally buttons are added (or not) to the step
            // if not in the first step previus button is added
            if (i > 1 && prev) inStepNav.appendChild(prev);
            // if not in the last step next button is added
            if (i < this.navigation.stepsCount) inStepNav.appendChild(next);
            // if it's the last step submig button is added
            if (i == this.navigation.stepsCount) inStepNav.appendChild(submit);

            // Appends the buttons wrapper into the step
            this.form.querySelector(`.step-${i}`).appendChild(inStepNav);
        }

        // Mueve el div preloader al contenedor wrapper
        wrapper.appendChild(this.form.querySelector('.preloader'));

    }

    initEventListeners() {
        // When the step changes, shows the appropriate container and validates previous steps (forzed)
        this.form.addEventListener('step-changed', (e) => {
            this.form.querySelectorAll('div[class^="step-"]').forEach(ctr => {
                ctr.style.display = 'none';
            });

            this.form.querySelector('div.step-' + e.detail.step).style.display = 'flex';

            for (let i = 1; i < e.detail.step; i++) {
                this.reviewStepValidation(i, true, false);
            }
        });

        // When field value changes inside an step, triggers validation for that step (no forze)
        this.form.querySelectorAll('[data-step] input').forEach((input) => {
            input.addEventListener('change', (event) => {
                const step = getClosestElement(event.target, 'div[class^="step-"]').getAttribute('data-ctr-step');
                this.reviewStepValidation(step);
            });
        });
    }

    // Reviews Validation of an step, 3 possible results:
    //    - valid = true      -> This means every validable input in the step is VALID
    //    - valid = undefined -> This means some inputs haven't been changed by the user yet
    //    - valid = false     -> This means at least one input in the step is invalid
    //
    // Forze: when true, undefined state is not possible and empty fields are treated as left empty
    // 
    // Finally triggers an event for the navigation component to update buttons styling
    reviewStepValidation(step, force, submit) {
        let valid = false;
        const inputs = Array.from(this.form.querySelectorAll(`.step-${step} input[data-val="true"]`));

        if (force) {
            // Manually triggers jquery validate for inputs in the step
            const validator = $(this.form).validate();
            inputs.forEach(input => {
                if (input.disabled) {
                    input.classList.remove('input-validation-error');
                    input.classList.add('valid');
                    input.setAttribute('aria-invalid', 'false');

                }
                else {
                    if (input.classList.contains('millions')) {
                        // Guarda el valor original con puntos
                        var originalValue = input.value;

                        // Remueve los puntos temporalmente para la validación
                        input.value = input.value.replace(/\./g, '');

                        // Valida el input
                        validator.element(input);

                        // Restaurar el valor original con puntos después de la validación, solo si no es submit
                        if (!submit) {
                            input.value = originalValue;
                        }
                    } else {
                        // Si no tiene la clase 'millions', validar directamente
                        validator.element(input);
                    }

                }
            });
        }

        if (inputs
            .map((input) => { return input.getAttribute("aria-invalid") })
            .every(x => x == 'false')) {
            valid = true;
        }
        else if (!force && !inputs
            .map((input) => { return input.getAttribute("aria-invalid") })
            .some(x => x == 'true')) {
            valid = undefined;
        }
        else {
            valid = false;
        }

        this.form.dispatchEvent(new CustomEvent('step-validation', { detail: { step, valid } }));

        return valid;
    }
}