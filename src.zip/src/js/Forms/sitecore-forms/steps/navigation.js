import getClosestElement from "@/js/Helpers/getClosestElement";

export class Navigation {
    constructor(form) {
        this.form = form;
        this.element = form.querySelector('.steps-nav__list');
        this.buttons = this.element.querySelectorAll('li');
        this.stepsCount = this.buttons.length;
        this.layout = this.element.getAttribute('data-layout');
        this.stickyElement = this.layout == 'text' ? window.stickyService.addElement(this.element, { ignoreHeader: true }) : null;

        if (this.element) {
            this.element.style.display = 'block';
            this.init(form);
            this.initialized = true;
        }
    }

    init(form) {
        // Takes navigation element outside the non-step form and hides it
        const formWrapper = form.querySelector('.form-wrapper');
        form.insertBefore(this.element, formWrapper);
        formWrapper.style.display = 'none';

        // Initializes navigation buttons with texts and events
        for (let i = 1; i <= this.buttons.length; i++) {
            let button = this.buttons[i - 1];
            button.setAttribute('data-btn-step', i);
            button.querySelector('.sequence').innerHTML = this.layout == 'button'
                ? String(i).padStart(2, '0')
                : `${i}/${this.stepsCount}`;
            if (this.layout == 'button') {
                button.addEventListener('click', (e) => {
                    this.goTo(getClosestElement(e.target, 'li').getAttribute('data-btn-step'))
                });
            }
        }

        // Updates buttons' styling when fields in the steps are validated (or not)
        if (this.layout == 'button') {
            this.form.addEventListener('step-validation', (e) => {
                const btn = this.buttons[e.detail.step - 1];
                const icon = btn.querySelector('use');
                btn.classList.remove('success', 'reject')
                if (e.detail.valid == true) {
                    btn.classList.add('success')
                    icon.setAttribute("xlink:href", icon.getAttribute("xlink:href").replace("close", "check"))
                }
                if (e.detail.valid == false) {
                    btn.classList.add('reject')
                    icon.setAttribute("xlink:href", icon.getAttribute("xlink:href").replace("check", "close"))
                }
            });
        }

        // Adds the event listeners for the back buttons
        if (this.layout == 'text') {
            this.element.querySelectorAll('.steps-nav__list-item').forEach((el, index) => {
                const step = parseInt(el.getAttribute('data-btn-step'))
                const button = el.querySelector('.link_back')
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.goTo(step - 1);
                });
            });
        }

        // Initializes the breadcrum element
        //this.breadcrumb = new Breadcrumbs(this.element, this.stepsCount);       

        this.stickyElement?.element.addEventListener('StickyElement.Refresh', (e) => {
            this.element.style.top = `${e.detail.offset}px`;
        });
    }

    // Triggers navigation update when step changes and dispatches 
    // an event for the steps component to show appropriate fields
    goTo(step) {
        this.buttons.forEach(button => {
            button.classList.remove('active')
        });

        var btn = Array.from(this.buttons)[step - 1];
        btn.classList.add('active');
        this.form.dispatchEvent(new CustomEvent('step-changed', { detail: { step, label: btn.querySelector('.text').innerText } }));
    }
}

export class Breadcrumbs {
    constructor(nav, lastStep) {
        this.el = nav.querySelector('.steps-nav__breadcrumb');
        this.currentStep = nav.querySelector('.current-step');
        this.finalStep = nav.querySelector('.final-step');
        this.stepLabel = nav.querySelector('.step-label');

        this.init(lastStep);
    }

    init(lastStep) {
        this.finalStep.innerHTML = lastStep;
        this.form.addEventListener('step-changed', (e) => {
            this.update(e.detail);
        });
    }

    update(stepInfo) {
        this.currentStep.innerHTML = stepInfo.step;
        this.stepLabel.innerHTML = stepInfo.label;
    }
}