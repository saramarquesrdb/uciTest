import { Navigation } from './navigation';
import { Steps } from './steps';
import ComponentService from "../../../services/components.service";

const stepsNav = (form) => {
    const scope = form.querySelector('.steps-nav__list')?.dataset.scope;
    if (!scope) return;
    if (scope == "Phone" && window.matchMedia('(min-width: 1024px)').matches) return;

    // Navigation initialization
    const navigation = new Navigation(form);
    if (!navigation.initialized) return;

    // Steps initialization
    const component = new Steps(form, navigation);

    // Set first step on load
    navigation.goTo(1);

    ComponentService.addComponent(component);
}

export default stepsNav;