/**
 * Evita que dos campos tengan el mismo valor y muestra el mismo mensaje en ambos.
 *
 * @returns {Function} validateDistinct() → true si los valores son distintos.
 */
const consentimientos = (form, classA, classB, messageClass) => {
  const getInputByCss = (root, cssClass) => {
    const direct = root.querySelector(`input.${cssClass}`);
    if (direct) return direct;
    const wrapper = root.querySelector(`.${cssClass}`);
    return wrapper ? wrapper.querySelector('input') : null;
  };
  
  const inputA = getInputByCss(form, classA);
  const inputB = getInputByCss(form, classB);
  if (!inputA || !inputB) return () => true;

  // Mensaje traducido
  const msgNode = form.querySelector(`input.${messageClass}`);
  const errorMessage = msgNode?.value?.trim() || 'Los campos no pueden tener el mismo valor.';

  const toggleError = (input, show, message = 'Los campos no pueden tener el mismo valor.') => {
    const formFieldset =
      input.closest('.form-fieldset') || input.closest('.form-list__field');
    if (!formFieldset) return;
  
    const errorSpan = formFieldset.querySelector('.error-message');
    if (!errorSpan) return;
  
    if (show) {
      /* ─── Mostrar error de igualdad ─── */
      input.classList.add('input-validation-error', 'input-validation-error-equality');
      input.classList.remove('valid');
  
      errorSpan.textContent = message;
      errorSpan.style.display = 'inline';
      errorSpan.dataset.equality = '1';          // ← marca “soy mensaje de igualdad”
  
      formFieldset.classList.add('has-error');
      input.setAttribute('aria-invalid', 'true');
    } else {
      /* ─── Ocultar nuestro error ─── */
      input.classList.remove('input-validation-error-equality');
  
      // ¿El <span> fue puesto por esta validación?
      const isOurError = errorSpan.dataset.equality === '1';
  
      if (!isOurError) {
        // El mensaje pertenece a otra regla (required, regex…). No tocar.
        return;
      }
  
      // Limpia la marca: a partir de aquí sabemos que el mensaje era nuestro
      delete errorSpan.dataset.equality;
  
      const stillInvalid = !input.checkValidity(); // Navegador + jQuery validations
  
      if (stillInvalid) {
        // Mantén la clase genérica para que jQuery/HTML5 lo sigan mostrando
        input.classList.add('input-validation-error');
        input.classList.remove('valid', 'input-validation-valid');
        formFieldset.classList.add('has-error');
        input.setAttribute('aria-invalid', 'true');
      } else {
        // El campo está completamente válido → limpia todo
        input.classList.remove('input-validation-error');
        input.classList.add('valid');
  
        errorSpan.textContent = '';
        errorSpan.style.display = 'none';
  
        formFieldset.classList.remove('has-error');
        input.setAttribute('aria-invalid', 'false');
      }
    }
  };
  

  /** Comprueba ambos valores y actualiza los dos campos */
  const validateDistinct = () => {
    const valA = inputA.value.trim().toLowerCase();
    const valB = inputB.value.trim().toLowerCase();
  
    // ───── Falta al menos uno → limpia SOLO tu clase y deja el resto intacto
    if (valA === '' || valB === '') {
      inputA.classList.remove('input-validation-error-equality');
      inputB.classList.remove('input-validation-error-equality');
      return true; // dejamos que jQuery Validation trabaje (required, regex, etc.)
    }
  
    // ───── Ambos rellenos → comprueba si son idénticos
    const duplicated = valA === valB;
    toggleError(inputA, duplicated, errorMessage);
    toggleError(inputB, duplicated, errorMessage);
  
    return !duplicated;
  };

  /* ——— listeners ——— */
// Por claridad, usar const/let coherentes en los listeners:
['input', 'change', 'blur'].forEach(evt => {
  [inputA, inputB].forEach(el => el.addEventListener(evt, validateDistinct));
});
  // Devuelve la función para usarla en el submit externo
  return validateDistinct;
};

export default consentimientos;
