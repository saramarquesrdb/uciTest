const initRequiredFields = (form) => {

    // Initial setup to mark mandatory fields
    form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(field => {
        if (field.hasAttribute('data-val') && field.hasAttribute('data-val-required')) {
            field.setAttribute('data-initial-required', 'true');
        }
    });

    // Function to update the required status and clear values of hidden fields
    const updateMandatoryStatus = () => {
        form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(field => {
            if (field.getAttribute('data-initial-required') === 'true') {
                if (field.offsetParent !== null) { // Check if the field is visible
                    field.setAttribute('data-val', 'true'); // Enable jQuery validation
                    field.setAttribute('data-val-required', 'This field is required.'); // Add required validation message
                } else {
                    field.removeAttribute('data-val'); // Disable jQuery validation
                    field.removeAttribute('data-val-required'); // Remove required validation message
                    // Clear the value of the field if hidden
                    if (field.tagName.toLowerCase() === 'select') {
                        field.selectedIndex = -1; // Clear selection for select elements
                    } else {
                        field.value = ''; // Clear value for input and textarea elements
                    }
                }
            }
        });
    };

    // Call the function on page load
    updateMandatoryStatus();

    // Monitor changes in the DOM to detect visibility changes
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                updateMandatoryStatus();
            }
        });
    });

    // Observe each form field
    form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(field => {
        observer.observe(field, { attributes: true });
    });

    // Optionally, monitor changes to the entire form to detect dynamic changes
    observer.observe(form, { childList: true, subtree: true });
}

export default initRequiredFields;