const googleIdUtmContent = (form) => {
 // Obtenemos el valor de 'co' desde la cookie '_ga'
 const co = document.cookie.match(/_ga=(.+?)(;|$)/) 
 ? document.cookie.match(/_ga=(.+?)(;|$)/)[1].split('.').slice(-2).join(".") 
 : "Incognito";

// Seleccionamos el input con la clase 'GoIdForLandings' dentro del formulario
const input = form.querySelector('.GoIdForLandings');
const inputIdMorgage = form.querySelector('.gIdMortgage');

// Verificamos que el input exista antes de asignarle el valor
if (input) {
 input.value = window.location + "{#}" + co;
} 
if(inputIdMorgage)
{ 
    inputIdMorgage.value = window.location + "{#}" + co;
}
 
}

export default googleIdUtmContent;
