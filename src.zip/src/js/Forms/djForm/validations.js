const validations = {
  // Common regex
  htmlElements: {
    nameRegex: /^\s*([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]{1,}([.,] |[-']| )?)+[A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]+\.?\s*$/,
    emailRegex: /^[-a-z0-9~!$%^&*_=+}{'?]+(\.[-a-z0-9~!$%^&*_=+}{'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i,
    phoneRegex: /^[0-9 ()+-]{9,12}$/
  },

  // Dropdowns / Selector
  selectorsValidate(selectorsRequired) {
    selectorsRequired.forEach(selector => {
      if (selector.querySelector('input').value === '') {
        selector.classList.add('error');
      }
    });
  },


  textInputValidate(fieldsToValidate) {
    fieldsToValidate.forEach(input => {
      if (input.value === '') {
        input.closest('.required').classList.add('error');
      } else if (input.type === 'email' && !validations.htmlElements.emailRegex.test(input.value)) {
        input.closest('.required').classList.add('error');
      } else if (input.classList.contains('input-distinguisher_phone-number')) {
        if (input.value.length < 11) {
          input.closest('.required').classList.add('error');
        } else {
          input.closest('.required').classList.remove('error');
        }
      } else if (input.type === 'text' && !validations.htmlElements.nameRegex.test(input.value)) {
        input.closest('.required').classList.add('error');
      } else {
        input.closest('.required').classList.remove('error');
      }
    });
  },

  textInputValidateOnBlur(fieldsToValidate) {
    fieldsToValidate.forEach(input => {
      input.addEventListener('blur', () => {
        validations.textInputValidate(fieldsToValidate);
      });
    });
  }


};

export default validations;
