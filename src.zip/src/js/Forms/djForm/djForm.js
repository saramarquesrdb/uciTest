import IMask from 'imask';
import { fadeIn } from '@/js/Helpers/fade';
import stepsValidation from '@/js/Forms/djForm/helpers';
import { assignmentRequiredRegex, isFieldRequired } from '@/js/Common/formsFunctions';
import getClosestElement from '@/js/Helpers/getClosestElement';
import steps from './steps';

const applicationFormDJ = form => {
  // Get key elements
  const formStep1 = form.querySelector('.application-form__step-1');
  const formStep2 = form.querySelector('.application-form__step-2');
  const continueBtnStep1 = formStep1.querySelector('.form-btn__continue  button.btn');
  const cancelBtnStep1 = formStep1.querySelector('.cancel-btn .form-btn__submit a.btn');
  const btnValidateStep2 = formStep2.querySelector('.form-btn__submit button');
  const backButtonStep2 = formStep2.querySelector('.form-btn__submit a');
  const stepHeader1 = document.querySelector('.steps-header__steps-item:first-of-type');
  const stepHeader2 = document.querySelector('.steps-header__steps-item:last-of-type');

  const dataCollectionContent = document.querySelector('.data-collection_content.lightbox_content');
  const lightboxTrigger = document.querySelector('.lightbox.data-collection .lightbox__trigger');

  // Prevent pointer events
  dataCollectionContent.closest('.lightbox__overlay').style.pointerEvents = 'none';

  // Open lightbox on "cancel" button
  cancelBtnStep1.addEventListener('click', () => {
    lightboxTrigger.click();
  });

  // Go Back Button
  if (backButtonStep2) {
    backButtonStep2.addEventListener('click', () => {
      stepsValidation(formStep2, formStep1, false);
      stepHeader2.classList.remove('active');
      stepHeader1.classList.add('active');
    });
  }


  // Lightbox feedback
  const lightboxContent = document.querySelector('.data-collection_content.lightbox_content');
  const feedbackBtn = lightboxContent.querySelector('.form-btn .form-btn__submit ');
  const feedbackTxt = lightboxContent.querySelector('.lightbox__title .feedback');
  const lightboxOverlay = document.querySelector('.lightbox.data-collection .lightbox__overlay');

  lightboxContent.querySelector('.lightbox__content-main').classList.remove('dis-none');
  lightboxContent.querySelector('.lightbox__title h2.title-l').classList.remove('dis-none');
  lightboxContent.querySelector('.lightbox__title .feedback').classList.add('dis-none');
  lightboxContent.querySelector('.lightbox__title .feedback').style.marginBottom = '0';
  lightboxOverlay.querySelector('.lightbox__close').style.display = 'none';

  feedbackBtn.addEventListener('click', () => {
    lightboxContent.querySelector('.lightbox__content-main').classList.add('dis-none');
    lightboxContent.querySelector('.lightbox__title h2.title-l').classList.add('dis-none');
    lightboxContent.querySelector('.lightbox__title .feedback').classList.remove('dis-none');
    lightboxContent.querySelector('.lightbox__title .feedback').style.marginBottom = '50px';
    lightboxOverlay.querySelector('.lightbox__close').style.display = 'block';
    lightboxOverlay.querySelector('.lightbox__close').style.pointerEvents = 'initial';
  });


  // Close lightbox on Continue button
  const lightboxBtnContinue = document.querySelector('.lightbox.data-collection .form-btn__continue');
  if (lightboxBtnContinue) {
    lightboxBtnContinue.addEventListener('click', () => {
      lightboxOverlay.classList.remove('active');
      fadeIn(lightboxOverlay, null, null, 0.1, 10);
      lightboxOverlay.style.display = 'none';
    });
  }

  // Show Address fieldset on radio button click
  const addressFieldset = form.querySelector('li.form-list__item.address');
  const addressRadioYes = form.querySelector('#decidedYes');
  const addressRadioNo = form.querySelector('#decidedNo');

  if (addressRadioNo && addressRadioYes) {
    addressRadioNo.addEventListener('click', () => {
      if (addressRadioNo.checked) {
        addressFieldset.style.display = 'none';
      }
    });
    addressRadioYes.addEventListener('click', () => {
      if (addressRadioYes.checked) {
        addressFieldset.style.display = 'list-item';
      }
    });
  }

  // Set max length in Phone field
  const getFieldset = input => getClosestElement(input, '.form-fieldset');
  const phoneNumberMaskOptions = { mask: '000 000 000 000', };
  const phoneNumberInput = form.querySelector('.input-distinguisher_phone-number');
  const phoneNumberFieldset = getFieldset(phoneNumberInput);
  const isPhoneNumberRequired = isFieldRequired(phoneNumberInput);
  const phoneNumberMinLength = phoneNumberInput ? phoneNumberInput.getAttribute('minlength') : null;
  const phoneNumberRegex = phoneNumberInput ? new RegExp(`^[0-9 ]{${phoneNumberMinLength},}$`) : null;

  if (phoneNumberInput) {
    IMask(phoneNumberInput, phoneNumberMaskOptions);
  }

  // Show dependant persons number selector
  const personsYes = form.querySelector('#employeesYes');
  const personsNo = form.querySelector('#employeesNo');
  const personsNumber = form.querySelector('#employeesNumber');

  if (personsNo && personsYes) {
    personsNo.addEventListener('click', () => {
      if (!personsYes.checked) {
        personsNumber.style.display = '';
      }
    });
    personsYes.addEventListener('click', () => {
      if (personsYes.checked) {
        personsNumber.style.display = 'flex';
      }
    });
  }

  // Set visibility for Holders
  const twoHoldersRadios = Array.from(formStep1.querySelectorAll('#holders input'));
  const twoHoldersFields = Array.from(formStep1.querySelectorAll('.twoHolders'));

  if (formStep1.querySelector('input#oneHolder').checked) {
    formStep1.querySelector('.twoHolders').style.display = 'none';
  }

  twoHoldersRadios.forEach(inputRadio => {
    if (inputRadio.id === 'twoHolders') {
      twoHoldersFields.forEach((field, index) => {
        field.style.display = 'none';
        if (field.querySelector('.form-list__field .form-fieldset')) {
          field.querySelector('.form-list__field').classList.add('required');
        }
      });
    } else {
      twoHoldersFields.forEach(field => {
        field.style.display = 'flex';
      });
    }
  });

  // Toggle visibility & required on Holders
  twoHoldersRadios.forEach(inputRadio => {
    inputRadio.addEventListener('click', e => {
      if (inputRadio.id === 'twoHolders') {
        twoHoldersFields.forEach(field => {
          field.style.display = 'flex';
          field.querySelector('.form-list__field > div').classList.add('required');
        });
      } else {
        twoHoldersFields.forEach(field => {
          field.style.display = 'none';
          field.querySelector('.form-list__field > div').classList.remove('required', 'error');
        });
      }
    });
  });

  steps(form, formStep1, formStep2, continueBtnStep1, btnValidateStep2);
};
export default applicationFormDJ;
