import stepsValidation from '@/js/Forms/djForm/helpers';
import validations from './validations';


const steps = (form, formStep1, formStep2, continueBtnStep1, btnValidateStep2) => {
  // Validate Step 1
  const requiredFieldsformStep1 = Array.from(formStep1.querySelectorAll('.required'));
  const selectorsRequiredFormStep1 = Array.from(formStep1.querySelectorAll('.required  .form-select-distinguisher_selector'));
  const inputNameRequired = Array.from(form.querySelectorAll('.required  .input-distinguisher_name'));
  const inputEmailRequired = Array.from(form.querySelectorAll('.required  .input-distinguisher_email'));
  const inputPhoneRequired = Array.from(form.querySelectorAll('.required  .input-distinguisher_phone-number'));
  const fieldsToValidate = [inputNameRequired[0], inputEmailRequired[0], inputPhoneRequired[0]];
  const stepHeader1 = document.querySelector('.steps-header__steps-item:first-of-type');
  const stepHeader2 = document.querySelector('.steps-header__steps-item:last-of-type');

  /** ********************
     * VALIDATE STEP 1
     * ****************** */

  continueBtnStep1.addEventListener('click', e => {
    e.preventDefault();
    if (requiredFieldsformStep1.length !== 0) {
      // Check required fields

      if (selectorsRequiredFormStep1) {
        validations.selectorsValidate(selectorsRequiredFormStep1);
      }
      if (formStep1.querySelector('input#twoHolders').checked) {
        validations.textInputValidate(fieldsToValidate);
      }

      // Check Error Fields
      const allRequiredFieldsWithErrorsFormStep1 = Array.from(formStep1.querySelectorAll('.required .error'));
      if (allRequiredFieldsWithErrorsFormStep1.length === 0) {
        stepsValidation(formStep1, formStep2);
        stepHeader1.classList.remove('active');
        stepHeader2.classList.add('active');
      }
    }
  });

  /** ********************
     * VALIDATE STEP 2
     * ****************** */
  // Validate Step 2
  const requiredFieldsFormStep2 = Array.from(formStep2.querySelectorAll('.required'));
  let selectorsRequiredFormStep2 = Array.from(formStep2.querySelectorAll('.required  .form-select-distinguisher_selector'));

  // Optional Marriage Status
  const selectMarriageStatus = form.querySelector('.marriage-status');
  const selectFamiliarStatus = form.querySelectorAll('.familiar-status .access-select__item input');

  selectFamiliarStatus.forEach(listItem => {
    listItem.addEventListener('click', () => {
      if (listItem.value === 'Casado') {
        selectMarriageStatus.classList.remove('hidden');
        selectMarriageStatus.querySelector('.form-list__field').classList.add('required');
        selectorsRequiredFormStep2 = Array.from(formStep2.querySelectorAll('.required  .form-select-distinguisher_selector'));
      } else {
        selectMarriageStatus.classList.add('hidden');
        selectMarriageStatus.querySelector('.form-list__field').classList.remove('required');
      }
    });
  });

  btnValidateStep2.addEventListener('click', e => {
    e.preventDefault();
    if (requiredFieldsFormStep2.length !== 0) {
      // Check required fields
      if (selectorsRequiredFormStep2) {
        validations.selectorsValidate(selectorsRequiredFormStep2);
      }

      // Check Error Fields
      const allRequiredFieldsWithErrorsFormStep2 = Array.from(formStep2.querySelectorAll('.required .error'));
      if (allRequiredFieldsWithErrorsFormStep2.length === 0) {
        stepsValidation(formStep2, formStep2);
        form.submit();
      }
    }
  });

  validations.textInputValidateOnBlur(fieldsToValidate);
};

export default steps;
