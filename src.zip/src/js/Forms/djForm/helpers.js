import { fadeIn, fadeOut } from '@/js/Helpers/fade';

const stepsValidation = (step1, step2, reverse) => {
  if (!reverse) {
    fadeOut(step1, fadeIn, step2);
  } else {
    fadeOut(step2, fadeIn, step1);
  }
};
export default stepsValidation;
