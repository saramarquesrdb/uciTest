const siteKey = "6LfdxGEpAAAAABum02S0JnYGSMfKd1fRMBRl1Lyi";

const executeRecaptcha = (form) => {
    if (!window.grecaptcha) {
        console.error("reCAPTCHA no está cargado.");
        return;
    }

    grecaptcha.ready(() => {
        grecaptcha.execute(siteKey, { action: 'submit' }).then((token) => {
            const field = form.querySelector('input[type="hidden"][name*="recaptcha"]');
            if (field) {
                field.value = token;
            }
            console.log("Token de reCAPTCHA generado y asignado.");
        });
    });
};

const initializeForms = () => {
    Array.from(document.querySelectorAll('form:not([data-recaptcha="false"])')).forEach(form => {
        let field = form.querySelector('input[type="hidden"][name*="recaptcha"]');
        if (!field) {
            field = document.createElement('input');
            field.setAttribute('type', 'hidden');
            field.setAttribute('name', 'recaptcha');
            form.appendChild(field);
        }

        form.addEventListener('submit', (event) => {
            event.preventDefault();

            const validationErrors = form.querySelectorAll('[class^="form-"].error, .input.input-validation-error');
            if (validationErrors.length > 0) return;

            executeRecaptcha(form);

            const shouldSubmit = !form.hasAttribute('data-ajax') || form.getAttribute('data-ajax') !== 'true';
            if (shouldSubmit) {
                form.submit();
            }
        });

        var formFields = form.querySelectorAll('input, textarea, select');
        formFields.forEach(function (field) {
            field.addEventListener('change', () => {
                executeRecaptcha(form);
            });
        });
    })
}

const initRecaptcha = () => {
    document.addEventListener("DOMContentLoaded", () => {
        console.log("Inicializando reCAPTCHA...");
        initializeForms();
    });
};

export default initRecaptcha;