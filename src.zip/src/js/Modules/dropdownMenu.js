
import hideOrShow from '../../Helpers/hideOrShow';

const dropdownMenu = () => {
    const close = document.getElementsByClassName('dropdown-menu__list');
    hideOrShow(close, '');
};

export default dropdownMenu;