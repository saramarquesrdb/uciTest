import IcoCalculatorApiClient from "./ICOCalculatorApiClient";


const IcoCalculator = (element) => {

 
    const evaluate = async () => {
 
        try {

            console.log(data);
            // Llamada a la API
            const productsJson = await IcoCalculatorApiClient.calculate(data);

            // Asegúrate de acceder a la propiedad correcta que contiene el array
            products = productsJson.products || []; // Cambia 'products' al nombre correcto

            console.log(products);

                  return true;

        } catch (error) {

            console.error('Error al obtener los productos:', error);
            return false;
        }


    }

       async function ReloadData() {
           
            try {
                console.log("reload data");
                const result = await evaluate();
                if (result) {
                    console.log("results OK");
                } else {
                    console.log("results ERROR");
                }
    
 
    
            } catch (error) {
                console.log("results ERROR");
            }
            finally {
                console.log("finally");
            }
        }
    
        ReloadData();



}

export default IcoCalculator;
