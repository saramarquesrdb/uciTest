class ICOCalculatorApiClient {
    constructor() {
        this.baseURL = `${window.location.origin}/api/sitecore/IcoSimulator`;
    }

    async calculate(request) {
        const url = new URL(`${this.baseURL}/ICOCalculatorResult`);

        return await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(request),
        })
            .then(async (response) => {
                const result = await response.json();
                if (result.errorMessages) { // Checks if the status code is not in the range 200-299
                    throw result;
                }
                //console.table(result);
                console.log(result);
                //console.log("api result" + JSON.stringify(result));
                return result;
            })
            .catch((error) => {
                //console.error('Error:', error);
                throw error;
            });
    }
}

export default new ICOCalculatorApiClient();
