export class Header {
    constructor() {
        this.header = document.querySelector('header');

        if (this.header) {
            this.initBanner();
        }
    }

    initBanner() {
        if (this.header.dataset.banner) {
            const bannerData = JSON.parse(this.header.dataset.banner);
            this.header.removeAttribute('data-banner');

            const alert = {
                id: bannerData.id,
                type: "banner",
                icon: bannerData.icon,
                message: bannerData.text,
                isClosable: true,
                dismissBehavior: bannerData.dismiss || 'reload',
                title: bannerData.title || '',
                state: bannerData.state || 'info',
            };

            window.alertService.showAlert(alert);
        }
    }
}