export const CardStates = {
    REDUCED: 'reduced',
    FULL: 'full'
};

class CardStateManager {
    constructor(element) {
        this.container = element;
        if (!this.container) {
            console.error('Container element is required');
            return;
        }

        const swiperContainer = this.container.querySelector('.swiper-container');
        this.swiper = swiperContainer.swiper;
        this.cards = Array.from(this.container.querySelectorAll('.card-result.scroll'));

        this.cards.forEach(this.setReducedState.bind(this));
        this.initializeCards();
        this.container.style.visibility = 'visible';
    }

    initializeCards() {
        this.cards.forEach(card => {
            const toggleIcons = card.querySelectorAll('.js-toggle-state');
            toggleIcons.forEach(icon => {
                const newIcon = icon.cloneNode(true);
                icon.parentNode.replaceChild(newIcon, icon);
                newIcon.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.handleStateToggle(card);
                });
            });

            const detailLinks = card.querySelectorAll('.js-toggle-detail');
            detailLinks.forEach(link => {
                const newLink = link.cloneNode(true);
                link.parentNode.replaceChild(newLink, link);
                newLink.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.handleDetailToggle();
                });
            });
        });
    }

    setReducedState(card) {
        const reducedElements = card.querySelectorAll('.reduced');
        const fullBlockElements = card.querySelectorAll('.full-block');
        const fullFlexElements = card.querySelectorAll('.full-flex');

        reducedElements.forEach(el => el.style.display = 'block');
        fullBlockElements.forEach(el => el.style.display = 'none');
        fullFlexElements.forEach(el => el.style.display = 'none');
    }

    setCardState(state, targetCard) {
        const reducedElements = targetCard.querySelectorAll('.reduced');
        const fullBlockElements = targetCard.querySelectorAll('.full-block');
        const fullFlexElements = targetCard.querySelectorAll('.full-flex');

        if (state === CardStates.REDUCED) {
            reducedElements.forEach(el => el.style.display = 'block');
            fullBlockElements.forEach(el => el.style.display = 'none');
            fullFlexElements.forEach(el => el.style.display = 'none');
        } else {
            reducedElements.forEach(el => el.style.display = 'none');
            fullBlockElements.forEach(el => el.style.display = 'block');
            fullFlexElements.forEach(el => el.style.display = 'flex');
        }

        if (this.swiper) this.swiper.update();
    }

    handleStateToggle(clickedCard) {
        const reducedElement = clickedCard.querySelector('.reduced');
        const isReduced = window.getComputedStyle(reducedElement).display !== 'none';
        const newState = isReduced ? CardStates.FULL : CardStates.REDUCED;
        this.cards.forEach(card => this.setCardState(newState, card));
    }

    handleDetailToggle() {
        const resultsElement = document.getElementById('results');
        if (resultsElement) resultsElement.scrollIntoView({ behavior: 'smooth' });
    }
}

export default CardStateManager;