const mortgagePaymentSummary = (element) => {

    var elementSummary = element.querySelector("#summary-calculator");;

    if (elementSummary) {

        var ProvinceNameStorage = localStorage.getItem("ProvinceNameStorage");
        var ProvinceIdStorage = localStorage.getItem("ProvinceIdStorage");
        var MortgageHouseStorage = localStorage.getItem("MortgageHouseStorage");
        var MortgageSavingStorage = localStorage.getItem("MortgageSavingStorage");
        var MortgageTermStorage = localStorage.getItem("MortgageTermStorage");
        var PropertyTypeNameStorage = localStorage.getItem("PropertyTypeNameStorage");
        var PropertyTypeStorage = localStorage.getItem("PropertyTypeStorage");
        var PurposeNameStorage = localStorage.getItem("PurposeNameStorage");
        var PurposeStorage = localStorage.getItem("PurposeStorage");
        var MainHolderAgeStorage = localStorage.getItem("MainHolderAgeStorage");
        var Titulares = localStorage.getItem("Titulares");
        var MainHolderInput = localStorage.getItem("MainHolderInput");
        var MainHolderPaymentsNumber = localStorage.getItem("MainHolderPaymentsNumber");
        var SecondaryHolderInput = localStorage.getItem("SecondaryHolderInput");
        var SecondaryPaymentsNumber = localStorage.getItem("SecondaryPaymentsNumber");
        var OtherLoanAmount = localStorage.getItem("OtherLoanAmount");
        var HasOtherLoan = localStorage.getItem("HasOtherLoan");
        var financiacion = localStorage.getItem("financiacion");
        var impuestosGastos = localStorage.getItem("impuestosGastos");
        var JobSituationFirstHolder = localStorage.getItem("JobSituationFirstHolder");
        var JobSituationSecondHolder = localStorage.getItem("JobSituationSecondHolder");
        var MortgageType = localStorage.getItem("MortgageType");


        document.querySelector("#Province").value = ProvinceIdStorage || "";
        document.querySelector("#MortgageHousePrice").value = MortgageHouseStorage || "0";
        document.querySelector("#MortgageSaving").value = MortgageSavingStorage || "0";
        document.querySelector("#MortgageTerm").value = MortgageTermStorage || "30";
        document.querySelector("#PropertyTypeLite").value = PropertyTypeStorage || "NewConstruction";
        document.querySelector("#PurposeLite").value = PurposeStorage || "true";
        document.querySelector("#MainHolderAge").value = MainHolderAgeStorage || "30";
        document.querySelector("#MainHolderInput").value = MainHolderInput || "0";
        document.querySelector("#MainHolderPaymentsNumber").value = MainHolderPaymentsNumber || "14";
        document.querySelector("#SecondaryHolderInput").value = SecondaryHolderInput || "0";
        document.querySelector("#SecondaryPaymentsNumber").value = SecondaryPaymentsNumber || "14";
        document.querySelector("#HasOtherLoan").value = HasOtherLoan || "false";
        if (!HasOtherLoan || HasOtherLoan === "false") {
            document.querySelector("#OtherLoanAmount").value = "0";
        } else {
            document.querySelector("#OtherLoanAmount").value = OtherLoanAmount || "0";
        }
        document.querySelector("#JobSituationFirstHolder").value = JobSituationFirstHolder || "";
        document.querySelector("#JobSituationSecondHolder").value = JobSituationSecondHolder || "";
        document.querySelector("#HasSecondaryHolder").value = (Titulares === '1' ? "False" : "True");
        document.querySelector("#MortgageAmount").value = financiacion || "0";
        document.querySelector("#MortgageType").value = MortgageType || "Mixed";


        // Valor predeterminado para Lite
        document.querySelector("#Lite").value = "True";

        function getDictionaryValue(id) {
            const el = document.getElementById(id);
            return el ? el.value : '';
        }
        
        // Example usage
        const twoHoldersSummary = getDictionaryValue("TwoHoldersSummaryDictionary");
        const oneHolderSummary = getDictionaryValue("OneHoldersSummaryDictionary");
        const yearOld = getDictionaryValue("YearOldDictionary");
        const loanOf = getDictionaryValue("LoanOfDictionary");
        const noActiveLoan = getDictionaryValue("NoActiveLoanDictionary");
        const financing = getDictionaryValue("FinancingDictionary");
        const contribution = getDictionaryValue("ContributionDictionary");
        const expensesAndTaxes = getDictionaryValue("ExpensesAndTaxesDictionary");

        var summary_titulares = (Titulares === '1' ? oneHolderSummary : twoHoldersSummary) + " / " + MainHolderAgeStorage + " " + yearOld + " / " + MainHolderInput + " € " + (Titulares === '2' ? " / " + SecondaryHolderInput + " € " : "") + (HasOtherLoan == "true" ? " / " + loanOf + ": " + OtherLoanAmount + " €" : " / " + noActiveLoan);
        var summary_vivienda = ProvinceNameStorage + " / " + MortgageHouseStorage + " € / " + PurposeNameStorage + " / " + PropertyTypeNameStorage;
        var summary_financiacion = financing + ": " + financiacion + " € / " + contribution + ": " + MortgageSavingStorage + " € / " + expensesAndTaxes +": " + impuestosGastos + " €";

        //Cargar los datos con el valor

        document.querySelector("#resumen_titulares").innerHTML = summary_titulares;
        document.querySelector("#resumen_tipoVivienda").innerHTML = summary_vivienda;
        document.querySelector("#resumen_financiacion").innerHTML = summary_financiacion;
    }

}

export default mortgagePaymentSummary;
