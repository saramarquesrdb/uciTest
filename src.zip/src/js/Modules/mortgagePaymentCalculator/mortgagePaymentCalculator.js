import mortgagePaymentApiClient from "./mortgagePaymentApiClient";
import Swiper from 'swiper';
import formValidator from "@/js/Common/forms/formValidator";
import CardStateManager from './cardStateManager.js';

const mortgagePaymentCalculator = (element) => {
    const form = element.querySelector('form');
    setTimeout(() => {
        //Necesita un timeout para que funcione el access select
        //loadFormData();
    }, 200);
    formValidator(form);

    const isMobile = window.innerWidth <= 1024;
    const results = element.querySelector('#results');
    const resultsMobile = element.querySelector('#results-mobile');
    const mobileStickyNav = element.querySelector('.steps-nav__list.sticky');
    const listItems = mobileStickyNav.querySelectorAll('.steps-nav__list-item');

    let shouldShowMobileResults = false;
    let hasPassedEndPoint = false;

    if (isMobile) {
        const cardManager = new CardStateManager(resultsMobile);

        const checkVisibility = () => {
            const resultsRect = results.getBoundingClientRect();
            const elementRect = element.getBoundingClientRect();
            const aboutYouRect = document.getElementById('about-you').getBoundingClientRect();

            if (resultsRect.top > window.innerHeight) {
                hasPassedEndPoint = false;
            }

            if (!hasPassedEndPoint && elementRect.top < window.innerHeight - 200) {
                shouldShowMobileResults = true;
                resultsMobile.style.opacity = 1;
                resultsMobile.style.visibility = 'visible';
            } else {
                shouldShowMobileResults = false;
                resultsMobile.style.opacity = 0;
                resultsMobile.style.visibility = 'hidden';
            }

            if (elementRect.top < window.innerHeight - 200 && resultsRect.bottom > 130) {
                mobileStickyNav.style.display = 'block';

                // Quitamos la clase active de todos
                listItems.forEach(item => item.classList.remove('active'));

                // Lógica del spy scroll usando la posición de about-you
                if (aboutYouRect.top > mobileStickyNav.offsetHeight + 40) {
                    listItems[0].classList.add('active'); // your-project activo
                } else if (aboutYouRect.bottom < mobileStickyNav.offsetHeight + 40) {
                    listItems[2].classList.add('active'); // results activo
                } else {
                    listItems[1].classList.add('active'); // about-you activo
                }
            } else {
                mobileStickyNav.style.display = 'none';
            }
        };

        const startObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                checkVisibility();
            });
        }, {
            threshold: [0.1]
        });

        const endObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting || (!entry.isIntersecting && entry.boundingClientRect.y < 0)) {
                    hasPassedEndPoint = true;
                    shouldShowMobileResults = false;
                    resultsMobile.style.opacity = 0;
                    resultsMobile.style.visibility = 'hidden';
                }
                checkVisibility();
            });
        }, {
            threshold: 0.1
        });

        window.addEventListener('scroll', checkVisibility);

        startObserver.observe(element);
        endObserver.observe(results);

        resultsMobile.style.visibility = 'hidden';
        mobileStickyNav.style.display = 'none';

        const scrollToElement = (elementId) => {
            const targetElement = document.getElementById(elementId);
            const offset = mobileStickyNav.offsetHeight + 40;
            const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - offset;

            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        };

        // Añadimos los click listeners a cada li
        listItems.forEach((item, index) => {
            item.addEventListener('click', () => {
                let targetId;
                switch (index) {
                    case 0:
                        targetId = 'your-project';
                        break;
                    case 1:
                        targetId = 'about-you';
                        break;
                    case 2:
                        targetId = 'results';
                        break;
                }
                scrollToElement(targetId);
            });
        });
    } else {
        resultsMobile.style.display = 'none';
    }

    // Declaración de variables globales
    let products = null;
    let Mixed5 = null;
    let Mixed10 = null;
    let Mixed7 = null;
    let fixedProducts = null;
    let variable = null;
    let holdersData;

    const housePriceInput = element.querySelector('input[name="house-price"]');
    const savingsInput = element.querySelector('input[name="cuanto-aportas"]');
    const MortgageTermInput = element.querySelector('input[name="mortgage-term"]');
    const radioOneHolder = element.querySelector("#oneHolder");
    const radioTwoHolders = element.querySelector("#twoHolders");
    const firstEmploymentStatusRadios = element.querySelectorAll('input[name="FirstEmploymentStatus"]');
    const secondEmploymentStatusRadios = element.querySelectorAll('input[name="SecondEmploymentStatus"]');
    const monthlyIncomeFirstHolderInput = element.querySelector("#MonthyIncomeFirstHolder");
    const monthlyIncomeSecondHolderInput = element.querySelector("#MonthyIncomeSecondHolder");
    const paymentMonthsRadios = element.querySelectorAll('input[name="numeroPagas1"]');
    const paymentMonthsRadios2 = element.querySelectorAll('input[name="numeroPagas2"]');
    const secondHolderElements = element.querySelectorAll('.secondHolderli');
    const otherLoansPaymentInput = element.querySelector("#OtherLoans");
    const residentRadios = element.querySelectorAll('input[name="residentIb"]');
    const noRadio = element.querySelector("#residentIbNo");
    const usoViviendaContainer = element.querySelector("#usoViviendaContainer");

    //Modificar el evento para uno o dos titulares
    element.querySelectorAll('input[name="Holders number"]').forEach(radio => {
        radio.addEventListener('change', (event) => {
            const selectedValue = event.target.value;
            console.log(`Número de titulares seleccionado: ${selectedValue}`);

            // Aquí puedes añadir lógica personalizada
            // Por ejemplo, mostrar/ocultar campos para el segundo titular
            if (selectedValue === "1") {
                // lógica para un solo titular
                document.querySelector(".HowOldHoldersTwoHolders").style.display = "none";
                document.querySelector(".HowOldHoldersOneHolder").style.display = "flex";
                document.querySelector("#FirstHolderId").style.display = "none";
                // Ocultar todos los elementos .secondHolderli
                secondHolderElements.forEach(element => {
                    element.classList.add('hidden');
                });
            } else if (selectedValue === "2") {
                document.querySelector(".HowOldHoldersTwoHolders").style.display = "flex";
                document.querySelector(".HowOldHoldersOneHolder").style.display = "none";
                document.querySelector("#FirstHolderId").style.display = "block";

                // Mostrar todos los elementos .secondHolderli
                secondHolderElements.forEach(element => {
                    element.classList.remove('hidden');
                });
            }
        });
    });

    // Llamada inicial para configurar el valor según el radio seleccionado por defecto
    createHoldersObject();

    const provinciaRadios = element.querySelectorAll('input[name="where"]');
    let provincia = Array.from(provinciaRadios)
        .find(radio => radio.checked);

    provincia = provincia ? provincia.value : "Andalucia";


    // Asignar el evento change a cada input de radio FirstEmploymentStatus para capturar cambios
    provinciaRadios.forEach(radio => {
        radio.addEventListener("change", async () => {
            provincia = radio.value;
            await ReloadData();
        });
    });

    housePriceInput.addEventListener('change', async () => {
        await ReloadData();
    });

    housePriceInput.addEventListener('blur', async () => {
        await ReloadData();
    });


    savingsInput.addEventListener('change', async () => {
        await ReloadData();
    });

    savingsInput.addEventListener('blur', async () => {
        await ReloadData();
    });

    function Validations() {
        var messageError = "";
        var AgeViable = true;
        var ContributionViable = true;
        var CostToIncomeFixedViable = true;
        var CostToIncomeMixedViable = true;
        var CostToIncomeVariableViable = true;
        var ExceededSavings = true;

        var mortgageTerm = formatNumberInt(MortgageTermInput.value);
        var Age = parseInt(edadInput.value, 10);

        var maxAge = mortgageTerm + Age;

        var _housePriceInput = element.querySelector('input[name="house-price"]');
        var _housePrice = formatNumberInt(_housePriceInput.value);

        var _savingsInput = element.querySelector('input[name="cuanto-aportas"]');
        var _savings = formatNumberInt(_savingsInput.value);

        if (_savings > _housePrice) {
            ExceededSavings = false;
            messageError = "ExceededSavings ";
        }

        if (maxAge > 75) {
            AgeViable = false;
            messageError = "MaxAgeExceed ";
        }
        else {
            AgeViable = true;
            messageError = "";
        }

        //Carga sobre ingresos

        //Fijo
        var costToIncomeRatioToleranceFixed = isNaN(parseFloat(document.querySelector('#costToIncomeRatioTolerance_Fixed').value)) ? 40 : parseFloat(document.querySelector('#costToIncomeRatioTolerance_Fixed').value);
        var costToIncomeFixed = document.querySelector('#CostToIncomeRatio_Fixed').value;


        console.log("Carga sobre ingresos Fijo " + costToIncomeFixed);
        if (costToIncomeFixed > costToIncomeRatioToleranceFixed) {
            CostToIncomeFixedViable = false;
            messageError += "Cost to income Fixed " + costToIncomeFixed + " costToIncomeRatioToleranceFixed " + costToIncomeRatioToleranceFixed;
        }
        else {
            CostToIncomeFixedViable = true;
            messageError += "";
        }

        //Mixed
        var costToIncomeRatioToleranceMixed = isNaN(parseFloat(document.querySelector('#costToIncomeRatioTolerance_Mixed').value)) ? 40 : parseFloat(document.querySelector('#costToIncomeRatioTolerance_Mixed').value);
        var costToIncomeMixed = document.querySelector('#CostToIncomeRatio_Mixed').value;


        console.log("Carga sobre ingresos Mixto " + costToIncomeMixed);
        if (costToIncomeMixed > costToIncomeRatioToleranceMixed) {
            CostToIncomeMixedViable = false;
            messageError += "Cost to income Mixed " + costToIncomeMixed + " costToIncomeRatioToleranceMixed " + costToIncomeRatioToleranceMixed;
        }
        else {
            CostToIncomeMixedViable = true;
            messageError += "";
        }

        //Variable
        var costToIncomeRatioToleranceVariable = isNaN(parseFloat(document.querySelector('#costToIncomeRatioTolerance_Variable').value)) ? 40 : parseFloat(document.querySelector('#costToIncomeRatioTolerance_Variable').value);
        var costToIncomeVariable = document.querySelector('#CostToIncomeRatio_Variable').value;


        console.log("Carga sobre ingresos Variable " + costToIncomeVariable);
        if (costToIncomeVariable > costToIncomeRatioToleranceVariable) {
            CostToIncomeVariableViable = false;
            messageError += "Cost to income Variable " + costToIncomeVariable + " costToIncomeRatioToleranceVariable " + costToIncomeRatioToleranceVariable;
        }
        else {
            CostToIncomeVariableViable = true;
            messageError += "";
        }


        //Contribucion
        const minContributionAllow = document.querySelector("#MinContributionProfile").value;
        const contribution = Math.round(formatNumberInt(savingsInput.value) * 100) / 100;
        const ContributionRateToleranceBelow = document.querySelector("#ContributionRateToleranceBelow").value;

        const ContributionRateToleranceBelowNumber = parseFloat(ContributionRateToleranceBelow);
        const minContributionAllowNumber = parseFloat(minContributionAllow);
        const minContributionAllowWithRate = ContributionRateToleranceBelowNumber && minContributionAllowNumber ? Math.round((minContributionAllowNumber - (minContributionAllowNumber * ContributionRateToleranceBelowNumber) / 100)) : minContributionAllowNumber;

        console.log("minContributionAllowWithRate " + minContributionAllowWithRate);

        if (contribution < minContributionAllowWithRate) {

            ContributionViable = false;
            messageError += "ContributionLow";
        } else {

            ContributionViable = true;
            messageError += "";
        }

        const ErrorMessage_Fixed = document.querySelector("#ErrorMessage_Fixed");
        if (ErrorMessage_Fixed) {
            ErrorMessage_Fixed.innerHTML = messageError;
        }

        const ErrorMessage_Mixed = document.querySelector("#ErrorMessage_Mixed");
        if (ErrorMessage_Mixed) {
            ErrorMessage_Mixed.innerHTML = messageError;
        }

        const ErrorMessage_Variable = document.querySelector("#ErrorMessage_Variable");
        if (ErrorMessage_Variable) {
            ErrorMessage_Variable.innerHTML = messageError;
        }

        const BtnSolicito_Fixed = document.querySelector("#BtnSolicito_Fixed");
        if (BtnSolicito_Fixed) {
            BtnSolicito_Fixed.style.display = "block";

        }

        const BtnSolicito_Mixed = document.querySelector("#BtnSolicito_Mixed");
        if (BtnSolicito_Mixed) {
            BtnSolicito_Mixed.style.display = "block";

        }

        const BtnSolicito_Variable = document.querySelector("#BtnSolicito_Variable");
        if (BtnSolicito_Variable) {
            BtnSolicito_Variable.style.display = "block";

        }


        const validations_Fixed = document.querySelector("#validations_Fixed");
        if (validations_Fixed) {
            document.querySelector('#validations_Fixed').style.display = "none";
        }

        const validations_Mixed = document.querySelector("#validations_Mixed");
        if (validations_Mixed) {
            document.querySelector('#validations_Mixed').style.display = "none";
        }

        const validations_Variable = document.querySelector("#validations_Variable");
        if (validations_Variable) {
            document.querySelector('#validations_Variable').style.display = "none";
        }

        if (!AgeViable) {
            document.querySelector('#validations_Fixed').style.display = "block";
            document.querySelector('#validations_Mixed').style.display = "block";
            document.querySelector('#validations_Variable').style.display = "block";

            document.querySelector('#BtnSolicito_Fixed').style.display = "none";
            document.querySelector('#BtnSolicito_Mixed').style.display = "none";
            document.querySelector('#BtnSolicito_Variable').style.display = "none";

        }
        if (!ContributionViable) {
            document.querySelector('#validations_Fixed').style.display = "block";
            document.querySelector('#validations_Mixed').style.display = "block";
            document.querySelector('#validations_Variable').style.display = "block";

            document.querySelector('#BtnSolicito_Fixed').style.display = "none";
            document.querySelector('#BtnSolicito_Mixed').style.display = "none";
            document.querySelector('#BtnSolicito_Variable').style.display = "none";

        }
        if (!CostToIncomeFixedViable) {
            document.querySelector('#validations_Fixed').style.display = "block";
            document.querySelector('#BtnSolicito_Fixed').style.display = "none";

        }

        if (!CostToIncomeMixedViable) {
            document.querySelector('#validations_Mixed').style.display = "block";
            document.querySelector('#BtnSolicito_Mixed').style.display = "none";
        }

        if (!CostToIncomeVariableViable) {
            document.querySelector('#validations_Variable').style.display = "block";
            document.querySelector('#BtnSolicito_Variable').style.display = "none";
        }

        if (!ExceededSavings) {
            ShowErrorGlobal(true);
            results.style.display = 'none';
            resultsMobile.style.visibility = 'hidden';
            console.log("SAvings es mayor que housePrice");

        }

        //Comprobar si houseprice tiene errores tiene que aparece el error
        const housePriceInput = document.getElementById("HousePrice");

        if (housePriceInput) {
            const parentDiv = housePriceInput.closest("div.form-input.error"); // Busca el ancestro más cercano con la clase
            if (parentDiv) {
                ShowErrorGlobal(true);
                results.style.display = 'none';
                resultsMobile.style.visibility = 'hidden';

            }
        }

        //Comprobar si en los ahorros tiene errores
        const MortgageHouseSavings = document.getElementById("MortgageHouseSavings");

        if (MortgageHouseSavings) {
            const parentDiv = MortgageHouseSavings.closest("div.form-input.error"); // Busca el ancestro más cercano con la clase
            if (parentDiv) {
                ShowErrorGlobal(true);
                results.style.display = 'none';
                resultsMobile.style.visibility = 'hidden';

            }
        }



    }

    MortgageTermInput.addEventListener('change', async () => {
        var mortgageTermNumber = (Math.round(formatNumberInt(MortgageTermInput.value) * 100) / 100);


        if (mortgageTermNumber < 5) {
            results.querySelector('#anhos5li').style.display = "none";
            results.querySelector('#anhos10li').style.display = "none";
            results.querySelector('#anhos7li').style.display = "none";


        }
        else if (mortgageTermNumber > 5 && mortgageTermNumber < 8) {
            results.querySelector('#anhos5li').style.display = "block";
            results.querySelector('#anhos10li').style.display = "none";
            results.querySelector('#anhos7li').style.display = "none";

        }
        else if (mortgageTermNumber > 8 && mortgageTermNumber < 11) {
            results.querySelector('#anhos5li').style.display = "block";
            results.querySelector('#anhos10li').style.display = "none";
            results.querySelector('#anhos7li').style.display = "block";

        }
        else {
            results.querySelector('#anhos5li').style.display = "block";
            results.querySelector('#anhos10li').style.display = "block";
            results.querySelector('#anhos7li').style.display = "block";
        }

        ModifyOptionMixedWithMortgageTerm(mortgageTermNumber);

        await ReloadData();
    });

    //Esta funcion Modifica las opciones del mixto en el caso de que hayamos seleccionado por ejemplo 10 y el plazo de la hipoteca sea 8. Evitamos casos negativos. 
    function ModifyOptionMixedWithMortgageTerm(mortgageTermNumber) {
        var MixtoOption = localStorage.getItem("selectedAnhosMixed") || 5;
        // Selecciona todos los radio buttons dentro del grupo con name="anhos"
        const radios = results.querySelectorAll('input[name="anhosMixed"]');
        const radiosMobile = resultsMobile.querySelectorAll('input[name="anhosMixed-mobile"]');

        if (mortgageTermNumber < 7 && MixtoOption >= 7) {
            MixtoOption = 5;
            localStorage.setItem("selectedAnhosMixed", 5);
        }
        else if (mortgageTermNumber <= 10 && mortgageTermNumber >= 7 && MixtoOption == 10) {
            MixtoOption = 7;
            localStorage.setItem("selectedAnhosMixed", 7);

        }

        radios.forEach(radio => {
            if (radio.value === MixtoOption) {
                console.log("Seleccionar" + radio.value);
                radio.checked = true;

                // Sincronizar con mobile
                radiosMobile.forEach(radioMob => {
                    if (radioMob.value === radio.value) {
                        radioMob.checked = true;
                    }
                });
            }
        });
    }

    // Uso de la vivienda First Resident/Second
    element.querySelectorAll('input[name="usoVivienda"]').forEach((radio) => {
        radio.addEventListener('change', async () => {
            await ReloadData();
        });
    });

    //Type of property New construction / SecondHand
    element.querySelectorAll('input[name="tipoCasa"]').forEach((radio) => {
        radio.addEventListener('change', async () => {  // Define la función de evento como async
            await ReloadData();
        });
    });



    const evaluate = async () => {
        var housePriceInput = element.querySelector('input[name="house-price"]');
        var housePrice = Math.round(formatNumberInt(housePriceInput.value) * 100) / 100;
        var savingsInput = element.querySelector('input[name="cuanto-aportas"]');
        var savings = Math.round(formatNumberInt(savingsInput.value) * 100) / 100;
        var MortgageTermInput = element.querySelector('input[name="mortgage-term"]');
        var mortgageTerm = ((Math.round(formatNumberInt(MortgageTermInput.value) * 100) / 100) * 12);
        var usoVivienda = element.querySelector('input[name="usoVivienda"]:checked').value === 'true';
        var tipoCasa = element.querySelector('input[name="tipoCasa"]:checked').value;
        var Age = parseInt(element.querySelector("#Edad").value, 10);
        var language = document.documentElement.lang == "en" ? "English" : "Spanish";
        var resident = document.querySelector('input[name="residentIb"]:checked');
        var residentValue = resident ? resident.id === "residentIbSi" : true;

        console.log("savings " + savings);
        var data = {
            AgeOfOldestHolder: Age,
            Holders: holdersData,
            FirstResidence: usoVivienda,
            Resident: residentValue,
            PropertyType: tipoCasa,
            Region: provincia,
            PurchaseSale: housePrice,
            Contribution: savings,
            Term: mortgageTerm,
            Language: language
        };


        try {

            console.log(data);
            // Llamada a la API
            const productsJson = await mortgagePaymentApiClient.calculate(data);
            //saveFormData();

            // Asegúrate de acceder a la propiedad correcta que contiene el array
            products = productsJson.products || []; // Cambia 'products' al nombre correcto

            //console.log(products);

            // Filtrar productos de tipo Fixed
            fixedProducts = products.find(product => {
                return product.basicData.type === "Fixed";
            });

            ShowErrorGlobal(false);

            loadDataFixed(fixedProducts);

            //Mixto 5 años
            Mixed5 = products.find(product => {
                return product.basicData.type === "Mixed" && product.basicData.fixedTerm == 60;
            });


            //Mixto 10 años
            Mixed10 = products.find(product => {
                return product.basicData.type === "Mixed" && product.basicData.fixedTerm == 120;
            });


            //Mixto 7 años
            Mixed7 = products.find(product => {
                return product.basicData.type === "Mixed" && product.basicData.fixedTerm == 84;
            });

            let valueMixedSelected = document.querySelector('#valueMixedSelected').value;

            MixtoOption = localStorage.getItem("selectedAnhosMixed") || valueMixedSelected;


            if (MixtoOption == 5) {
                loadDataMixed(Mixed5, 5);
            }
            else if (MixtoOption == 10) {
                loadDataMixed(Mixed10, 10);
            }
            else if (MixtoOption == 7) {
                loadDataMixed(Mixed7, 7);
            }

            // variable
            variable = products.find(product => {
                return product.basicData.type === "Variable";
            });

            loadDataVariable(variable);

            return true;

        } catch (error) {
            ShowErrorGlobal(true);

            results.style.display = 'none';
            resultsMobile.style.visibility = 'hidden';
            console.error('Error al obtener los productos:', error);
            return false;
        }


    }

    function tipoimpuesto(expensesLightbox) {
        //El tipo de label para canarias y Nueva construccion es (IGIC + AJD) para el resto de españa (ITP)
        var tipoCasaValue = element.querySelector('input[name="tipoCasa"]:checked').value;
        if (provincia == "Canarias" && tipoCasaValue == "NewConstruction") {
            expensesLightbox.querySelector('#tax-type-spain').classList.add('hidden');
            expensesLightbox.querySelector('#tax-type-canarias').classList.remove('hidden');
            expensesLightbox.querySelector('#tax-type-spain-new-construction').classList.add('hidden');
        }
        else {
            if (tipoCasaValue == "NewConstruction") {
                expensesLightbox.querySelector('#tax-type-spain').classList.add('hidden');
                expensesLightbox.querySelector('#tax-type-canarias').classList.add('hidden');
                expensesLightbox.querySelector('#tax-type-spain-new-construction').classList.remove('hidden');
            }
            else {
                expensesLightbox.querySelector('#tax-type-spain').classList.remove('hidden');
                expensesLightbox.querySelector('#tax-type-canarias').classList.add('hidden');
                expensesLightbox.querySelector('#tax-type-spain-new-construction').classList.add('hidden');
            }

        }
    }


    const loadDataFixed = (product) => {
        var cardFixed = results.querySelector('#type-Fixed-id');
        var cardFixedMobile = resultsMobile.querySelector('#type-Fixed-id');

        if (!cardFixed) {
            return;
        }
        var savingsInput = element.querySelector('input[name="cuanto-aportas"]');
        var savings = Math.round(formatNumberInt(savingsInput.value) * 100) / 100;

        var basicData = product.basicData;
        var quotas = product.quotas[0];
        var quotamonth = formatNumberSpanishWithTwoDecimals(quotas.amount, 2);

        var termInYears = formatNumberSpanishWithTwoDecimals(basicData.fixedTerm / 12, 0);
        var totalamount = formatNumberSpanishWithTwoDecimals(basicData.mortgageAmount, 0);
        var tae = formatNumberSpanishWithTwoDecimals(basicData.annualPercentageRate, 3);
        var tin = formatNumberSpanishWithTwoDecimals(basicData.nominalInterestRate, 3);
        var contribution = savings;

        var expenses = product.expenses;
        var tax = expenses.tax;
        var openingCommission = expenses.openingCommission;
        var appraisal = expenses.appraisal;
        var notary = expenses.notary;
        var registry = expenses.registry;
        var manager = expenses.manager;
        var purchaseCosts = notary + registry + manager + tax;
        var mortgageCosts = openingCommission + appraisal;
        var taxes = tax + openingCommission + appraisal + notary + registry + manager;
        var taxesFormat = formatNumberSpanishWithTwoDecimals(taxes, 2);
        var totalsavings = formatNumberSpanishWithTwoDecimals(contribution, 2);
        var savingsFormat = formatNumberSpanishWithTwoDecimals(contribution - taxes, 2);
        var legal = product.legals.text;
        var legalRepresentativo = product.legals.example;
        var minContribution = product.risks.minContribution;
        var costToIncomeRatio = product.risks.costToIncomeRatio;



        // Expenses Table
        const expensesLightbox = document.querySelector(`#taxes-and-expenses-${product.basicData.type}`);
        if (expensesLightbox) {
            expensesLightbox.querySelector('#exp-notary').innerHTML = `${formatNumberSpanishWithTwoDecimals(notary, 2)} €`;
            expensesLightbox.querySelector('#exp-registry').innerHTML = `${formatNumberSpanishWithTwoDecimals(registry, 2)} €`;
            expensesLightbox.querySelector('#exp-manager').innerHTML = `${formatNumberSpanishWithTwoDecimals(manager, 2)} €`;
            expensesLightbox.querySelector('#exp-tax').innerHTML = `${formatNumberSpanishWithTwoDecimals(tax, 2)} €`;
            tipoimpuesto(expensesLightbox);
            expensesLightbox.querySelector('#exp-purchase-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(purchaseCosts, 2)} €`;
            expensesLightbox.querySelector('#exp-appraisal').innerHTML = `${formatNumberSpanishWithTwoDecimals(appraisal, 2)} €`;
            expensesLightbox.querySelector('#exp-opening').innerHTML = `${formatNumberSpanishWithTwoDecimals(openingCommission, 2)} €`;
            expensesLightbox.querySelector('#exp-mortgage-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(mortgageCosts, 2)} €`;
            expensesLightbox.querySelector('#exp-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(purchaseCosts + mortgageCosts, 2)} €`;
        }

        //Minima contribution
        console.log("minContribution " + minContribution);
        document.querySelector('#MinContributionProfile').value = minContribution;
        document.querySelector('#CostToIncomeRatio_Fixed').value = costToIncomeRatio;

        //Terms in years
        cardFixed.querySelectorAll('.TermYears_Fixed').forEach(span => {
            span.innerHTML = `${termInYears}`;
        });
        cardFixedMobile.querySelectorAll('.TermYears_Fixed').forEach(span => {
            span.innerHTML = `${termInYears}`;
        });

        cardFixed.querySelector('#cuotames').innerHTML = `${quotamonth}`;
        //cardFixedMobile.querySelector('#cuotames').innerHTML = `${quotamonth}`;

        // total amount
        cardFixed.querySelector('#total-amount').innerHTML = `${totalamount}`;
        // tae
        cardFixed.querySelector('#tae-cifra').innerHTML = `${tae}%`;
        cardFixedMobile.querySelector('#tae-cifra').innerHTML = `${tae}%`;
        //tin
        cardFixed.querySelector('#tin-cifra').innerHTML = `${tin}%`;
        cardFixedMobile.querySelector('#tin-cifra').innerHTML = `${tin}%`;
        //savings
        cardFixed.querySelector('#ahorro-aportado').innerHTML = `${savingsFormat}€`;
        //taxes
        cardFixed.querySelector('#impuestos-gastos').innerHTML = `${taxesFormat}€`;
        //total savings
        cardFixed.querySelector('#total-ahorrado').innerHTML = `${totalsavings}€`;
        //Legal
        document.querySelector('#legalFijo').innerHTML = `${legal}`;
        document.querySelector('#legalRepresentativoFijo').innerHTML = `${legalRepresentativo}`;
    }

    const loadDataMixed = (product, type) => {
        var cardMixed = results.querySelector('#type-Mixed-id');
        var cardMixedMobile = resultsMobile.querySelector('#type-Mixed-id');
        if (!cardMixed) {
            return;
        }
        var savingsInput = element.querySelector('input[name="cuanto-aportas"]');
        var savings = Math.round(formatNumberInt(savingsInput.value) * 100) / 100;

        var yearsChoosen = Math.round(formatNumberInt(MortgageTermInput.value));
        var basicData = product.basicData;
        var quotasfixed = product.quotas[0];
        var quotamonthFixed = formatNumberSpanishWithTwoDecimals(quotasfixed.amount, 2);
        var quotamonthMixed = "Euribor + " + formatNumberSpanishWithTwoDecimals(product.rates.margin, 2) + "%";
        var termInYears = formatNumberSpanishWithTwoDecimals(basicData.fixedTerm / 12, 0);
        var termInYearsRest = formatNumberSpanishWithTwoDecimals(Math.round(yearsChoosen - termInYears), 0);
        var totalamount = formatNumberSpanishWithTwoDecimals(basicData.mortgageAmount, 0);
        var tae = formatNumberSpanishWithTwoDecimals(basicData.annualPercentageRate, 3);
        var tin = formatNumberSpanishWithTwoDecimals(basicData.nominalInterestRate, 3);
        var contribution = savings;

        var expenses = product.expenses;
        var tax = expenses.tax;
        var openingCommission = expenses.openingCommission;
        var appraisal = expenses.appraisal;
        var notary = expenses.notary;
        var registry = expenses.registry;
        var manager = expenses.manager;
        var purchaseCosts = notary + registry + manager + tax;
        var mortgageCosts = openingCommission + appraisal;
        var taxes = tax + openingCommission + appraisal + notary + registry + manager;
        var taxesFormat = formatNumberSpanishWithTwoDecimals(taxes, 2);
        var totalsavings = formatNumberSpanishWithTwoDecimals(contribution, 2);
        var savingsFormat = formatNumberSpanishWithTwoDecimals(contribution - taxes, 2);
        var euribor = product.rates.euribor.value;
        var legal = product.legals.text;
        var legalRepresentativo = product.legals.example;
        var minContribution = product.risks.minContribution;
        var costToIncomeRatio = product.risks.costToIncomeRatio;

        // Expenses Table
        const expensesLightbox = document.querySelector(`#taxes-and-expenses-${product.basicData.type}`);
        if (expensesLightbox) {
            expensesLightbox.querySelector('#exp-notary').innerHTML = `${formatNumberSpanishWithTwoDecimals(notary, 2)} €`;
            expensesLightbox.querySelector('#exp-registry').innerHTML = `${formatNumberSpanishWithTwoDecimals(registry, 2)} €`;
            expensesLightbox.querySelector('#exp-manager').innerHTML = `${formatNumberSpanishWithTwoDecimals(manager, 2)} €`;
            expensesLightbox.querySelector('#exp-tax').innerHTML = `${formatNumberSpanishWithTwoDecimals(tax, 2)} €`;
            tipoimpuesto(expensesLightbox);
            expensesLightbox.querySelector('#exp-purchase-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(purchaseCosts, 2)} €`;
            expensesLightbox.querySelector('#exp-appraisal').innerHTML = `${formatNumberSpanishWithTwoDecimals(appraisal, 2)} €`;
            expensesLightbox.querySelector('#exp-opening').innerHTML = `${formatNumberSpanishWithTwoDecimals(openingCommission, 2)} €`;
            expensesLightbox.querySelector('#exp-mortgage-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(mortgageCosts, 2)} €`;
            expensesLightbox.querySelector('#exp-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(purchaseCosts + mortgageCosts, 2)} €`;
        }

        document.querySelector('#MinContributionProfile').value = minContribution;
        document.querySelector('#CostToIncomeRatio_Mixed').value = costToIncomeRatio;

        if (type == 5) {
            cardMixed.querySelector('#anhos5').checked = true;
        }
        else if (type == 10) {
            cardMixed.querySelector('#anhos10').checked = true;
        }
        else if (type == 7) {
            cardMixed.querySelector('#anhos7').checked = true;
        }

        //Terms in years
        cardMixed.querySelectorAll('.TermYears_Mixed').forEach(span => {
            span.innerHTML = `${termInYears}`;
        });
        cardMixedMobile.querySelectorAll('.TermYears_Mixed').forEach(span => {
            span.innerHTML = `${termInYears}`;
        });



        if (cardMixed.querySelector('#TinTextNumber'))
            cardMixed.querySelector('#TinTextNumber').innerHTML = `TIN Los ${termInYears} `;


        //Resto de periodo mixto
        cardMixed.querySelector('#TermYearsRest_Mixed').innerHTML = `${termInYearsRest}`;
        cardMixedMobile.querySelector('#TermYearsRest_Mixed').innerHTML = `${termInYearsRest}`;
        //quote months Fixed

        cardMixed.querySelector('#cuotames').innerHTML = `${quotamonthFixed}`;
        cardMixedMobile.querySelector('#cuotames').innerHTML = `${quotamonthFixed}`;

        //quote months Fixed
        cardMixed.querySelector('#euribor-cifra').innerHTML = `${quotamonthMixed}`;
        cardMixedMobile.querySelector('#euribor-cifra').innerHTML = `${quotamonthMixed}`;

        // total amount
        cardMixed.querySelector('#total-amount').innerHTML = `${totalamount}`;
        // tae
        cardMixed.querySelector('#tae-cifra').innerHTML = `${tae}%`;
        cardMixedMobile.querySelector('#tae-cifra').innerHTML = `${tae}%`;
        //tin
        cardMixed.querySelector('#tin-cifra').innerHTML = `${tin}%`;
        cardMixedMobile.querySelector('#tin-cifra').innerHTML = `${tin}%`;
        //savings
        cardMixed.querySelector('#ahorro-aportado').innerHTML = `${savingsFormat}€`;
        //taxes
        cardMixed.querySelector('#impuestos-gastos').innerHTML = `${taxesFormat}€`;
        //total savings
        cardMixed.querySelector('#total-ahorrado').innerHTML = `${totalsavings}€`;
        //Legal
        document.querySelector('#legalMixto').innerHTML = `${legal}`;
        document.querySelector('#legalRepresentativoMixto').innerHTML = `${legalRepresentativo}`;
    }


    const loadDataVariable = (product) => {
        var cardVariable = results.querySelector('#type-Variable-id');
        var cardVariableMobile = resultsMobile.querySelector('#type-Variable-id');

        if (!cardVariable) {
            return;
        }
        var savingsInput = element.querySelector('input[name="cuanto-aportas"]');
        var savings = Math.round(formatNumberInt(savingsInput.value) * 100) / 100;
        var basicData = product.basicData;
        var quotasfixed = product.quotas[0];
        var monthVariable = basicData.term - basicData.fixedTerm;
        var quotamonthFixed = formatNumberSpanishWithTwoDecimals(quotasfixed.amount, 2);
        var quotamonthMixed = "Euribor + " + formatNumberSpanishWithTwoDecimals(product.rates.margin, 2) + "%";
        var termInYearsFixed = formatNumberSpanishWithTwoDecimals(basicData.fixedTerm / 12, 0) === "1" ? "" : formatNumberSpanishWithTwoDecimals(basicData.fixedTerm / 12, 0);

        var termInYearsVariable = formatNumberSpanishWithTwoDecimals(monthVariable / 12, 0);
        var totalamount = formatNumberSpanishWithTwoDecimals(basicData.mortgageAmount, 0);
        var tae = formatNumberSpanishWithTwoDecimals(basicData.annualPercentageRate, 3);
        var tin = formatNumberSpanishWithTwoDecimals(basicData.nominalInterestRate, 3);
        var contribution = savings;

        var expenses = product.expenses;
        var tax = expenses.tax;
        var openingCommission = expenses.openingCommission;
        var appraisal = expenses.appraisal;
        var notary = expenses.notary;
        var registry = expenses.registry;
        var manager = expenses.manager;
        var purchaseCosts = notary + registry + manager + tax;
        var mortgageCosts = openingCommission + appraisal;
        var taxes = tax + openingCommission + appraisal + notary + registry + manager;
        var taxesFormat = formatNumberSpanishWithTwoDecimals(taxes, 2);
        var totalsavings = formatNumberSpanishWithTwoDecimals(contribution, 2);
        var savingsFormat = formatNumberSpanishWithTwoDecimals(contribution - taxes, 2);
        var euribor = product.rates.euribor.value;
        var legal = product.legals.text;
        var legalRepresentativo = product.legals.example;
        var minContribution = product.risks.minContribution;
        var costToIncomeRatio = product.risks.costToIncomeRatio;

        // Expenses Table
        const expensesLightbox = document.querySelector(`#taxes-and-expenses-${product.basicData.type}`);
        if (expensesLightbox) {
            expensesLightbox.querySelector('#exp-notary').innerHTML = `${formatNumberSpanishWithTwoDecimals(notary, 2)} €`;
            expensesLightbox.querySelector('#exp-registry').innerHTML = `${formatNumberSpanishWithTwoDecimals(registry, 2)} €`;
            expensesLightbox.querySelector('#exp-manager').innerHTML = `${formatNumberSpanishWithTwoDecimals(manager, 2)} €`;
            expensesLightbox.querySelector('#exp-tax').innerHTML = `${formatNumberSpanishWithTwoDecimals(tax, 2)} €`;
            tipoimpuesto(expensesLightbox);
            expensesLightbox.querySelector('#exp-purchase-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(purchaseCosts, 2)} €`;
            expensesLightbox.querySelector('#exp-appraisal').innerHTML = `${formatNumberSpanishWithTwoDecimals(appraisal, 2)} €`;
            expensesLightbox.querySelector('#exp-opening').innerHTML = `${formatNumberSpanishWithTwoDecimals(openingCommission, 2)} €`;
            expensesLightbox.querySelector('#exp-mortgage-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(mortgageCosts, 2)} €`;
            expensesLightbox.querySelector('#exp-total').innerHTML = `${formatNumberSpanishWithTwoDecimals(purchaseCosts + mortgageCosts, 2)} €`;
        }



        document.querySelector('#MinContributionProfile').value = minContribution;
        document.querySelector('#CostToIncomeRatio_Variable').value = costToIncomeRatio;

        //Terms in years      
        cardVariable.querySelectorAll('.TermYears_Variable').forEach(span => {
            span.innerHTML = `${termInYearsFixed}`;
        });
        cardVariableMobile.querySelectorAll('.TermYears_Variable').forEach(span => {
            span.innerHTML = `${termInYearsFixed}`;
        });

        cardVariable.querySelector('#cuotames').innerHTML = `${quotamonthFixed}`;
        cardVariableMobile.querySelector('#cuotames').innerHTML = `${quotamonthFixed}`;

        //quote months Fixed
        cardVariable.querySelector('#euribor-cifra').innerHTML = `${quotamonthMixed}`;
        cardVariableMobile.querySelector('#euribor-cifra').innerHTML = `${quotamonthMixed}`;

        cardVariable.querySelector('#TermYearsRest_Variable').innerHTML = `${termInYearsVariable}`;
        cardVariableMobile.querySelector('#TermYearsRest_Variable').innerHTML = `${termInYearsVariable}`;

        // total amount
        cardVariable.querySelector('#total-amount').innerHTML = `${totalamount}`;
        // tae
        cardVariable.querySelector('#tae-cifra').innerHTML = `${tae}%`;
        cardVariableMobile.querySelector('#tae-cifra').innerHTML = `${tae}%`;
        //tin
        cardVariable.querySelector('#tin-cifra').innerHTML = `${tin}%`;
        cardVariableMobile.querySelector('#tin-cifra').innerHTML = `${tin}%`;

        //savings
        cardVariable.querySelector('#ahorro-aportado').innerHTML = `${savingsFormat}€`;
        //taxes
        cardVariable.querySelector('#impuestos-gastos').innerHTML = `${taxesFormat}€`;
        //total savings
        cardVariable.querySelector('#total-ahorrado').innerHTML = `${totalsavings}€`;
        //Legal
        document.querySelector('#legalVariable').innerHTML = `${legal}`;
        document.querySelector('#legalRepresentativoVariable').innerHTML = `${legalRepresentativo}`;
    }

    let MixtoOption = localStorage.getItem("selectedAnhosMixed") || 5;
    // Selecciona todos los radio buttons dentro del grupo con name="anhos"
    const radios = results.querySelectorAll('input[name="anhosMixed"]');
    const radiosMobile = resultsMobile.querySelectorAll('input[name="anhosMixed-mobile"]');

    radios.forEach(radio => {
        if (radio.value === MixtoOption) {
            console.log("Seleccionar" + radio.value);
            radio.checked = true;

            // Sincronizar con mobile
            radiosMobile.forEach(radioMob => {
                if (radioMob.value === radio.value) {
                    radioMob.checked = true;
                }
            });
        }
    });

    // Agrega un evento de cambio a cada radio button
    radios.forEach((radio) => {
        radio.addEventListener('change', (event) => {
            const valorSeleccionado = parseInt(event.target.value);
            MixtoOption = localStorage.setItem("selectedAnhosMixed", valorSeleccionado);

            // Sincronizar con mobile
            radiosMobile.forEach(radioMob => {
                if (radioMob.value === event.target.value) {
                    radioMob.checked = true;
                }
            });

            console.log("valor Seleccionado " + valorSeleccionado);
            if (valorSeleccionado == 5) {
                loadDataMixed(Mixed5, 5);
            }
            else if (valorSeleccionado == 10) {
                loadDataMixed(Mixed10, 10);
            }
            else if (valorSeleccionado == 7) {
                loadDataMixed(Mixed7, 7);
            }
        });
    });

    radiosMobile.forEach((radio) => {
        radio.addEventListener('change', (event) => {
            const valorSeleccionado = parseInt(event.target.value);
            MixtoOption = localStorage.setItem("selectedAnhosMixed", valorSeleccionado);

            // Sincronizar con desktop
            radios.forEach(radioDesk => {
                if (radioDesk.value === event.target.value) {
                    radioDesk.checked = true;
                }
            });

            console.log("valor Seleccionado " + valorSeleccionado);
            if (valorSeleccionado == 5) {
                loadDataMixed(Mixed5, 5);
            }
            else if (valorSeleccionado == 10) {
                loadDataMixed(Mixed10, 10);
            }
            else if (valorSeleccionado == 7) {
                loadDataMixed(Mixed7, 7);
            }
        });
    });

    // Función para crear el objeto o array basado en el valor del radio
    async function createHoldersObject() {
        let selectedEmploymentStatus = Array.from(firstEmploymentStatusRadios)
            .find(radio => radio.checked);
        selectedEmploymentStatus = selectedEmploymentStatus ? selectedEmploymentStatus.value : "PublicEmployee";
        let selectedEmploymentStatusSecond = Array.from(secondEmploymentStatusRadios)
            .find(radio => radio.checked);
        selectedEmploymentStatusSecond = selectedEmploymentStatusSecond ? selectedEmploymentStatusSecond.value : "PublicEmployee";
        const monthlyIncomeFirst = isNaN(parseFloat(monthlyIncomeFirstHolderInput.value)) ? 1800.00 : parseFloat(monthlyIncomeFirstHolderInput.value);
        const monthlyIncomeSecond = isNaN(parseFloat(monthlyIncomeSecondHolderInput.value)) ? 1800.00 : parseFloat(monthlyIncomeSecondHolderInput.value);

        const paymentRadios = element.querySelectorAll('input[name="numeroPagas1"]');
        const paymentMonths = Array.from(paymentRadios)
            .find(radio => radio.checked);
        var paymentMonthsValue = paymentMonths ? paymentMonths.value : 12;

        const paymentRadio2 = element.querySelectorAll('input[name="numeroPagas2"]');
        const paymentMonths2 = Array.from(paymentRadio2)
            .find(radio => radio.checked);
        var paymentMonthsValue2 = paymentMonths2 ? paymentMonths2.value : 12;

        const otherLoansPaymentValue = otherLoansPaymentInput ? parseFloat(otherLoansPaymentInput.value) : 0;

        if (radioOneHolder.checked) {
            // Si el radio es 1, crear un solo objeto
            holdersData = [{
                employmentStatus: selectedEmploymentStatus,
                monthlyIncome: monthlyIncomeFirst,
                paymentMonths: paymentMonthsValue,
                otherLoansPayment: otherLoansPaymentValue
            }
            ];

            document.querySelector(".HowOldHoldersTwoHolders").style.display = "none";
            document.querySelector(".HowOldHoldersOneHolder").style.display = "flex";
            document.querySelector("#FirstHolderId").style.display = "none";
            // Ocultar todos los elementos .secondHolderli
            secondHolderElements.forEach(element => {
                element.classList.add('hidden');
            });

        } else if (radioTwoHolders.checked) {
            // Si el radio es 2, crear un array con dos objetos
            holdersData = [
                {
                    employmentStatus: selectedEmploymentStatus,
                    monthlyIncome: monthlyIncomeFirst,
                    paymentMonths: paymentMonthsValue,
                    otherLoansPayment: otherLoansPaymentValue
                },
                {
                    employmentStatus: selectedEmploymentStatusSecond,
                    monthlyIncome: monthlyIncomeSecond,
                    paymentMonths: paymentMonthsValue2,
                    otherLoansPayment: 0.00
                }
            ];

            document.querySelector(".HowOldHoldersTwoHolders").style.display = "flex";
            document.querySelector(".HowOldHoldersOneHolder").style.display = "none";
            document.querySelector("#FirstHolderId").style.display = "block";

            // Mostrar todos los elementos .secondHolderli
            secondHolderElements.forEach(element => {
                element.classList.remove('hidden');
            });
        }

        //console.log("holdersData:", holdersData); // Muestra el resultado en la consola
        return holdersData;
    }



    // Asignar el evento change a cada input de radio FirstEmploymentStatus para capturar cambios
    firstEmploymentStatusRadios.forEach(radio => {
        radio.addEventListener("change", async () => {
            await ReloadData();
        });
    });

    // Asignar el evento change a cada input de radio FirstEmploymentStatus para capturar cambios
    secondEmploymentStatusRadios.forEach(radio => {
        radio.addEventListener("change", async () => {
            await ReloadData();
        });
    });

    residentRadios.forEach((radio) => {
        radio.addEventListener('change', async () => {
            await ReloadData();
            if (noRadio && usoViviendaContainer) {
                if (noRadio.checked) {
                    usoViviendaContainer.style.display = "none";
                } else {
                    usoViviendaContainer.style.display = "flex";
                }
            }
        });
    });

    radioOneHolder.addEventListener("change", async () => {
        await ReloadData();
    });

    radioTwoHolders.addEventListener("change", async () => {
        await ReloadData();
    });
    // Asignar el evento change al input de ingresos mensuales
    monthlyIncomeFirstHolderInput.addEventListener("blur", async () => {
        await ReloadData();
    });

    // Asignar el evento change al input de ingresos mensuales
    monthlyIncomeSecondHolderInput.addEventListener("blur", async () => {
        await ReloadData();
    });

    // Asignar eventos change a los radios de paymentMonths
    paymentMonthsRadios.forEach(radio => {
        radio.addEventListener("change", async () => {
            await ReloadData();
        });

    });

    paymentMonthsRadios2.forEach(radio => {
        radio.addEventListener("change", async () => {
            await ReloadData();
        });
    });

    otherLoansPaymentInput.addEventListener("blur", async () => {
        await ReloadData();
    });

    //Edad 
    // Selecciona el input de edad
    const edadInput = element.querySelector("#Edad");

    // Asigna el evento de escucha
    edadInput.addEventListener("blur", async function () {
        await ReloadData();
    });


    const formatNumberSpanishWithTwoDecimals = (number, digits) => {
        const parsedNumber = typeof number === 'string'
            ? parseFloat(number.replace(',', '.')) // Convertir coma decimal a punto para parsear
            : number;

        // Validar si es un número
        if (isNaN(parsedNumber)) {
            throw new Error('El valor proporcionado no es un número válido');
        }

        // Convertir el número a string con formato español
        return parsedNumber
            .toFixed(digits) // Asegurar los decimales
            .replace('.', ',') // Reemplazar el punto decimal por coma
            .replace(/\B(?=(\d{3})+(?!\d))/g, '.'); // Insertar puntos en los miles
    };

    const formatNumberInt = (number) => {
        return parseInt(number.replace(/\./g, ''));
    }



    // Seleccionar los radios y el elemento a mostrar/ocultar
    const otrosPrestamosSi = element.querySelector('#otrosPrestamosSi');
    const otrosPrestamosNo = element.querySelector('#otrosPrestamosNo');
    const totalPrestamos = element.querySelector('#totalprestamos');

    // Función para mostrar u ocultar el elemento totalprestamos
    function toggleTotalPrestamos() {
        if (otrosPrestamosSi.checked) {
            // Mostrar totalprestamos si "Sí" está seleccionado
            totalPrestamos.style.display = 'block';
        } else {
            // Ocultar totalprestamos si "No" está seleccionado
            totalPrestamos.style.display = 'none';
        }
    }

    // Asignar el evento change a ambos radios
    otrosPrestamosSi.addEventListener("change", toggleTotalPrestamos);
    otrosPrestamosNo.addEventListener("change", toggleTotalPrestamos);

    // Llamar a la función una vez para configurar la visibilidad inicial
    toggleTotalPrestamos();


    // Botones
    const buttonFixed = results.querySelector("#BtnSolicito_Fixed");
    const buttonMixed = results.querySelector("#BtnSolicito_Mixed");
    const buttonVariable = results.querySelector("#BtnSolicito_Variable");

    function ValidateRequired(event) {

        const form = document.querySelector('form');
        const validator = form ? formValidator(form) : null;

        if (validator === null) {
            return; // Detener la ejecución si validator es null
        }


        const monthlyIncomeFirstHolderInput = document.querySelector("#MonthyIncomeFirstHolder");
        validator.fieldValidator(monthlyIncomeFirstHolderInput);


        const monthlyIncomeSecondHolderInput = document.querySelector("#MonthyIncomeSecondHolder");
        const style = getComputedStyle(monthlyIncomeSecondHolderInput);
        if (monthlyIncomeSecondHolderInput && monthlyIncomeSecondHolderInput.offsetParent !== null && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0") {

            validator.fieldValidator(monthlyIncomeSecondHolderInput);
        }


        const OtherLoans = document.querySelector("#OtherLoans");
        const style2 = getComputedStyle(OtherLoans);
        if (OtherLoans && OtherLoans.offsetParent !== null && style2.display !== "none" && style2.visibility !== "hidden" && style2.opacity !== "0") {
            validator.fieldValidator(OtherLoans);
        }


        const firstErrorElement = document.querySelector(".form-input.error");

        if (firstErrorElement) {
            event.preventDefault();
            // Desplazar el scroll hasta el elemento
            firstErrorElement.scrollIntoView({ behavior: "smooth", block: "center" });

            // También puedes agregar un foco al primer input dentro de ese contenedor, si es necesario
            const input = firstErrorElement.querySelector("input");
            if (input) {
                input.focus();
            }
        }


        SummarymortgageRequest(element);


    }

    function SummarymortgageRequest(element) {

        //Province
        const provinciaRadios = element.querySelectorAll('input[name="where"]');
        let selectedRadio = Array.from(provinciaRadios).find(radio => radio.checked);


        var provinciaId = selectedRadio ? selectedRadio.getAttribute('data-province') : null; // Valor de data-province

        var provinciaName = selectedRadio ? element.querySelector(`label[for="${selectedRadio.id}"]`).textContent.trim() : null;


        localStorage.setItem("ProvinceNameStorage", provinciaName);
        localStorage.setItem("ProvinceIdStorage", provinciaId);

        //MortgageHousePrice
        var housePriceInput = element.querySelector('input[name="house-price"]');
        var housePrice = housePriceInput ? housePriceInput.value : 0;


        localStorage.setItem("MortgageHouseStorage", housePrice);

        //MortgageSaving
        var savingsInput = document.querySelector('input[name="cuanto-aportas"]');
        var contribution = savingsInput ? savingsInput.value : 0;


        localStorage.setItem("MortgageSavingStorage", contribution);

        //MortgageTerm
        var MortgageTermInput = element.querySelector('input[name="mortgage-term"]');
        var mortgageTerm = ((Math.round(formatNumberInt(MortgageTermInput.value) * 100) / 100) * 12);


        localStorage.setItem("MortgageTermStorage", mortgageTerm);

        //PropertyType
        var tipoCasaSelected = element.querySelector('input[name="tipoCasa"]:checked')
        var tipoCasaValue = element.querySelector('input[name="tipoCasa"]:checked').value;
        if (tipoCasaSelected) {
            // Buscar el label asociado al radio seleccionado
            const label = document.querySelector(`label[for="${tipoCasaSelected.id}"]`);

            // Obtener el texto dentro del <span class="caption-placeholder-m">
            const tipoCasaText = label ? label.querySelector('.caption-placeholder-m').textContent.trim() : null;

            localStorage.setItem("PropertyTypeNameStorage", tipoCasaText);

        }

        localStorage.setItem("PropertyTypeStorage", tipoCasaValue);


        //Purpose
        var PurposeSelected = element.querySelector('input[name="usoVivienda"]:checked')
        var PurposeValue = element.querySelector('input[name="usoVivienda"]:checked').value;
        if (PurposeSelected) {
            // Buscar el label asociado al radio seleccionado
            const label = document.querySelector(`label[for="${PurposeSelected.id}"]`);

            // Obtener el texto dentro del <span class="caption-placeholder-m">
            const PurposeText = label ? label.querySelector('.caption-placeholder-m').textContent.trim() : null;

            localStorage.setItem("PurposeNameStorage", PurposeText);

        }

        localStorage.setItem("PurposeStorage", PurposeValue);


        //MainHolderAge
        var MainHolderAge = parseInt(element.querySelector("#Edad").value, 10);
        localStorage.setItem("MainHolderAgeStorage", MainHolderAge);

        //Titulares
        const radioOneHolder = element.querySelector("#oneHolder");
        const radioTwoHolders = element.querySelector("#twoHolders");
        var titulares = radioOneHolder.checked ? "1" : (radioTwoHolders.checked ? "2" : "");

        localStorage.setItem("Titulares", titulares);

        //MainHolderInput
        var monthlyIncomeFirstHolderInput = element.querySelector("#MonthyIncomeFirstHolder");

        var valueFirstHolder = monthlyIncomeFirstHolderInput ? monthlyIncomeFirstHolderInput.value.trim() : '';
        var monthlyIncomeFirstHolder = valueFirstHolder && !isNaN(parseFloat(valueFirstHolder))
            ? formatNumberSpanishWithTwoDecimals(valueFirstHolder, 0)
            : 0;

        localStorage.setItem("MainHolderInput", monthlyIncomeFirstHolder);

        //MainHolderPaymentsNumber

        var MainHolderPaymentsNumberRadios = element.querySelectorAll('input[name="numeroPagas1"]');
        var MainHolderPaymentsNumberChecked = Array.from(MainHolderPaymentsNumberRadios)
            .find(radio => radio.checked);
        var MainHolderPaymentsNumberValue = MainHolderPaymentsNumberChecked ? MainHolderPaymentsNumberChecked.value : 12;

        localStorage.setItem("MainHolderPaymentsNumber", MainHolderPaymentsNumberValue);

        //SecondaryHolderInput
        var monthlyIncomeSecondHolderInput = element.querySelector("#MonthyIncomeSecondHolder");

        var valueSecondHolder = monthlyIncomeSecondHolderInput ? monthlyIncomeSecondHolderInput.value.trim() : '';
        var monthlyIncomeSecondHolder = valueSecondHolder && !isNaN(parseFloat(valueSecondHolder))
            ? formatNumberSpanishWithTwoDecimals(valueSecondHolder, 0)
            : 0;

        localStorage.setItem("SecondaryHolderInput", monthlyIncomeSecondHolder);


        // SecondaryPaymentsNumber
        var SecondaryHolderPaymentsNumberRadios = element.querySelectorAll('input[name="numeroPagas2"]');
        const SecondaryHolderPaymentsNumberChecked = Array.from(SecondaryHolderPaymentsNumberRadios)
            .find(radio => radio.checked);
        var SecondaryHolderPaymentsNumberValue = SecondaryHolderPaymentsNumberChecked ? SecondaryHolderPaymentsNumberChecked.value : 12;

        localStorage.setItem("SecondaryPaymentsNumber", SecondaryHolderPaymentsNumberValue);


        //OtherLoanAmount
        var otherLoansPaymentInput = element.querySelector("#OtherLoans");

        var valueotherLoansPayment = otherLoansPaymentInput ? otherLoansPaymentInput.value.trim() : '';
        localStorage.setItem("OtherLoanAmount", valueotherLoansPayment);


        //HasOtherLoan

        var HasOtherLoan = element.querySelector('input[name="otrosPrestamos"]:checked').value === "Sí";

        localStorage.setItem("HasOtherLoan", HasOtherLoan);

        //Financiacion
        var cardFixed = document.querySelector('#type-Fixed-id');
        cardFixed.querySelector('#total-amount');

        var totalAmountInput = cardFixed.querySelector('#total-amount');
        var financiacion = totalAmountInput ? totalAmountInput.textContent : 0;

        localStorage.setItem("financiacion", financiacion);

        var impuestosGastosInput = cardFixed.querySelector('#impuestos-gastos');
        var impuestosGastos = impuestosGastosInput ? impuestosGastosInput.textContent.replace('€', '') : 0;

        localStorage.setItem("impuestosGastos", impuestosGastos);


        //Job situation First Holder
        const FirstEmploymentStatusRadio = element.querySelectorAll('input[name="FirstEmploymentStatus"]');
        let FirstEmploymentStatus = Array.from(FirstEmploymentStatusRadio).find(radio => radio.checked);

        var FirstEmploymentStatusId = FirstEmploymentStatus ? FirstEmploymentStatus.getAttribute('data-jobsituation') : null; // Valor de data-province

        localStorage.setItem("JobSituationFirstHolder", FirstEmploymentStatusId);

        //Job situation Second Holder
        const SecondEmploymentStatusRadio = element.querySelectorAll('input[name="SecondEmploymentStatus"]');
        let SecondEmploymentStatus = Array.from(SecondEmploymentStatusRadio).find(radio => radio.checked);

        var SecondEmploymentStatusId = SecondEmploymentStatus ? SecondEmploymentStatus.getAttribute('data-jobsituation') : null; // Valor de data-province

        localStorage.setItem("JobSituationSecondHolder", SecondEmploymentStatusId);



        console.log("ProvinceNameStorage: " + localStorage.getItem("ProvinceNameStorage"));
        console.log("ProvinceIdStorage: " + localStorage.getItem("ProvinceIdStorage"));
        console.log("MortgageHouseStorage: " + localStorage.getItem("MortgageHouseStorage"));
        console.log("MortgageSavingStorage: " + localStorage.getItem("MortgageSavingStorage"));
        console.log("MortgageTermStorage: " + localStorage.getItem("MortgageTermStorage"));
        console.log("PropertyTypeNameStorage: " + localStorage.getItem("PropertyTypeNameStorage"));
        console.log("PropertyTypeStorage: " + localStorage.getItem("PropertyTypeStorage"));
        console.log("PurposeNameStorage: " + localStorage.getItem("PurposeNameStorage"));
        console.log("PurposeStorage: " + localStorage.getItem("PurposeStorage"));
        console.log("MainHolderAgeStorage: " + localStorage.getItem("MainHolderAgeStorage"));
        console.log("Titulares: " + localStorage.getItem("Titulares"));
        console.log("MainHolderInput: " + localStorage.getItem("MainHolderInput"));
        console.log("MainHolderPaymentsNumber: " + localStorage.getItem("MainHolderPaymentsNumber"));
        console.log("SecondaryHolderInput: " + localStorage.getItem("SecondaryHolderInput"));
        console.log("SecondaryPaymentsNumber: " + localStorage.getItem("SecondaryPaymentsNumber"));
        console.log("OtherLoanAmount: " + localStorage.getItem("OtherLoanAmount"));
        console.log("HasOtherLoan: " + localStorage.getItem("HasOtherLoan"));
        console.log("financiacion: " + localStorage.getItem("financiacion"));
        console.log("impuestosGastos: " + localStorage.getItem("impuestosGastos"));


    }

    function ShowErrorGlobal(isError) {
        if (isError) {
            element.querySelector('#errors').style.display = 'block';
            document.getElementById('legalFijo').classList.add('hidden');
            document.getElementById('legalMixto').classList.add('hidden');
            document.getElementById('legalVariable').classList.add('hidden');
        }
        else {
            element.querySelector('#errors').style.display = 'none';
            var dataslide = document.querySelector('.menu-tab-button:is(.active)').getAttribute("data-slide");

            if (dataslide.includes("Fixed")) {
                document.getElementById('legalFijo').classList.remove('hidden');
                document.getElementById('legalMixto').classList.add('hidden');
                document.getElementById('legalVariable').classList.add('hidden');

            }
            else if (dataslide.includes("Mixed")) {
                document.getElementById('legalFijo').classList.add('hidden');
                document.getElementById('legalMixto').classList.remove('hidden');
                document.getElementById('legalVariable').classList.add('hidden');
            }
            else if (dataslide.includes("Variable")) {
                document.getElementById('legalFijo').classList.add('hidden');
                document.getElementById('legalMixto').classList.add('hidden');
                document.getElementById('legalVariable').classList.remove('hidden');
            }


        }
    }


    if (buttonFixed) {
        buttonFixed.addEventListener("click", (event) => {
            ValidateRequired(event);
            localStorage.setItem("MortgageType", "Fijo");
        });
    }

    if (buttonMixed) {
        buttonMixed.addEventListener("click", (event) => {
            ValidateRequired(event);
            var MixtoOption = localStorage.getItem("selectedAnhosMixed") || 5;
            localStorage.setItem("MortgageType", "Mixto " + MixtoOption);

        });
    }

    if (buttonVariable) {
        buttonVariable.addEventListener("click", (event) => {
            ValidateRequired(event);
            localStorage.setItem("MortgageType", "Variable");
        });
    }

    function legalsForSlide(activeSlideId) {
        const mortgageTermOptionSelected = formatNumberInt(MortgageTermInput.value);
        document.querySelectorAll('#textoLegal .bodycopy-s').forEach(legal => {
            legal.classList.add('hidden');
        });
        switch (activeSlideId) {
            case '#type-Fixed-id':
                document.getElementById('legalRepresentativoFijo').classList.remove('hidden');
                document.getElementById('legalFijo').classList.remove('hidden');
                MortgageTermInput.value = mortgageTermOptionSelected;
                break;
            case '#type-Mixed-id':
                document.getElementById('legalRepresentativoMixto').classList.remove('hidden');
                document.getElementById('legalMixto').classList.remove('hidden');
                MortgageTermInput.value = mortgageTermOptionSelected;
                break;
            case '#type-Variable-id':
                document.getElementById('legalRepresentativoVariable').classList.remove('hidden');
                document.getElementById('legalVariable').classList.remove('hidden');
                break;
        }
    }

    const handleTabs = (swiper) => {
        const tabs = document.querySelectorAll('#results .menu-tab-button');

        console.log("modificar selecccion");
        const getSlideIndexById = (slideId) => {
            const slides = document.querySelectorAll('.swiper-slide');
            return Array.from(slides).findIndex(slide => slide.id === slideId.substring(1));
        };

        const getTabBySlideIndex = (index) => {
            const slides = document.querySelectorAll('.swiper-slide');
            const slideId = slides[index]?.id;
            if (!slideId) return null;

            return Array.from(tabs).find(tab => tab.dataset.slide === `#${slideId}`);
        };

        const updateTabStates = (activeTab) => {
            tabs.forEach(tab => {
                const isActive = tab === activeTab;
                tab.classList.toggle('active', isActive);
                tab.setAttribute('aria-selected', isActive.toString());
            });

            legalsForSlide(activeTab.dataset.slide)
        };

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                if (tab.classList.contains('inactive')) return;
                updateTabStates(tab);

                const slideId = tab.dataset.slide;
                const slideIndex = getSlideIndexById(slideId);

                if (slideIndex !== -1) {
                    swiper.slideTo(slideIndex);
                }

                console.log(tab.getAttribute("data-slide"));

                var dataslide = tab.getAttribute("data-slide");

                // Modificar los valores que tenemos para el caso Fijo
                //Comprobar que el que esta seleccionado es fijo y entonces el mortgageTerm no puede ser menor que 10
                const slider = document.getElementById("MortgageHouseDurationRangeSlider");
                const rangeInput = slider.querySelector(".range-slider__input");
                const minText = slider.querySelector(".range-slider__legend-start .bodycopy-xs");
                const noUiSliderInstance = slider.querySelector(".noUi-target").noUiSlider;

                if (dataslide.includes("Fixed")) {
                    rangeInput.setAttribute("min", "10");
                    minText.textContent = "10 años";

                    noUiSliderInstance.updateOptions({
                        range: {
                            min: 10,
                            max: 30
                        }
                    });


                    if (parseInt(rangeInput.value) < 10) {
                        rangeInput.value = 10;
                    }
                } else {
                    rangeInput.setAttribute("min", "7");
                    minText.textContent = "7 años";

                    noUiSliderInstance.updateOptions({
                        range: {
                            min: 7,
                            max: 30
                        }
                    });

                }
            });
        });
    };

    async function ReloadData() {
        const cardResult = document.querySelector('.card-result');
        try {
            console.log("reload data");
            createHoldersObject();
            cardResult.classList.add('fade-out');
            const result = await evaluate();
            if (result) {
                ShowErrorGlobal(false);
                results.style.display = 'block';
                if (shouldShowMobileResults) {
                    resultsMobile.style.visibility = 'visible';
                }
            } else {
                ShowErrorGlobal(true);
                results.style.display = 'none';
                resultsMobile.style.visibility = 'hidden';
            }

            // Guardar el índice activo de cada slider
            const activeIndices = [];
            document.querySelectorAll('.card-result-payment-swiper .swiper-container').forEach((slider, index) => {
                const swiperInstance = slider.swiper; // Acceder a la instancia de Swiper
                if (swiperInstance) {
                    activeIndices[index] = swiperInstance.activeIndex;
                }
            });

            //Obtener el tab que esta seleccionado y dejar seleccionado en el swipper
            const activeButtons = Array.from(document.querySelectorAll('.menu-tab-button'))
                .filter(button => button.classList.contains('active'));

            const tabIndexes = activeButtons.map(button => button.getAttribute('tabindex'));

            console.log("tab seleccionada: " + tabIndexes);



            // Reconfigurar los sliders
            const swiperInstances = [];
            document.querySelectorAll('.card-result-payment-swiper .swiper-container').forEach((slider, index) => {
                const swiper = new Swiper(slider, {
                    slidesPerView: "auto",
                    effect: slider.dataset.effect || 'swipe',
                    allowTouchMove: false,
                    autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
                    initialSlide: tabIndexes,
                    navigation: {
                        nextEl: slider.querySelector('.swiper-button-next'),
                        prevEl: slider.querySelector('.swiper-button-prev'),
                    },
                    on: {
                        slideChange: function () {
                            if (isMobile) {
                                if (slider.closest('#results-mobile')) {
                                    const activeSlide = this.slides[this.activeIndex].id;
                                    const tab = document.querySelector(`.menu-tab-button:not(.active)[data-slide="#${activeSlide}"]`);
                                    if (tab) {
                                        tab.click();
                                    }
                                }

                                if (slider.closest('#results')) {
                                    const otherSwiperIndex = index === 0 ? 1 : 0;
                                    if (swiperInstances[otherSwiperIndex] && swiperInstances[otherSwiperIndex].activeIndex !== this.activeIndex) {
                                        swiperInstances[otherSwiperIndex].slideTo(this.activeIndex, 0, false);
                                    }
                                }
                            }
                        }
                    },
                });
                swiperInstances.push(swiper);
                if (slider.closest('#results')) {
                    handleTabs(swiper);
                }

            });

            //Validations
            Validations();



        } catch (error) {
            ShowErrorGlobal(true);
            results.style.display = 'none';
            resultsMobile.style.visibility = 'hidden';
            console.error("Error during evaluation:", error);
        }
        finally {
            /*results.style.display = 'block';
            if (shouldShowMobileResults) {
                resultsMobile.style.visibility = 'visible';
            }*/
            cardResult.classList.remove('fade-out');
        }
    }

    ReloadData();

    // Elimina todos los items de localStorage cuando la página se recarga
    window.addEventListener('beforeunload', function () {
        localStorage.removeItem("selectedAnhosMixed");
        // Guardar los datos cuando el usuario va a salir o recargar la página

    });


    // Función para guardar el formulario completo en localStorage
    function saveFormData() {
        const form = document.querySelector('form');
        const formData = new FormData(form);
        const formObject = {};

        // Guardar campos normales
        formData.forEach((value, key) => {
            if (key !== 'recaptcha') {
                formObject[key] = value;
            }
        });

        // Guardar valores de los access-select (value y texto)
        const accessSelects = form.querySelectorAll('.access-select');
        accessSelects.forEach((select, index) => {
            const checkedInput = select.querySelector('input[type="radio"]:checked');
            const visibleTextEl = select.querySelector('.access-select__chosen-option');

            if (checkedInput && checkedInput.name) {
                // Guardar el value
                formObject[checkedInput.name] = checkedInput.value;

                // Guardar el texto visible
                if (visibleTextEl) {
                    formObject[`${checkedInput.name}_text`] = visibleTextEl.textContent.trim();
                }

                // Guardar data-province si existe (para casos como provincias)
                if (checkedInput.dataset.province) {
                    formObject[`${checkedInput.name}_province`] = checkedInput.dataset.province;
                }
            }
        });

        localStorage.setItem('formData', JSON.stringify(formObject));
    }


    // Función para cargar los datos guardados en el formulario
    function loadFormData() {
        const savedData = localStorage.getItem('formData');
        if (!savedData) return;

        const formObject = JSON.parse(savedData);

        for (const [key, value] of Object.entries(formObject)) {
            if (key.endsWith('_text') || key.endsWith('_province')) continue;

            const inputs = document.querySelectorAll(`[name="${key}"]`);

            if (inputs.length === 1) {
                const input = inputs[0];
                if (input.type === 'radio' || input.type === 'checkbox') {
                    if (input.value === value) {
                        input.checked = true;
                        input.dispatchEvent(new Event('change'));
                    }
                } else {
                    input.value = value;
                }
            } else if (inputs.length > 1) {
                const provinceKey = `${key}_province`;
                const targetProvince = formObject[provinceKey];

                let targetInput = null;

                // Si tiene data-province guardado, buscar por eso (más específico)
                if (targetProvince) {
                    inputs.forEach(input => {
                        if (input.dataset.province === targetProvince) {
                            targetInput = input;
                        }
                    });
                }

                // Fallback: buscar por value si no hay province
                if (!targetInput) {
                    inputs.forEach(input => {
                        if (input.value === value) {
                            targetInput = input;
                        }
                    });
                }

                if (targetInput) {
                    targetInput.checked = true;
                    const parentSelect = targetInput.closest('.access-select');
                    const chosenOption = parentSelect?.querySelector('.access-select__chosen-option');
                    const hiddenInput = parentSelect?.querySelector('.access-select__chosen-option_hidden');

                    if (chosenOption && targetInput.title) {
                        chosenOption.textContent = targetInput.title;
                    }
                    if (hiddenInput) {
                        hiddenInput.value = targetInput.value;
                    }
                }
            }
        }
    }
}

export default mortgagePaymentCalculator;
