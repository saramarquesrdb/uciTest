import pagination from '../../Helpers/jsPagination';
import scrollTo from '../../Helpers/scrollTo';
import accordion from '../../Common/accordion';
import fanditData from './fandit.json';
import provinces from './provinces.json';

const subsidyFinder = component => {
  // Read-Store-Delete goals data from data attribute @ component wrapper
  const goals = JSON.parse(component.dataset.goals);
  component.removeAttribute('data-goals');

  // GeoLocationService obtained province
  const province = component.dataset.province;
  component.removeAttribute('data-province');
  const defaultProvinces = province ? provinces.find(x => x.code == province.slice(0, 2))?.ids : [];

  // Fallback Profiles || Defined in US-5453
  const fallbackProfiles = component.dataset.profile ? JSON.parse(component.dataset.profile) : [];
  component.removeAttribute('data-profile');

  // No results text
  const noResultsElement = component.querySelector('.no-results-default');
  const noResultsText = noResultsElement.innerHTML;
  noResultsElement.remove();

  const triggeredGoals = [];
  const registerGoal = goal => {
    if (!triggeredGoals.includes(goal)) {
      fetch(`${window.location.origin}/goals/register?goalId={${goal}}`, {
        method: 'POST'
      });

      triggeredGoals.push(goal);
    }
  };

  // Retrieve fandit data to populate form dropdowns
  // const fanditData = await fetch('https://api.fandit.es/api/v1/fund-data-filters/?format=json').then(response => response.json());

  // Populate the provinces dropdown
  const provincesList = component.querySelector('.province ul.access-select__list');
  if (provincesList && fanditData.provinces) {
    fanditData.provinces.forEach(province => {
      const li = document.createElement('li');
      li.classList.add('access-select__item');
      li.innerHTML = `
           <input class="access-select__option access-select__input" id="province-${province.id}" type="radio" title="${province.name}" name="province" value="${province.id}">
           <label class="access-select__option access-select__label" for="province-${province.id}">${province.name}</label>
      `;

      li.addEventListener('click', () => {
        registerGoal(goals.ProvinceSelected);
      });

      provincesList.appendChild(li);
    });

    if (defaultProvinces.length > 0) {
      const provincesInput = component.querySelector('li.province #subsidyFinder-province');
      provincesInput.value = defaultProvinces[0];
      provincesInput.classList.add('valid');

      const provincesInputLabel = component.querySelector('li.province .access-select__option.access-select__chosen-option');
      provincesInputLabel.innerHTML = fanditData.provinces.find(x => x.id == defaultProvinces[0]).name;
    }
  }

  // Populate the profiles dropdown
  const profilesList = component.querySelector('.profile ul.access-select__list');
  if (profilesList && fanditData.applicants) {
    fanditData.applicants.forEach(profile => {
      const li = document.createElement('li');
      li.classList.add('access-select__item');
      li.innerHTML = `
           <input class="access-select__option access-select__input" id="profile-${profile.id}" type="radio" title="${profile.name}" name="profile" value="${profile.id}">
           <label class="access-select__option access-select__label" for="profile-${profile.id}">${profile.name}</label>
      `;

      li.addEventListener('click', () => {
        registerGoal(goals.ProfileSelected);
      });

      profilesList.appendChild(li);
    });
  }

  // Populate the subsidy types dropdown
  const subsidyTypeList = component.querySelector('.subsidy-type .checkbox-group ul.column');
  if (subsidyTypeList && fanditData.credits) {
    fanditData.credits.forEach(subsidyType => {
      const li = document.createElement('li');
      li.classList.add('checkbox-group__item');
      li.innerHTML = `
        <div class="checkbox">
          <input class="checkbox-input subsidyType" id="subsidy-type-${subsidyType.id}" type="checkbox" name="${subsidyType.name}" title="${subsidyType.name}" value="${subsidyType.id}">
          <svg class='icon icon-icon-check'>
            <use xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='/dist/icons/icons.svg#icon-check'></use>
          </svg>
          <label class="checkbox-label" for="subsidy-type-${subsidyType.id}">
              <div class="caption-placeholder-m">${subsidyType.name}</div>
          </label>
        </div>
      `;

      li.addEventListener('click', () => {
        registerGoal(goals.SubsidyTypeSelected);
      });

      subsidyTypeList.appendChild(li);
    });
  }

  // Define LoadResults method
  const loadResults = (results, start) => {
    const accordionList = component.querySelector('ol.accordion__list');
    accordionList.setAttribute('start', start ? start + 1 : 1);
    if (accordionList) {
      accordionList.innerHTML = '';
      results.forEach(result => {
        const item = `
        <button class="accordion__trigger accordion__trigger-subsidy" type="button">
        <div class="bodycopy-l">${result.cleaned_title}</div>
     </button>
     <div class="accordion__item-content accordion__item-content-subsidy">
        <div class="row">
           <div class="col-xs-10 col-ms-10 col-sm-12 col-lg-12 col">
              <div class="accordion__item-content-wrapper">
                 <div class="accordion__item-description">
                    <div class="subsidy-result">
                       <div class="subsidy-result__deadline">
                          <svg class="icon icon-plazo-uci ">
                             <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                xlink:href="/dist/icons/icons.svg#plazo-uci"></use>
                          </svg>
                          <div class="bodycopy-m">
                             Plazo:
                          </div>
                          <div class="bodycopy-m">
                             ${result.status_text}
                          </div>
                       </div>
                       <ul class="subsidy-result__data">
                          <li>
                             <svg class="icon icon-ambito-geografico-uci">
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                   xlink:href="/dist/icons/icons.svg#ambito-geografico-uci"></use>
                             </svg>
                             <div class="bodycopy-m">
                                Ámbito geográfico:
                             </div>
                             <div class="bodycopy-m">
                                ${result.region_type}
                             </div>
                          </li>
                          <li>
                             <svg class="icon icon-arrow-top-uci ">
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                   xlink:href="/dist/icons/icons.svg#arrow-top-uci"></use>
                             </svg>
                             <div class="bodycopy-m">
                                Cuantía máxima:
                             </div>
                             <div class="bodycopy-m">
                                ${result.request_amount.toLocaleString('es-ES')}€
                             </div>
                          </li>
                          <li>
                             <svg class="icon icon-presupuesto-uci ">
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                   xlink:href="/dist/icons/icons.svg#presupuesto-uci"></use>
                             </svg>
                             <div class="bodycopy-m">
                                Presupuesto:
                             </div>
                             <div class="bodycopy-m">
                                ${result.total_amount.toLocaleString('es-ES')}€
                             </div>
                          </li>
                          <li>
                             <svg class="icon icon-arrow-down-uci ">
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                   xlink:href="/dist/icons/icons.svg#arrow-down-uci"></use>
                             </svg>
                             <div class="bodycopy-m">
                                Presupuesto mínimo:
                             </div>
                             <div class="bodycopy-m">
                                ${result.min_budget.toLocaleString('es-ES')}€
                             </div>
                          </li>
                       </ul>
                       ${(result.link || result.pdf_file) ?
            `
                        <div class="subsidy-result__links ${result.link || result.pdf_file ? '' : 'hidden'}">
                          ${(result.link) ?
              `
                            <a class="link" href="${result.link}" target="_blank">
                              <span>Más información</span>
                            </a>
                            ` :
              ''
            }
                          ${(result.pdf_file) ?
              `
                            <a class="link" href="${result.pdf_file}" target="_blank">
                              <span>Más información (PDF)</span>
                            </a>
                            ` :
              ''
            }
                        </div>
                        ` :
            ''
          }
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
          `;
        const li = document.createElement('li');
        li.classList.add('accordion__item');
        li.innerHTML = item;

        li.addEventListener('click', () => {
          registerGoal(goals.SubsidyClick);
        });

        accordionList.appendChild(li);
      });

      accordionList.firstElementChild.firstElementChild.classList.add('active');
      accordion('accordion-subsidy', 'accordion__trigger-subsidy', 'accordion__item-content-subsidy');
    }
  };

  const setState = (isLoading, hasResults, loadingPage) => {
    if (isLoading) {
      component.querySelector('button[type=submit]').setAttribute('disabled', 'disabled');
      component.querySelector('.subsidy-finder__preloader').classList.remove('hidden');
      component.querySelector('.subsidy-finder > .row').classList.remove('aling-items');
      if (loadingPage) {
        component.querySelector('.subsidy-finder__results').style.opacity = '0.2';
      } else {
        component.querySelector('.subsidy-finder__results').classList.add('hidden');
        component.querySelector('.subsidy-finder__notfound').classList.add('hidden');
      }
    } else {
      component.querySelector('.subsidy-finder__preloader').classList.add('hidden');
      component.querySelector('button[type=submit]').removeAttribute('disabled');
      component.querySelector('.subsidy-finder__results').style.opacity = '1';

      if (hasResults) {
        component.querySelector('.subsidy-finder__results').classList.remove('hidden');
        component.querySelector('.subsidy-finder__notfound').classList.add('hidden');
        component.querySelector('.subsidy-finder > .row').classList.remove('aling-items');
      } else {
        component.querySelector('.subsidy-finder__results').classList.add('hidden');
        component.querySelector('.subsidy-finder__notfound').classList.remove('hidden');
        component.querySelector('.subsidy-finder > .row').classList.add('aling-items');
      }
    }
  };

  let eventListenersLoaded = false;
  let submissions = 0;

  // Handle the form submission
  const form = component.querySelector('form');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      if (submissions > 0) {
        component.querySelector('.subsidy-finder__notfound .no-results').innerHTML = noResultsText;
      }

      setState(true, false, false);

      registerGoal(goals.Search);

      const fanditUrl = 'https://subvencionator.api.fandit.es/api/v1/fund-list';

      const defaultProfiles = component.querySelector('#subsidyFinder-profile') ? [] : fallbackProfiles;

      const formData = {
        searchByText: component.querySelector('#subsidyFinder-keywords')?.value ?? null,
        provinces: component.querySelector('#subsidyFinder-province')?.value ? [parseInt(component.querySelector('#subsidyFinder-province').value, 10)] : defaultProvinces,
        applicants: component.querySelector('#subsidyFinder-profile')?.value ? [parseInt(component.querySelector('#subsidyFinder-profile').value, 10)] : defaultProfiles,
        creditTypes: Array.from(component.querySelectorAll('.subsidy-type .checkbox:checked')).map(x => parseInt(x.value, 10)),
      };

      // Complete requestData object as expected by fandit
      const requestData = {
        format: 'json',
        page: 1,
        applicants: formData.applicants,
        provinces: formData.provinces,
        communities: [],
        actions: [],
        activities: [],
        region_types: [],
        types: formData.creditTypes,
        max_budget: null,
        max_total_amount: null,
        min_total_amount: null,
        search_by_text: formData.searchByText,
        office: '',
        bdns: null,
        is_open: true,
        date_range: '',
        start_date: null,
        end_date: null,
        reviewed: null,
        final_period_end_date: null,
        final_period_start_date: (new Date()).toISOString().split('T')[0]
      };

      // Build the final URL
      const requestUrl = `${fanditUrl}?page=1&requestData=${encodeURI(JSON.stringify(requestData))}`;

      // Fetch results
      const results = await fetch(requestUrl).then(response => response.json());
      if (results.count > 0) {
        // set title
        const title = component.querySelector('.subsidy-finder__results h2');
        if (title) {
          title.innerHTML = `${results.count} resultados`;

          const selectedProvince = component.querySelector('li.province .access-select__option.access-select__chosen-option').innerText;
          if (selectedProvince) {
            title.innerHTML = `${title.innerHTML} en ${selectedProvince}`
          }
        }

        // load results
        loadResults(results.results);

        // load pagination
        const paginationElement = component.querySelector('.pagination');

        if (paginationElement) {
          const itemsPerPage = 20; // Set by fandit
          const totalPages = Math.ceil(results.count / itemsPerPage);

          pagination(paginationElement, 1, totalPages, eventListenersLoaded);

          const paginationElementEventHandler = async customEvent => {
            const header = document.querySelector('header') ?? document.querySelector('.landing-header')
            if (header) {
              scrollTo(component, 300, header.offsetHeight);
            }
            setState(true, true, true);
            const target = customEvent.detail;
            const requestPageUrl = `${fanditUrl}?page=${target}&requestData=${encodeURI(JSON.stringify(requestData))}`;
            const pageResults = await fetch(requestPageUrl).then(response => response.json());
            loadResults(pageResults.results, target * itemsPerPage - itemsPerPage);
            setState(false, true, false);
          };

          if (!eventListenersLoaded) {
            paginationElement.addEventListener('pageChange', paginationElementEventHandler);
          }
        }

        // show/hide with/without results views depending on results
        setState(false, true, false);
      } else {
        // show/hide with/without results views depending on results
        setState(false, false, false);
      }

      window.datalayerService.push({
        event: 'subsidyFinder',
        query_buscador: formData.searchByText,
        provincia: formData.provinces,
        perfil: formData.applicants,
        tipo_subvencion: formData.creditTypes,
        resultados: results.count > 0,
        resultados_cantidad: results.count
      })

      eventListenersLoaded = true;
      submissions++;
    });

  }

  const scrollHandler = () => {
    const windowHeight = window.innerHeight;
    const documentHeight = document.body.clientHeight;
    const scrollTop = window.scrollY;

    // Calculate the scroll percentage
    const scrollPercentage = (scrollTop / (documentHeight - windowHeight)) * 100;

    if (scrollPercentage >= 50) {
      registerGoal(goals.HalfScreenScroll);
    }

    if (scrollPercentage >= 100) {
      registerGoal(goals.FullScreenScroll);
    }
  };

  window.addEventListener('scroll', scrollHandler);

  if (defaultProvinces.length > 0) {
    component.querySelector('button.btn[type=submit]').click()
  }
};

export default subsidyFinder;
