import mockResponse from "./mockResponse"

class CalculatorApiClient {
    constructor() {
        this.baseURL = `${window.location.origin}/api/sitecore/CommunityCalculator`;
    }

    async calculate(request) {
        const url = new URL(`${this.baseURL}/CommunityCalculatorResult`);

        return await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(request),
        })
            .then(async (response) => {
                const result = await response.json();
                //const result = mockResponse
                if (result.errorMessages) { // Checks if the status code is not in the range 200-299
                    throw result;
                }

                console.log(result);
                return result;
            })
            .catch((error) => {
                //console.error('Error:', error);
                throw error;
            });
    }

    async requestPdf(request) {
        const url = new URL(`${this.baseURL}/CommunityCalculatorPdfRequest`);
        console.log(request);

        return await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(request),
        })
            .then(async (response) => {
                if (!response.ok) {
                    // Si la respuesta no es correcta, obtenemos el mensaje de error
                    const errorText = await response.text();
                    throw new Error(`Error al solicitar el PDF: ${errorText}`);
                }
                // Convertimos la respuesta a un Blob (PDF)
                return await response.blob();
            })
            .catch((error) => {
                throw error;
            });
    }

}

export default new CalculatorApiClient();