import regexValidate from "@/js/Common/regexValidate";
import selectValidate from "@/js/Common/selectValidate";

let hasAttemptedSubmit = false;

export const markSubmitAttempted = () => {
    hasAttemptedSubmit = true;
};

export const validatePdfForm = (pdfForm, fieldSelector) => {
    if (!hasAttemptedSubmit) {
        return checkFormValidity(pdfForm, true, fieldSelector);
    }

    return checkFormValidity(pdfForm, false, fieldSelector);
};

const checkFormValidity = (pdfForm, silentCheck, fieldSelector) => {
    const validations = [
        { field: 'input[name="name"]', regex: /^\s*([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]{1,}([.,] |[-']| )?)+[A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]+\.?\s*$/, parent: '.form-fieldset:has(input[name="name"])' },
        { field: 'input[name="lastname"]', regex: /^\s*([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]{1,}([.,] |[-']| )?)+[A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]+\.?\s*$/, parent: '.form-fieldset:has(input[name="lastname"])' },
        { field: 'input[name="email"]', regex: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, parent: '.form-fieldset:has(input[name="email"])' },
        { field: 'input[name="phone"]', regex: /^\d{5,}$/, parent: '.form-fieldset:has(input[name="phone"])' },
        { field: 'input[name="clientAddress"]', regex: /\S/, parent: '.form-fieldset:has(input[name="clientAddress"])' }
    ];

    if (fieldSelector !== undefined) {
        silentCheck = true;
    }

    if (silentCheck) {
        let isValid = true;
        var fieldValidation = validations.find(v => v.field === fieldSelector);
        const input = pdfForm.querySelector(fieldValidation.field);
        const parentElement = pdfForm.querySelector(fieldValidation.parent);
        const errorMessage = parentElement.querySelector(".error-message-text");
        const errorMessageLimit = parentElement.querySelector(".error-message-limit");

        if (input && !fieldValidation.regex.test(input.value)) {
            isValid = false;
            if (parentElement) {
                parentElement.classList.add("error");
                if (errorMessage) {
                    errorMessage.classList.remove("hidden");
                }
                if (errorMessageLimit) {
                    errorMessageLimit.classList.add("hidden");
                }
            }
        }
        else{
            if (parentElement) {
                const min = input.hasAttribute("data-min") ? parseInt(input.getAttribute("data-min"), 10) : null;
                const max = input.hasAttribute("data-max") ? parseInt(input.getAttribute("data-max"), 10) : null;
                const value = input.value.trim();

                if ((min !== null && value.length < min) || (max !== null && value.length > max)) {
                    parentElement.classList.add("error");
                    if (errorMessage) {
                        errorMessage.classList.add("hidden");
                    }
                    if (errorMessageLimit) {
                        errorMessageLimit.classList.remove("hidden");
                    }
                }
                else{
                    parentElement.classList.remove("error");
                }
            }
        }

        const prefixInput = pdfForm.querySelector('input[name="prefix"]');
        const provinceInput = pdfForm.querySelector('input[name="province"]');
        const positionInput = pdfForm.querySelector('input[name="communityPosition"]');

        if ((prefixInput && !prefixInput.value) ||
            (provinceInput && !provinceInput.value) ||
            (positionInput && !positionInput.value)) {
            isValid = false;
        }

        return isValid;
    }

    validations.forEach(v => {
        const input = pdfForm.querySelector(v.field);
        const parent = pdfForm.querySelector(v.parent);
        if (input && parent) {
            regexValidate(v.regex, input, parent);
        }
    });

    selectValidate(pdfForm.querySelector('input[name="prefix"]'), pdfForm.querySelector('.form-select:has(input[name="prefix"])'));
    selectValidate(pdfForm.querySelector('input[name="province"]'), pdfForm.querySelector('.form-select:has(input[name="province"])'));
    selectValidate(pdfForm.querySelector('input[name="communityPosition"]'), pdfForm.querySelector('.form-select:has(input[name="communityPosition"])'));

    if (pdfForm.querySelectorAll('.form-select.error, .form-fieldset.error').length === 0) {
        pdfForm.classList.add('valid');
        pdfForm.classList.remove('not-valid');
    } else {
        pdfForm.classList.remove('valid');
        pdfForm.classList.add('not-valid');
    }

    return pdfForm.querySelectorAll('.form-select.error, .form-fieldset.error').length === 0;
};

export const setupFieldValidation = (pdfForm) => {
    const fields = [
        'input[name="name"]',
        'input[name="lastname"]',
        'input[name="email"]',
        'input[name="phone"]',
        'input[name="clientAddress"]',
        'input[name="prefix"]',
        'input[name="province"]',
        'input[name="communityPosition"]'
    ];

    fields.forEach(selector => {
        const field = pdfForm.querySelector(selector);
        if (field) {
            field.addEventListener('change', () => validatePdfForm(pdfForm, selector));
            field.addEventListener('blur', () => validatePdfForm(pdfForm, selector));
        }
    });
};

export default {
    validatePdfForm,
    setupFieldValidation,
    markSubmitAttempted
};