import formValidator from "@/js/Common/forms/formValidator";
import rangeSlider from "@/js/Common/rangeSlider";
import { setAccessSelect } from "@/js/Helpers/_helpers";
import calculatorApiClient from "./calculatorApiClient";
import pdfFormValidator from "./pdfFormValidator";

const communityCalculator = (element) => {
    const form = element.querySelector('form#community-calculator-form');
    const preloader = document.querySelector("#communityCalculatorPreloaderContainer");
    const lightboxPdfFormHeader = document.querySelector("#community-calculator-pdf-form-lightbox-header");
    const lightboxPdfFormSuccessMessage = document.querySelector("#communityCalculatorSuccessContainer");
    const lightboxPdfFormFieldsContainer = document.querySelector("#community-calculator-pdf-form-container");
    const communityCalculatorPdfFormTrigger = document.querySelector("#communityCalculatorPdfFormTrigger");
    
    formValidator(form);

    const pdfForm = element.querySelector('form#community-calculator-pdf-form');
    pdfFormValidator.setupFieldValidation(pdfForm);

    if(communityCalculatorPdfFormTrigger){
        communityCalculatorPdfFormTrigger.addEventListener('click', () => {
            if (preloader) {
                preloader.style.display = "none";
            }
            if (pdfForm) {
                pdfForm.classList.remove("hidden");
            }
            if (lightboxPdfFormHeader) {
                lightboxPdfFormHeader.classList.remove("hidden");
            }
            if (lightboxPdfFormSuccessMessage) {
                lightboxPdfFormSuccessMessage.style.display = "none";
            }
        });
    }

    pdfForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        pdfFormValidator.markSubmitAttempted();
        if (!pdfFormValidator.validatePdfForm(pdfForm, undefined)) return;

        updatePdfFormInputs();
        const formData = new FormData(pdfForm);
        const request = Object.fromEntries(formData.entries());

        try {
            if (!pdfFormValidator.validatePdfForm(pdfForm, undefined)) return;
            if (preloader) {
                preloader.style.display = "flex";
            }
            if (pdfForm) {
                pdfForm.classList.add("hidden");
            }
            if (lightboxPdfFormHeader) {
                lightboxPdfFormHeader.classList.add("hidden");
            }

            const pdfBlob = await calculatorApiClient.requestPdf(request);
            // Crea una URL para el Blob y fuerza la descarga
            const blobUrl = URL.createObjectURL(pdfBlob);
            const a = document.createElement('a');
            a.href = blobUrl;
            a.download = 'UCI - Simulación préstamo comunidad.pdf';

            if (lightboxPdfFormFieldsContainer) {
                lightboxPdfFormFieldsContainer.appendChild(a);
            }

            clearPdfFormFields();
            if (preloader) {
                preloader.style.display = "none";
            }
            if (lightboxPdfFormSuccessMessage) {
                lightboxPdfFormSuccessMessage.style.display = "flex";
            }
            
            a.click();
            a.remove();
            URL.revokeObjectURL(blobUrl);

        } catch (error) {
            console.error("Error al generar el PDF", error);
        }
    })

    rangeSlider(
        '#loan-amount .range-slider__slider',
        '#loan-amount .range-slider__input',
    );

    const amortizationRangeSlider = rangeSlider(
        '#partial-amortization-amount .range-slider__slider',
        '#partial-amortization-amount .range-slider__input',
    );

    const getSelectedGracePeriod = () => {
        // Selecciona todos los inputs de tipo radio con el nombre "grace-period"
        const radios = document.querySelectorAll('input[name="grace-period"]');

        // Itera sobre los radios y verifica cuál está seleccionado
        let selectedValue;
        radios.forEach(radio => {
            if (radio.checked) {
                selectedValue = radio.value; // Guarda el valor del radio seleccionado
            }
        });

        // Retorna el valor seleccionado o null si no se encontró ninguno
        return selectedValue || null;
    }

    const getSelectedPartialAmortization = () => {
        // Selecciona todos los radios con el nombre "partial-amortization"
        const radios = document.querySelectorAll('input[name="partial-amortization"]');

        // Itera sobre los radios para encontrar el seleccionado
        for (const radio of radios) {
            if (radio.checked) {
                return radio.value === "1"; // Devuelve el valor del radio seleccionado
            }
        }

        return null; // Devuelve null si no hay ninguno seleccionado
    }

    //Load Comments
    const Comments = document.getElementById('CalculatorComments');
    const AddComments = () => {
        var apartmentsAmount = (document.querySelector('#apartments-amount')) ? "Cantidad de vecinos: " + document.querySelector('#apartments-amount').value : "";
        var carencia = "Carencia: " + getSelectedGracePeriod();
        var amortization = "Amortizacion: " + (getSelectedPartialAmortization() == 1 ? "SI" : "NO");
        var fechaAmortizacion = "Fecha Amortizacion: " + document.querySelector('input[name="year"]:checked').value + "-" + document.querySelector('input[name="month"]:checked').value;
        var importeAmortizacion = "Importe amortizacion: " + document.querySelector('input[name="partial-amortization-amount"]').value.replace(/\./g, '');
        var mortageTerm = "Periodo Hipoteca: " + loanDurationInput.value + " años. "
        if (Comments) Comments.value = apartmentsAmount + " " + carencia + " " + amortization + " " + fechaAmortizacion + " " + importeAmortizacion + " " + mortageTerm;
    }

    const today = new Date();
    setAccessSelect("#month .access-select", (today.getMonth() + 1).toString().padStart(2, '0'))
    setAccessSelect("#year .access-select", (today.getFullYear() + 3).toString())

    const baseGracePeriodLabel = document.querySelector('#grace-period-label').textContent;
    const baseBeforeAmortizationLabel = document.querySelector('#before-amortization-label').textContent;
    const baseOriginationFeeLabel = document.querySelector('#origination-fee-label').textContent;

    const loanAmountInput = element.querySelector('input[name="loan-amount"]');
    const propertyPurchasePriceInput = document.getElementById('PropertyPurchasePrice');

    const updateAmortizationRangeSlider = () => {
        amortizationRangeSlider.destroy();
        const formattedValue = loanAmountInput.value.replace(/\./g, '').replace(/,/g, '.');
        const cancellationLimit = element.querySelector('#partial-amortization-amount .range-slider__legend-end span');
        cancellationLimit.textContent = new Intl.NumberFormat('es-ES').format(parseFloat(formattedValue)) + " €";
        const cancellationInputText = element.querySelector('#partial-amortization-amount .range-slider__input');
        cancellationInputText.setAttribute('max', parseFloat(formattedValue));
        rangeSlider(
            '#partial-amortization-amount .range-slider__slider',
            '#partial-amortization-amount .range-slider__input',
        );
        if (propertyPurchasePriceInput) propertyPurchasePriceInput.value = loanAmountInput.value;

    }

    updateAmortizationRangeSlider();
    loanAmountInput.addEventListener('change', updateAmortizationRangeSlider);

    const partialAmortizationOptions = element.querySelectorAll('input[name="partial-amortization"]');
    partialAmortizationOptions.forEach(radio => {
        radio.addEventListener('change', event => {
            element.querySelectorAll('.partial-amortization').forEach(el => {
                el.classList.toggle('hidden', event.target.value === '0');
            });


        });
    });

    const loanDurationInput = element.querySelector('input[name="loan-duration"]');
    const mortgageTerm = document.getElementById('MortgageTerm');

    loanDurationInput.addEventListener('change', () => {
        element.querySelectorAll('#year .access-select__item').forEach((item, index) => {
            item.classList.toggle('hidden', index > loanDurationInput.value)
        });
        if (mortgageTerm) mortgageTerm.value = loanDurationInput.value;

    });

    const apartmentAmountInput = element.querySelector('input[name="apartments-amount"]');

    apartmentAmountInput.addEventListener('blur', () => {
        const inputs = document.querySelectorAll(".NumberOfOwners");
        inputs.forEach(i => {
            i.value = apartmentAmountInput.value;
        });
    });

    const gracePeriodOptions = element.querySelectorAll('input[name="grace-period"]');
    const maxDuration = parseInt(loanDurationInput.getAttribute('data-max'));
    let previousMaxDuration = maxDuration;
    gracePeriodOptions.forEach(radio => {
        radio.addEventListener('change', event => {
            const loanDurationInputErrorText = loanDurationInput.closest('.form-input').querySelector('.field-bottom__error-message .error-message');
            const loanDurationInputHelperText = loanDurationInput.closest('.form-input').querySelector('.field-bottom__helper-text .bodycopy-xs');

            switch (event.target.value) {
                case "0":
                    loanDurationInput.setAttribute('data-max', maxDuration);
                    loanDurationInputErrorText.textContent = loanDurationInputErrorText.textContent.replace(`${previousMaxDuration}`, `${maxDuration}`);
                    loanDurationInputHelperText.textContent = loanDurationInputHelperText.textContent.replace(`${previousMaxDuration}`, `${maxDuration}`);
                    previousMaxDuration = maxDuration;
                    break;
                case "1":
                    loanDurationInput.setAttribute('data-max', maxDuration + 1);
                    loanDurationInputErrorText.textContent = loanDurationInputErrorText.textContent.replace(`${previousMaxDuration}`, `${maxDuration + 1}`);
                    loanDurationInputHelperText.textContent = loanDurationInputHelperText.textContent.replace(`${previousMaxDuration}`, `${maxDuration + 1}`);
                    previousMaxDuration = maxDuration + 1;
                    break;
                case "2":
                    loanDurationInput.setAttribute('data-max', maxDuration + 2);
                    loanDurationInputErrorText.textContent = loanDurationInputErrorText.textContent.replace(`${previousMaxDuration}`, `${maxDuration + 2}`);
                    loanDurationInputHelperText.textContent = loanDurationInputHelperText.textContent.replace(`${previousMaxDuration}`, `${maxDuration + 2}`);
                    previousMaxDuration = maxDuration + 2;
                    break;
                default:
                    break;
            }

        });
    });

    const evaluate = async () => {
        if (!form.classList.contains('valid')) return;

        let data = {
            loanAmount: +(element.querySelector('input[name="loan-amount"]').value.replace(/\./g, '')),
            transactionAmount: +(element.querySelector('#total-amount').innerHTML.replace(/\./g, '')),
            houseNumber: +element.querySelector('input[name="apartments-amount"]').value,
            loanYears: +element.querySelector('input[name="loan-duration"]').value,
            gracePeriodYears: +element.querySelector('input[name="grace-period"]:checked').value,
            hasAmortize: false,
            amortizeDate: null,
            amortizeAmount: null,
            language: 'es-ES'
        }

        const hasAmortize = element.querySelector('input[name="partial-amortization"]:checked').value == 1;
        if (hasAmortize) {
            data = {
                ...data,
                hasAmortize,
                amortizeDate: `${element.querySelector('input[name="year"]:checked').value}-${element.querySelector('input[name="month"]:checked').value}-01`,
                amortizeAmount: +(element.querySelector('input[name="partial-amortization-amount"]').value.replace(/\./g, '')),
            }
        }

        const cardResult = document.querySelector('.card-result');
        cardResult.classList.add('fade-out');
        await calculatorApiClient.calculate(data)
            .then((result) => {
                document.querySelector('#errors').style.display = 'none';
                document.querySelector('#results').style.display = 'flex';
                loadResult(data, result);
                window.datalayerService.sendCustomEvent('simcalc_prestamo_comunidad_vecinos', result)
            })
            .catch((error) => {
                document.querySelector('#errors').style.display = 'flex';
                document.querySelector('#results').style.display = 'none';
                document.querySelector('#errors .error-list').innerHTML = '';
                error.errorMessages.forEach(errorMessage => {
                    const li = document.createElement('li');
                    const div = document.createElement('div');
                    div.classList.add('bodycopy-m');
                    div.textContent = errorMessage;
                    li.appendChild(div);
                    document.querySelector('#errors .error-list').appendChild(li);
                });
                document.querySelector('#legal').innerHTML = '';
            })
            .finally(() => {
                cardResult.classList.remove('fade-out');
            })
    }

    const loadResult = (data, result) => {
        document.querySelector('#initial').classList.toggle('hidden', data.gracePeriodYears > 0);
        document.querySelector('#grace-period-result').classList.toggle('hidden', data.gracePeriodYears == 0);
        document.querySelector('#after-grace-period-result').classList.toggle('hidden', data.gracePeriodYears == 0);
        document.querySelector('#after-amortization-result').classList.toggle('hidden', !data.hasAmortize);
        document.querySelector('#after-grace-period-label').style.display = !result.MonthsUntilAmortize ? 'inline' : 'none';
        document.querySelector('#after-grace-period-tooltip').style.display = !result.MonthsUntilAmortize ? 'inline' : 'none';
        document.querySelector('#before-amortization-label').style.display = result.MonthsUntilAmortize ? 'inline' : 'none';
        document.querySelector('#before-amortization-tooltip').style.display = result.MonthsUntilAmortize ? 'inline' : 'none';
        document.querySelector('#base-payment-neighbor').innerHTML = `${result.MonthlyAmountByNeighbor}`;
        document.querySelector('#base-payment-community').innerHTML = `${result.MonthlyAmount}`;
        document.querySelector('#grace-period-label').textContent = baseGracePeriodLabel.replace('XX', data.gracePeriodYears * 12)
        document.querySelector('#grace-period-result-neighbor').innerHTML = `${result.MonthlyAmountGracePeriodByNeighbor}`;
        document.querySelector('#grace-period-result-community').innerHTML = `${result.MonthlyAmountGracePeriod}`;
        document.querySelector('#after-grace-period-result-neighbor').innerHTML = `${result.MonthlyAmountAfterGracePeriodByNeighbor}`;
        document.querySelector('#after-grace-period-result-community').innerHTML = `${result.MonthlyAmountAfterGracePeriod}`;
        document.querySelector('#before-amortization-label').textContent = baseBeforeAmortizationLabel.replace('XX', result.MonthsUntilAmortize)
        document.querySelector('#after-amortization-result-neighbor').innerHTML = `${result.MonthlyAmountAfterAmortizeByNeighbor}`;
        document.querySelector('#after-amortization-result-community').innerHTML = `${result.MonthlyAmountAfterAmortize}`;
        document.querySelector('#tae').innerHTML = `${result.Tae}%`;
        document.querySelector('#tin').innerHTML = `${result.Tin}%`;
        document.querySelector('#origination-fee-label').textContent = baseOriginationFeeLabel.replace('XX', result.OpeningCommission)
        document.querySelector('#origination-fee').innerHTML = `${result.OpeningCommissionAmount}€`;
        document.querySelector('#amortization-fee').innerHTML = `${result.AmortizeCommissionAmount}€`;
        document.querySelector('#total-amount').innerHTML = `${result.AmountFinanced}€`;
        document.querySelector('#other-fees').classList.toggle('hidden', result.AmortizeCommissionAmount === null);
        document.querySelector('#other-fees').classList.toggle('card-result__additional2', result.AmortizeCommissionAmount !== null);
        document.querySelector('#legal').innerHTML = result.LegalText;
    }

    const updatePdfFormInputs = () => {
        document.getElementById('pdfHouseAmount').value = document.querySelector('#apartments-amount').value;
        document.getElementById('pdfGIdCommunityCalculator').value = document.querySelector('#gIdCommunityCalculator').value;
        document.getElementById('pdfLoanAmount').value = document.querySelector('input[name="loan-amount"]').value.replace(/\./g, '');
        document.getElementById('pdfTransactionAmount').value = document.querySelector('#total-amount').innerHTML.replace(/\./g, '').replace(/\,/g, '.').replace(/\€/g, '');
        document.getElementById('pdfLoanYears').value = document.querySelector('input[name="loan-duration"]').value;
        document.getElementById('pdfGracePeriodYears').value = getSelectedGracePeriod();
        document.getElementById('pdfAmortize').value = getSelectedPartialAmortization();
        document.getElementById('pdfAmortizeDate').value = `${document.querySelector('input[name="year"]:checked').value}-${document.querySelector('input[name="month"]:checked').value}-01`;
        document.getElementById('pdfAmortizeAmount').value = document.querySelector('input[name="partial-amortization-amount"]').value.replace(/\./g, '');
    };

    const clearPdfFormFields = () => {
        document.querySelector('input[name="name"]').value = "";
        document.querySelector('input[name="lastname"]').value = "";
        document.querySelector('input[name="email"]').value = "";
        document.querySelector('input[name="phone"]').value = "";
        document.querySelector('input[name="clientAddress"]').value = "";
    }

    let hasPageLoaded = false;

    // Ejecutar esta función cuando la página esté completamente cargada
    window.addEventListener('load', () => {
        hasPageLoaded = true;
    });

    form.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', () => {
            setTimeout(evaluate, 100)
            if (hasPageLoaded) {
                AddComments();
            }
        }); // waits for 100ms so that the validation takes place before submitting
    });

    evaluate().then(() => {
        document.querySelector('#calculator-form-result').classList.remove('hidden');
        updatePdfFormInputs();
    });
}

export default communityCalculator;
