import scrollTo from '../../Helpers/scrollTo';
import getClosestElement from '../../Helpers/getClosestElement';

const resourcesCenter = el => {
  const paginationWrapper = el.querySelector('.pagination');
  const paginationElement = el.querySelector('.pagination__list');
  const pageSize = parseInt(paginationElement.dataset.pageSize, 0);
  let pages = parseInt(paginationElement.dataset.pages, 0);
  let page = parseInt(paginationElement.dataset.page, 0);
  let category;
  let filter;

  let distributorLimit = 4;
  const distributorSeeMore = el.querySelector('#resources-distributor-see-more-button');
  const categories = Array.from(el.querySelectorAll('.distributor-card'));
  const handleDistributor = () => {
    for (let i = 0; i < categories.length; i++) {
      categories[i].style.display = (i < distributorLimit) ? 'flex' : 'none';
    }

    if (categories.length > 4) {
      distributorSeeMore.innerHTML =
        (distributorLimit >= categories.length) ?
          distributorSeeMore.dataset.seeLess :
          distributorSeeMore.dataset.seeMore;
    } else {
      el.querySelector('.resources__footer').style.display = 'none';
    }
  };

  const handlePagination = noscroll => {
    el.querySelectorAll('.resources-card').forEach(card => {
      card.parentNode.style.display = 'none';
    });

    let index = 1;
    let taken = 0;
    el.querySelectorAll(`.resources-card${filter ?? ''}`).forEach(card => {
      if ((index > pageSize * (page - 1)) && taken < pageSize) {
        card.parentNode.style.display = 'block';
        taken++;
      }

      index++;
    });

    if (noscroll !== true) {
      scrollTo(document.querySelector('.resources-center'), 500, document.querySelector('header').offsetHeight);
    }

    el.querySelectorAll('.pagination__item').forEach(item => { item.classList.remove('active'); });

    const paginationElements = Array.from(el.querySelectorAll('li[class*=pagination-]'));

    paginationElements[0].style.visibility = (page === 1) ? 'hidden' : 'visible';
    if (page === 1) paginationElements[1].classList.add('active');
    paginationElements[2].style.display = (pages > 4 && page > 3) ? 'block' : 'none';

    if (pages === 2) {
      paginationElements[3].style.display = 'none';
      paginationElements[4].style.display = 'none';
      paginationElements[5].style.display = 'none';
    }

    if (pages === 3) {
      paginationElements[3].style.display = 'block';
      paginationElements[3].querySelector('.pagination__link').innerHTML = 2;
      if (page === 2) paginationElements[3].classList.add('active');
      paginationElements[4].style.display = 'none';
      paginationElements[5].style.display = 'none';
    }

    if (pages === 4) {
      paginationElements[3].style.display = 'block';
      paginationElements[3].querySelector('.pagination__link').innerHTML = 2;
      if (page === 2) paginationElements[3].classList.add('active');
      paginationElements[4].style.display = 'block';
      paginationElements[4].querySelector('.pagination__link').innerHTML = 3;
      if (page === 3) paginationElements[4].classList.add('active');
      paginationElements[5].style.display = 'none';
    }

    if (pages > 4) {
      if (page === 1 || page === 2) {
        paginationElements[3].style.display = 'block';
        paginationElements[3].querySelector('.pagination__link').innerHTML = 2;
        if (page === 2) paginationElements[3].classList.add('active');
        paginationElements[4].style.display = 'block';
        paginationElements[4].querySelector('.pagination__link').innerHTML = 3;
        if (page === 3) paginationElements[4].classList.add('active');
        paginationElements[5].style.display = 'none';
      } else if (page === pages || page === (pages - 1)) {
        paginationElements[3].style.display = 'block';
        paginationElements[3].querySelector('.pagination__link').innerHTML = pages - 2;
        paginationElements[4].style.display = 'block';
        paginationElements[4].querySelector('.pagination__link').innerHTML = pages - 1;
        if (page === pages - 1) paginationElements[4].classList.add('active');
        paginationElements[5].style.display = 'none';
      } else {
        paginationElements[3].style.display = 'block';
        paginationElements[3].querySelector('.pagination__link').innerHTML = page - 1;
        paginationElements[4].style.display = 'block';
        paginationElements[4].querySelector('.pagination__link').innerHTML = page;
        paginationElements[4].classList.add('active');
        paginationElements[5].style.display = 'block';
        paginationElements[5].querySelector('.pagination__link').innerHTML = page + 1;
      }
    }

    paginationElements[6].style.display = (pages > 4 && (pages - page > 2)) ? 'block' : 'none';
    if (page === pages) paginationElements[7].classList.add('active');
    paginationElements[7].querySelector('.pagination__link').innerHTML = pages;
    paginationElements[8].style.visibility = (page !== pages) ? 'visible' : 'hidden';

    if (pages > 1) {
      paginationWrapper.style.display = 'flex';
    } else {
      paginationWrapper.style.display = 'none';
    }
  };

  const handleFilter = selectedCategory => {
    if (selectedCategory) {
      category = selectedCategory;
      filter = `[data-category*="${category}"]`;
      el.querySelector('.resources-center__resultsText').style.display = 'block';
    } else {
      category = undefined;
      filter = undefined;
      el.querySelector('.resources-center__resultsText').style.display = 'none';
    }

    el.querySelector('.category-holder').innerHTML = category;
    const count = el.querySelectorAll(`.resources-card${filter ?? ''}`).length;
    pages = count % pageSize > 0 ? parseInt(count / pageSize, 0) + 1 : parseInt(count / pageSize, 0);
    page = 1;
    handlePagination();
  };

  handleDistributor();
  handlePagination(true);

  el.querySelectorAll('.pagination__link').forEach(e => {
    e.addEventListener('click', link => {
      const linkEl = getClosestElement(link.target, '.pagination__link');
      let target;
      if (linkEl.classList.value.includes('pagination__next')) {
        target = parseInt(el.querySelector('.active').innerText, 0) + 1;
      } else if (linkEl.classList.value.includes('pagination__prev')) {
        target = parseInt(el.querySelector('.active').innerText, 0) - 1;
      } else {
        target = parseInt(linkEl.innerText, 0);
      }

      if (page !== target) {
        page = target;
        handlePagination();
      }
    });
  });

  el.querySelectorAll('.distributor-card').forEach(c => {
    c.addEventListener('click', e => {
      handleFilter(getClosestElement(e.target, '.distributor-card').dataset.category);
    });
  });

  el.querySelectorAll('.resources-card__category').forEach(c => {
    c.addEventListener('click', e => {
      handleFilter(getClosestElement(e.target, '.resources-card').dataset.category);
    });
  });

  el.querySelector('.clear-filter').addEventListener('click', () => {
    handleFilter();
  });

  distributorSeeMore.addEventListener('click', () => {
    if (distributorSeeMore.innerText === distributorSeeMore.dataset.seeMore) {
      distributorLimit += 4;
    } else {
      distributorLimit = 4;
      scrollTo(el, 500, document.querySelector('header').offsetHeight);
    }

    handleDistributor();
  });
};

export default resourcesCenter;
