import Tabs from "./tabs";
import ComponentService from "../../services/components.service";

/**
 * Inicializa todos los componentes de tabs en la página que no estén marcados como aislados
 * Los registra en el ComponentService para su gestión centralizada
 */
const initTabs = () => {
    if (document.querySelector('body').classList == '') return; //fractal
    document.querySelectorAll('.content-with-menu-tab').forEach(el => {
        ComponentService.addComponent(new Tabs(el));
    });
}

export default initTabs;