import Swiper from 'swiper';

/**
 * Componente para manejar la funcionalidad de tabs
 * Implementa la lógica para cambiar entre tabs y manejar su estado
 */
class Tabs {
    /**
     * Constructor de la clase
     * @param {HTMLElement} el - El elemento raíz del componente
     */
    constructor(el) {
        this.container = el;
        this.buttons = this.container.querySelectorAll('.menu-tab-button');
        this.contents = this.container.querySelectorAll('.content-with-menu-tab__content');
        this.activeTabNumber = 1;
        this.swiperInstance = null; // Guardamos la instancia de Swiper

        this.init();
    }

    /**
     * Inicializa el componente
     */
    init() {
        this.setupEventListeners();
        this.initSwiper();

        // Activar la primera pestaña por defecto
        this.activateTab(1);
    }

    /**
     * Configura los listeners de eventos
     */
    setupEventListeners() {
        this.buttons.forEach(button => {
            button.addEventListener('click', (e) => {
                const tabNumber = button.getAttribute('data-tab');
                this.activateTab(tabNumber);
            });
        });
    }

    /**
     * Inicializa el swiper para los contenidos de las pestañas
     */
    initSwiper() {
        //Activar el swiper para el formato vertical en dispositivos móviles (porque se convierte en horizontal)
        const verticalScroller = this.container.querySelector('.menu-tab-scroller__scroll.menu-tab-scroller__scroll--');
        if (
            verticalScroller &&
            window.matchMedia('(max-width: 767px)').matches) {
            verticalScroller.classList.add('swiper-container');
        }

        // Comprobar si los tabs caben completamente en el contenedor
        const tabsWrapper = this.container.querySelector('.menu-tab__wrapper');
        const tabsContent = this.container.querySelector('.menu-tab-scroller__scroll-content');

        if (tabsWrapper && tabsContent) {
            // Obtener el ancho del contenedor y el ancho total de los tabs
            const wrapperWidth = tabsWrapper.offsetWidth;
            const tabsWidth = tabsContent.scrollWidth;

            // Solo inicializar Swiper si los tabs no caben en el contenedor
            if (tabsWidth <= wrapperWidth) {
                // Ocultar los botones de navegación ya que no son necesarios
                const prevButton = this.container.querySelector('.swiper-button-prev');
                const nextButton = this.container.querySelector('.swiper-button-next');
                if (prevButton) prevButton.style.display = 'none';
                if (nextButton) nextButton.style.display = 'none';

                return;
            }
        }

        document.querySelectorAll('.menu-tab.tabs').forEach(menu => {
            const slider = menu.querySelector('.swiper-container');
            if (slider) {
                const swiperOptions = {
                    slidesPerView: "auto",
                    effect: slider.dataset.effect ?? 'swipe',
                    // centeredSlides: true,
                    autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
                    pagination: {
                        el: slider.querySelector('.swiper-pagination'),
                        clickable: true,
                    },
                    navigation: {
                        nextEl: menu.querySelector('.swiper-button-next'),
                        prevEl: menu.querySelector('.swiper-button-prev'),
                    },
                    slidesOffsetAfter: 60,
                    breakpoints: {
                        40000: {
                            slidesPerView: 1,
                            slidesPerGroup: 1,
                            spaceBetween: 0,
                        }
                    },
                };

                // Guardar la instancia de Swiper para usarla después
                if (menu === this.container.querySelector('.menu-tab.tabs')) {
                    this.swiperInstance = new Swiper(slider, swiperOptions);
                } else {
                    new Swiper(slider, swiperOptions);
                }
            }
        });
    }

    /**
     * Activa la pestaña especificada
     * @param {string|number} tabNumber - El número de la pestaña a activar
     */
    activateTab(tabNumber) {
        // Guardar el tab activo
        this.activeTabNumber = tabNumber;

        // Desactivar todos los botones
        this.buttons.forEach(button => {
            button.classList.remove('active');
            button.setAttribute('aria-selected', 'false');
        });

        // Activar el botón correspondiente
        const activeButton = this.container.querySelector(`.menu-tab-button[data-tab="${tabNumber}"]`);
        if (activeButton) {
            activeButton.classList.add('active');
            activeButton.setAttribute('aria-selected', 'true');

            // Desplazar el Swiper para mostrar completamente la pestaña seleccionada
            this.scrollToTab(activeButton);
        }

        // Ocultar todos los contenidos y quitar clase active de los items
        this.contents.forEach(content => {
            content.style.display = 'none';

            // Quitar clase active del item interno
            const contentItem = content.querySelector('.menu-tab-content__item');
            if (contentItem) {
                contentItem.classList.remove('active');
            }
        });

        // Mostrar el contenido correspondiente
        const activeContent = this.container.querySelector(`.content-with-menu-tab__content[data-tab="${tabNumber}"]`);
        if (activeContent) {
            activeContent.style.display = 'block';

            // Añadir clase active al item interno
            const activeContentItem = activeContent.querySelector('.menu-tab-content__item');
            if (activeContentItem) {
                activeContentItem.classList.add('active');
            }
        }
    }

    /**
     * Desplaza el swiper para mostrar completamente la pestaña seleccionada
     * solo si la pestaña no está completamente visible
     * @param {HTMLElement} tabElement - El elemento de la pestaña a mostrar
     */
    scrollToTab(tabElement) {
        // Verificar si tenemos una instancia válida de Swiper
        if (!this.swiperInstance) {
            // Si no hay swiper (porque los tabs caben completamente), no hacemos nada
            return;
        }

        // Encontrar el slide que contiene la pestaña
        const slideElement = tabElement.closest('.swiper-slide');
        if (!slideElement) return;

        // Obtener el contenedor del Swiper
        const swiperContainer = this.container.querySelector('.swiper-container');
        if (!swiperContainer) return;

        // Comprobar si la pestaña está completamente visible en el contenedor
        const tabRect = slideElement.getBoundingClientRect();
        const containerRect = swiperContainer.getBoundingClientRect();

        // Si la pestaña está parcialmente fuera del contenedor visible, desplazamos
        const isPartiallyHidden =
            tabRect.left < containerRect.left ||
            tabRect.right > containerRect.right;

        if (isPartiallyHidden) {
            // Buscamos el índice del slide
            const slides = Array.from(this.container.querySelectorAll('.swiper-slide'));
            const slideIndex = slides.indexOf(slideElement);

            if (slideIndex !== -1) {
                // Desplazar al slide correspondiente solo si no está completamente visible
                this.swiperInstance.slideTo(slideIndex);
            }
        }
    }
}

export default Tabs;
