import YouTubePlayer from 'youtube-player';

export class Lightbox {
    constructor(el) {
        this.element = el;
        this.modal = el.querySelector('.modal');
        this.id = el.getAttribute('id').split('-lightbox-new')[0];
        this.toggles = [...document.querySelectorAll(`.modal-toggle[data-modal="${this.id}"]`)];
        this.close = el.querySelector('.modal-close');

        if (document.getElementById(`${this.id}-yt`)) {
            this.youtube = YouTubePlayer(`${this.id}-yt`);
        }

        this.init();
    }

    init() {
        // 1. eventos para abrir el modal
        this.toggles.forEach(t => {
            t.addEventListener('click', (e) => {
                e.stopPropagation();
                this.modal.classList.toggle('fade-in');
            });
        });

        // 2. boton X para cerrar
        if (this.close) {
            this.close.addEventListener('click', (e) => {
                e.stopPropagation();
                this.modal.classList.toggle('fade-in');
                if (this.youtube) this.youtube?.pauseVideo();
            });
        }

        // 3. click fuera del modal para cerrar
        document.addEventListener('click', (event) => {
            const container = this.modal.querySelector('.modal-container');
            if (
                this.modal.classList.contains('fade-in') && // modal abierto
                !container.contains(event.target) && // click fuera del container (contenido)
                !Array.from(this.toggles).some(toggle => toggle.contains(event.target)) // el click no es en un toggle
            ) {
                this.modal.classList.remove('fade-in');
                if (this.youtube) this.youtube?.pauseVideo();
            }
        });

        // video
        if (this.element.querySelector('video')) {
            this.modal.classList.add('empty');
        }
    }
}