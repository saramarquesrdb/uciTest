import { Lightbox } from './lightbox';

const initLightboxes = () => {
    const lightboxes = [...document.querySelectorAll('.lightbox-new')];
    if (lightboxes.length === 0) return;

    const ids = new Set();
    lightboxes.forEach(l => {
        if (ids.has(l.id)) {
            l.remove();
        } else {
            ids.add(l.id);
            document.body.appendChild(l);
        }
    });

    lightboxes.map(x => new Lightbox(x))
};

export default initLightboxes;
