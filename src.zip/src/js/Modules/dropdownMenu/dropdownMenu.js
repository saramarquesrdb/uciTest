import hideOrShow from '../../Helpers/hideOrShow';

const dropdownMenu = () => {
    const close = document.getElementsByClassName('dropdown-menu__close');
    hideOrShow(close, '');
};

export default dropdownMenu;