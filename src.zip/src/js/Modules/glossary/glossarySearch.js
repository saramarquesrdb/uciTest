import showMore from '../../Common/showMore';
import hideOrShow from '../../Helpers/hideOrShow';

const glossarySearch = () => {
  const activeClassname = 'visible';
  const input = document.querySelector('.glossary__search input');
  const firstLvlList = document.getElementsByClassName('glossary-list');
  const radioGroup = document.getElementsByClassName('alpha-menu__radio');
  const radio = document.getElementsByClassName('alpha-menu__input');
  const label = document.getElementsByClassName('alpha-menu__label');
  const elementsToReplaceText = [
    '.glossary__extra-title .placeholder',
    '.glossary__extra-desc .placeholder',
  ];
  const elementsToHide = ['glossary-list__letter', 'glossary-list__link'];
  const elementsToShowFor404 = ['glossary__extra-404'];

  const performASearch = () => {
    const filter = input.value.toLowerCase();
    const arrayOfVisibleElements = [];

    if (!filter) {
      const theOriginalList = firstLvlList[0];
      const theOriginalLabel = label[0];

      hideOrShow(elementsToHide, '');
      hideOrShow(elementsToShowFor404, '');

      for (let i = 0; i < firstLvlList.length; i++) {
        const thisFirstLvlList = firstLvlList[i];
        const secondLvlList = thisFirstLvlList.querySelector(
          '.glossary-list__list',
        );
        const secondLvlItem = secondLvlList.getElementsByClassName(
          'glossary-list__item',
        );

        thisFirstLvlList.classList.remove(activeClassname);

        for (let j = 0; j < secondLvlItem.length; j++) {
          secondLvlItem[j].style.display = '';
        }
      }

      theOriginalList.classList.add(activeClassname);
      theOriginalLabel.classList.add(activeClassname);

      showMore(
        'glossary-list',
        'glossary-list__item',
        '.glossary-list__link .link',
      );
    } else {
      for (let i = 0; i < radioGroup.length; i++) {
        const thisRadio = radioGroup[i].querySelector('.alpha-menu__input');

        label[i].classList.remove(activeClassname);
        radio[i].checked = false;

        thisRadio.addEventListener('click', () => {
          input.value = '';

          hideOrShow(elementsToHide, '');
          hideOrShow(elementsToShowFor404, '');

          for (let j = 0; j < firstLvlList.length; j++) {
            const thisFirstLvlList = firstLvlList[j];
            const secondLvlList = thisFirstLvlList.querySelector(
              '.glossary-list__list',
            );
            const secondLvlItem = secondLvlList.getElementsByClassName(
              'glossary-list__item',
            );

            for (let k = 0; k < secondLvlItem.length; k++) {
              secondLvlItem[k].style.display = '';
            }
          }

          showMore(
            'glossary-list',
            'glossary-list__item',
            '.glossary-list__link .link',
          );
        });
      }

      for (let i = 0; i < firstLvlList.length; i++) {
        const thisFirstLvlList = firstLvlList[i];
        const secondLvlList = thisFirstLvlList.querySelector(
          '.glossary-list__list',
        );
        const secondLvlItem = secondLvlList.getElementsByClassName(
          'glossary-list__item',
        );

        hideOrShow(elementsToHide, 'none');

        thisFirstLvlList.classList.add(activeClassname);

        for (let j = 0; j < secondLvlItem.length; j++) {
          const thisItem = secondLvlItem[j];
          const thisTarget = thisItem.querySelector(
            '.glossary-list-item__title',
          );

          if (
            thisTarget.innerText
              .trim()
              .toLowerCase()
              .indexOf(filter) > -1
          ) {
            thisItem.style.display = '';
            arrayOfVisibleElements.push(0);
          } else {
            thisItem.style.display = 'none';
            arrayOfVisibleElements.push(1);
          }
        }
      }

      if (!arrayOfVisibleElements.includes(0)) {
        elementsToReplaceText.map(el => {
          document.querySelector(el).innerText = filter;
        });

        hideOrShow(elementsToShowFor404, 'block');
      } else {
        hideOrShow(elementsToShowFor404, '');
      }
    }
  };

  if (input) {
    input.addEventListener('keyup', performASearch);
  }
};

export default glossarySearch;
