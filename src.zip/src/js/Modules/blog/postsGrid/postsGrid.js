import scrollTo from "@/js/Helpers/scrollTo";

const postsGrid = (element) => {
    const model = element.querySelector('ul.item-model');
    const cardHtml = model.innerHTML;
    model.remove();

    const loadPage = (source, page, ignoreHighlighted, clearPrevious, scroll) => {
        fetch(`${window.location.origin}/blogapi/page?source=${source}&page=${page}&ignoreHighlighted=${ignoreHighlighted.toString()}`, {
            method: 'GET'
        })
            .then(response => {
                return response.json();
            })
            .then(data => {
                if (clearPrevious) {
                    element.querySelectorAll('.cards-grid__cards__item:not(.highlighted)').forEach(el => { el.remove(); });
                }
                const container = element.querySelector('.cards-grid__cards ul');
                const posts = data.Posts;
                posts.forEach(x => {
                    let html = cardHtml;
                    html = html.replaceAll('[url]', x.url);
                    html = html.replaceAll('[image]', x.image);
                    html = html.replaceAll('[publishedDate]', x.publishedDate);
                    html = html.replaceAll('[categoryUrl]', x.categoryUrl);
                    html = html.replaceAll('[categoryTitle]', x.categoryTitle);
                    html = html.replaceAll('[title]', x.title);

                    const wrapper = document.createElement('div');
                    wrapper.innerHTML = html.trim();

                    const card = wrapper.firstChild;
                    card.setAttribute('data-page', page);
                    container.appendChild(card);
                })

                if (!ignoreHighlighted) {
                    const highlightedCard = element.querySelector('.cards-grid__cards__item.highlighted');
                    if (highlightedCard) {
                        container.appendChild(highlightedCard);
                    }
                }
            })
            .finally(() => {
                if (scroll) {
                    scrollTo(element, 200, 100);
                }
            });
    }

    const source = element.dataset.source;

    const pagination = element.querySelector('.pagination');
    if (pagination) {
        pagination.addEventListener('pageChange', (e) => {
            const page = e.detail;
            loadPage(source, page, false, true, true);
        })
    }

    const seeMore = element.querySelector('.link.link_more');
    if (seeMore) {
        seeMore.addEventListener('click', () => {
            loadPage(source, 2, true, false, false);
        })
    }

    const seeLess = element.querySelector('.link.link_more_less');
    if (seeLess) {
        seeLess.addEventListener('click', () => {
            element.querySelectorAll('.cards-grid__cards__item[data-page="2"]').forEach(el => { el.remove(); });
            scrollTo(element, 200, 100);
        })
    }
}

export default postsGrid;