import postsGrid from "./postsGrid";

const initPostsGrid = () => {
    document.querySelectorAll('.cards-grid.posts-grid').forEach(x => {
        postsGrid(x);
    });
}

export default initPostsGrid;