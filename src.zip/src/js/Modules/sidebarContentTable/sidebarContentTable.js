class SidebarContentTable {
    static SCROLL_OFFSET = 50;
    static SCROLL_DELAY = 1000;

    constructor(el, options = {}) {
        // Elementos DOM principales
        this.element = el;
        this.wrapAggregator = this.element.querySelector('.wrap-aggregator');
        this.tileTitle = this.element.querySelector('.tile-aggregator__title');
        this.tileAggregator = this.element.querySelector('.tile-aggregator');
        this.links = this.element.querySelectorAll('.tile-aggregator__link a');
        this.header = document.querySelector('header');
        this.sidebar = document.querySelector(".sidebar-content-table");

        // Opciones
        this.options = {
            stickyElement: options.stickyElement || {
                selector: null,
                onlyUpwards: false,
                viewport: 'both'
            }
        };

        // Estado interno
        this.isManualScroll = true;
        this.sections = null;
        this.mediaQueryXS = window.matchMedia('(max-width: 767px)');
        this.mediaQueryMS = window.matchMedia('(min-width: 768px) and (max-width: 1023px)');
        this.boundHandleScroll = this.handleScroll.bind(this);
        this.boundHandleMediaChange = this.handleMediaChange.bind(this);
        this.lastScrollPosition = 0;
        this.isMobile = false;

        // Observer para detectar visibilidad
        this.observer = new IntersectionObserver(this.handleIntersection.bind(this), {
            threshold: 0
        });

        this.init();
    }

    init() {
        if (!this.wrapAggregator || !this.tileAggregator) {
            console.warn('SidebarContentTable: Elementos requeridos no encontrados');
            return;
        }

        this.sections = this.getSections();

        // Comprobar el estado inicial y posicionar el elemento
        const isMobileInitial = this.mediaQueryXS.matches || this.mediaQueryMS.matches;
        if (isMobileInitial) {
            this.wrapAggregator.classList.add('collapsed');
            this.wrapAggregator.classList.add('scroll');
            if (this.tileTitle && !this.tileTitle.querySelector('.icon')) {
                this.tileTitle.appendChild(this.createIcon('plus-circle'));
            }
        }

        this.initMediaQuery();
        this.addEventListeners();
        this.observer.observe(this.element);
    }

    initMediaQuery() {
        this.isMobile = this.mediaQueryXS.matches || this.mediaQueryMS.matches;
        this.mediaQueryXS.addEventListener('change', this.boundHandleMediaChange);
        this.mediaQueryMS.addEventListener('change', this.boundHandleMediaChange);
        this.handleMediaChange();
    }

    addEventListeners() {
        window.addEventListener('scroll', this.boundHandleScroll, { passive: true });
        if(this.tileTitle){
            this.tileTitle.addEventListener('click', this.handleTitleClick.bind(this));
        }

        this.links.forEach(link => {
            link.addEventListener('click', this.handleLinkClick.bind(this));
        });

        this.boundHandleScroll();
    }

    getSections() {
        return Array.from(this.links)
            .map(link => {
                const targetId = link.getAttribute('href')?.substring(1);
                return targetId ? document.getElementById(targetId) : null;
            })
            .filter(Boolean);
    }

    handleMediaChange() {
        this.isMobile = this.mediaQueryXS.matches || this.mediaQueryMS.matches;
        this.wrapAggregator.classList.toggle('scroll', this.isMobile);

        if (this.isMobile) {
            if (this.tileTitle && !this.tileTitle.querySelector('.icon')) {
                this.tileTitle.appendChild(this.createIcon('plus-circle'));
            }
            this.wrapAggregator.classList.add('collapsed');
            this.wrapAggregator.style.removeProperty('top');
        } else {
            if (this.tileTitle) {
                this.tileTitle.querySelector('.icon')?.remove();
            }
            this.wrapAggregator.classList.remove('collapsed');
            this.wrapAggregator.style.top = '0';
            this.wrapAggregator.style.display = '';
        }
    }

    handleIntersection(entries) {
        if (!this.isMobile) return;

        entries.forEach(entry => {
            this.wrapAggregator.style.display = entry.isIntersecting ? '' : 'none';
        });
    }

    handleTitleClick() {
        if (!this.isMobile) return;
        this.wrapAggregator.classList.toggle('collapsed');
        if (this.tileTitle) {
            this.updateIcon(this.tileTitle.querySelector('.icon')); 
        }
    }

    handleScroll() {
        if (!this.isManualScroll) return;

        if(this.sidebar && this.sidebar.classList.contains("forBlog")){
            const rect = this.sidebar.getBoundingClientRect();
            // Check if the top of the container is at or above the top of the viewport
            if (rect.top <= 0) {
                this.sidebar.classList.add("forBlogScroll");
            } else {
                this.sidebar.classList.remove("forBlogScroll");
            }
        }

        const scrollPosition = window.scrollY || document.documentElement.scrollTop;
        const scrollingUp = scrollPosition < this.lastScrollPosition;
        const stickyOffset = this.getStickyOffset(scrollingUp);

        // Ajustar posición del wrap-aggregator solo en desktop
        if (!this.isMobile) {
            const elementTop = this.element.getBoundingClientRect().top;
            if (elementTop <= stickyOffset) {
                this.wrapAggregator.style.top = `${stickyOffset}px`;
            } else {
                this.wrapAggregator.style.top = '0';
            }
        } else {
            this.wrapAggregator.style.removeProperty('top');
        }

        // Encuentra la sección activa
        const viewportCenter = window.innerHeight / 2;
        let activeSection = null;
        let minDistance = Infinity;

        this.sections.forEach(section => {
            if (!section) return;
            const rect = section.getBoundingClientRect();
            const distance = Math.abs(rect.top - viewportCenter);

            if (distance < minDistance) {
                minDistance = distance;
                activeSection = section;
            }
        });

        this.updateActiveLink(activeSection);
        this.lastScrollPosition = scrollPosition;
    }

    handleLinkClick(event) {
        event.preventDefault();

        const link = event.target.closest('a');
        if (!link) return;

        const targetId = link.getAttribute('href')?.substring(1);
        if (!targetId) return;

        const targetElement = document.getElementById(targetId);
        if (!targetElement) return;

        this.isManualScroll = false;
        this.clearActiveLinks();

        const clickedLink = link.closest('.tile-aggregator__link');
        if (clickedLink) {
            this.setActiveLink(clickedLink);
        }

        const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
        const targetRect = targetElement.getBoundingClientRect();
        const targetPosition = currentScroll + targetRect.top;
        const isScrollingUp = targetPosition < currentScroll;
        const stickyOffset = this.getStickyOffset(isScrollingUp);

        // Ajustar posición del wrap-aggregator solo en desktop
        if (!this.isMobile) {
            if (stickyOffset) {
                this.wrapAggregator.style.top = `${stickyOffset}px`;
            } else {
                this.wrapAggregator.style.top = '0';
            }
        } else {
            this.wrapAggregator.style.removeProperty('top');
        }

        window.scrollTo({
            top: targetPosition - stickyOffset - SidebarContentTable.SCROLL_OFFSET,
            behavior: 'smooth'
        });

        // En móvil, colapsar la tabla después de seleccionar
        if (this.isMobile) {
            this.wrapAggregator.classList.add('collapsed');
            if (this.tileTitle) {
                const icon = this.tileTitle.querySelector('.icon');
                if (icon) {
                    this.updateIcon(icon);
                }
            }
        }

        setTimeout(() => {
            this.isManualScroll = true;
        }, SidebarContentTable.SCROLL_DELAY);
    }

    getStickyOffset(isScrollingUp = false) {
        const stickyElement = document.querySelector(this.options.stickyElement.selector);
        if (!stickyElement) return 0;

        const { onlyUpwards } = this.options.stickyElement;
        if (onlyUpwards && !isScrollingUp) return 0;

        return stickyElement.offsetHeight;
    }

    updateActiveLink(activeSection) {
        this.clearActiveLinks();

        if (!activeSection) return;

        const activeLink = Array.from(this.links).find(link => {
            const href = link.getAttribute('href');
            return href?.substring(1) === activeSection.id;
        });

        if (activeLink) {
            this.setActiveLink(activeLink.parentElement);
        }
    }

    clearActiveLinks() {
        this.links.forEach(link => {
            const linkParent = link.parentElement;
            const itemParent = link.closest('.tile-aggregator__item');

            linkParent?.classList.remove('active');
            itemParent?.classList.remove('active');
        });
    }

    setActiveLink(element) {
        element.classList.add('active');
        const parentItem = element.closest('.tile-aggregator__item');
        if (parentItem) {
            parentItem.classList.add('active');
        }
    }

    updateIcon(iconElement) {
        const newIconType = this.wrapAggregator.classList.contains('collapsed') ? 'plus-circle' : 'minus-circle';
        iconElement.replaceWith(this.createIcon(newIconType));
    }

    createIcon(iconType) {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.classList.add('icon', `icon-icon-${iconType}`);

        const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
        use.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', `/dist/icons/icons.svg#icon-${iconType}`);
        svg.appendChild(use);

        return svg;
    }
}

export default SidebarContentTable;