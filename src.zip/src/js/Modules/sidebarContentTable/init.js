import SidebarContentTable from "./sidebarContentTable";
import ComponentService from "../../services/components.service";

const initSidebarContentTable = () => {
    document.querySelectorAll('.sidebar-content-table').forEach(el => {
        const hasPostHeadline = document.querySelector('.post-headline__head.sticky-clone');

        const options = {
            stickyElement: hasPostHeadline ?
                {
                    selector: '.post-headline__head.sticky-clone',
                    onlyUpwards: false,
                    viewport: 'both'
                } :
                {
                    selector: 'header',
                    onlyUpwards: true,
                    viewport: 'both'
                }
        };

        ComponentService.addComponent(new SidebarContentTable(el, options));
    });
}

export default initSidebarContentTable;