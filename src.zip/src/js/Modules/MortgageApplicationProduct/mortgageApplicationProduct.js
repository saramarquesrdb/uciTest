import formValidator from "@/js/Common/forms/formValidator";
import { jsLog } from "@/js/Helpers/_helpers";

const mortgageApplicationProduct = (element) => {
  const form = element.querySelector('form');
  if (!form) return null;

  const validator = formValidator(form);

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log("Manejando submit... preventDefault ejecutado");
    const isValid = validator.isFormValid();
    alert("is Valid: " + isValid);

    if (isValid) {
      jsLog("--> Formulario válido, enviando...");
      form.requestSubmit(); // más seguro que form.submit()
    } else {
      jsLog("--> Formulario NO válido, no se envía");
      const firstError = form.querySelector('.error input, .error .access-select__option');
      if (firstError) firstError.focus();
    }
  };

  form.addEventListener('submit', handleSubmit);
  return validator;
};

export default mortgageApplicationProduct;
