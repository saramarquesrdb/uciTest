
const pendingDocuments = () => {
  // PI=3,141592653589792
  // R=radio
  // L=longitud=2 x PI x R
  // Offset=L/4
  // dash=dato x L / 100
  // resto=L - dash
  const classLine = 'js-line-segment';
  const classDataTotal = 'data-total';
  const classDataUpload = 'data-num-upload';


  function graphInit() {
    const elements = document.getElementsByClassName(classLine);
    for (let i = 0; i < elements.length; i += 1) {
      const percentTotal = parseFloat(elements[i].getAttribute(classDataTotal));
      const percentInit = parseFloat(elements[i].getAttribute(classDataUpload));
      const dashInitOne = (percentInit * 100) / percentTotal;
      const x2 = `${dashInitOne.toString()}%`;

      elements[i].setAttribute('x2', x2);
    }
  }

  // si se usa ajax llamar de nuevo a la funcion circuloInit
  graphInit();
};


export default pendingDocuments;
