import getClosestElement from '../../Helpers/getClosestElement';

const postHeadlineStickyActive = () => {
  const activeClassname = 'active';
  const trigger = document.querySelector('.post-headline__socials-trigger');
  const wrapper = getClosestElement(
    trigger,
    '.post-headline__head-wrapper.sticky-clone__wrapper',
  );

  trigger.addEventListener('click', () => {
    if (!wrapper.classList.contains(activeClassname)) {
      wrapper.classList.add(activeClassname);
    } else {
      wrapper.classList.remove(activeClassname);
    }
  });
};

export default postHeadlineStickyActive;
