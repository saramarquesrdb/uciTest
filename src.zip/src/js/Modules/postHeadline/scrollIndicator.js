const postHeadlineScrollIndicator = () => {
  window.addEventListener('scroll', () => {
    const content = document.querySelector('.blog-post-content');
    const postHeadlineBar = document.querySelector(
      '.post-headline__head.sticky-clone .progress-bar'
    );

    if (!content || !postHeadlineBar) return;

    const offsetTop = content.getBoundingClientRect().top + window.scrollY;
    const contentHeight = content.scrollHeight;
    const winScroll = window.scrollY - offsetTop;

    const scrolled = Math.min((winScroll / contentHeight) * 100, 100);
    postHeadlineBar.style.width = `${scrolled}%`;
  });
};

export default postHeadlineScrollIndicator;
