const initShareApa = () => {
    const component = document.querySelector('.share-APA');

    if (component) {
        const url = new URL(window.location.href);
        const leadKey = url.searchParams.get('leadKey');

        if (leadKey !== null) {
            const modifiedLeadKey = leadKey.replace(/:/g, '@');
            let newPathname = url.pathname;

            if (!newPathname.endsWith('/')) {
                newPathname += '/';
            }

            newPathname += `${modifiedLeadKey}/`;

            if (!url.pathname.includes(modifiedLeadKey)) {
                window.location.href = `${url.origin}${newPathname}${url.search}`;
                return;
            }

            const manifestUrl = `/share-apa/${modifiedLeadKey}/manifest.json`;
            const link = document.createElement('link');
            link.rel = 'manifest';
            link.href = manifestUrl;
            document.head.appendChild(link);

            console.log(`Manifest cargado: ${manifestUrl}`);

            const script = document.createElement('script');
            script.defer = true;
            script.src = "/dist/files/pwa-landing/index.js";
            document.head.appendChild(script);

            console.log("Script añadido: /dist/files/pwa-landing/index.js");
        }
    }
};

export default initShareApa;
