import getClosestElement from '../../Helpers/getClosestElement';

const journeySliderStickyActive = () => {
  const activeClassname = 'active';
  const trigger = document.querySelector('.journey-slider__stepsBar');
  const wrapper = getClosestElement(
    trigger,
    '.journey-slider__stepsBar .sticky-clone__wrapper',
  );

  trigger.addEventListener('click', () => {
    if (!wrapper.classList.contains(activeClassname)) {
      wrapper.classList.add(activeClassname);
    } else {
      wrapper.classList.remove(activeClassname);
    }
  });
};


export default journeySliderStickyActive;
