import MenuTab from "./menuTab";
import ComponentService from "../../services/components.service";

const initMenuTab = () => {
    document.querySelectorAll('.menu-tab__wrapper:not(.isolated)').forEach(el => {
        ComponentService.addComponent(new MenuTab(el));
    });
}

export default initMenuTab;
