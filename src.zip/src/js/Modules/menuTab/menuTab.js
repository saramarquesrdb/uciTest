class MenuTab {
    constructor(el) {
        this.element = el;
        this.tabs = el.querySelectorAll('.menu-tab-button');
        this.contents = el.querySelectorAll('.menu-tab-content__item');
        this.menuTabContainer = el.querySelector('.menu-tab');
        this.menuTabWrapper = el;
        this.contentContainer = el.querySelector('.menu-tab-content');

        this.menuTabInitialTop = this.menuTabContainer.getBoundingClientRect().top + window.scrollY;
        this.lastScrollTop = window.scrollY || document.documentElement.scrollTop;
        this.isHeaderVisible = true;
        this.headerHeight = 0;
        this.header = document.querySelector('header');
        this.currentMenuTabTop = 0;

        this.init();
    }

    init() {
        this.addEvents();
        this.adjustCardTitles();
    }

    addEvents() {
        this.tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.id.replace('tab_', '');
                this.hideAllContents();
                this.showContent(tabId);
            });
        });

        window.addEventListener('load', () => this.adjustCardTitles());
        window.addEventListener('resize', () => this.adjustCardTitles());
    }

    hideAllContents() {
        this.contents.forEach(content => {
            content.classList.remove('active');
            content.classList.add('inactive');
        });

        this.tabs.forEach(tab => {
            tab.classList.remove('active');
            tab.classList.add('inactive');
        });
    }

    showContent(tabId) {
        const content = this.element.querySelector('#content_' + tabId);
        if (content) {
            content.classList.remove('inactive');
            content.classList.add('active');
        }

        const tab = this.element.querySelector('#tab_' + tabId);
        if (tab) {
            tab.classList.remove('inactive');
            tab.classList.add('active');
        }
    }

    adjustCardTitles() {
        const titleElements = document.querySelectorAll('.card-contact__title > h3');
        titleElements.forEach(titleElement => {
            const title = titleElement.getAttribute('data-title');
            const reducedTitle = titleElement.getAttribute('data-title');
            if (title && reducedTitle) {
                titleElement.innerHTML = window.innerWidth <= 1023 ? reducedTitle : title;
            }
        });
    }
}

export default MenuTab;
