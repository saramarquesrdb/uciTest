

/* READY FOR STICKY
import getClosestElement from '../../Helpers/getClosestElement';
/* const faqsStackerStickyActive = () => {
  const activeClassname = 'active';
  const trigger = document.querySelector('.faqs-component__stacker-dropdown');
  const wrapper = getClosestElement(
    trigger,
    '.faqs-component__stacker-dropdown .sticky-clone__wrapper',
  );

  console.log('gets on function js');

  trigger.addEventListener('click', () => {
    if (!wrapper.classList.contains(activeClassname)) {
      wrapper.classList.add(activeClassname);
    } else {
      wrapper.classList.remove(activeClassname);
    }
  });
}; */

/* export default faqsStackerStickyActive; */
