const mobileMenuOpenHideFixed = () => {
  const trigger = document.getElementsByClassName(
    'header-fixed__mobile-menu-control',
  );
  const targetsArray = ['.header-fixed__body-main-overlay', 'body'];
  const activeClassname = 'mobile-menu-is-open';
  const timeoutDuration = 500;
  let flag = true;

  for (let i = 0; i < trigger.length; i++) {
    const thisTrigger = trigger[i];

    thisTrigger.addEventListener('click', () => {
      if (flag) {
        flag = false;

        const clickOutside = () => {
          const handler = e => {
            const isClickedInsideMobileMenu = document
              .querySelector('.header-fixed__body-main')
              .contains(e.target);

            if (!isClickedInsideMobileMenu && flag) {
              flag = false;
              targetsArray.map(element => document
                .querySelector(element)
                .classList.remove(activeClassname));
              document.removeEventListener('click', handler);
              setTimeout(() => {
                flag = true;
              }, timeoutDuration);
            }
          };

          return handler;
        };

        document.addEventListener('click', clickOutside());

        targetsArray.map(element => {
          const target = document.querySelector(element);

          if (!target.classList.contains(activeClassname)) {
            target.classList.add(activeClassname);

            setTimeout(() => {
              flag = true;
            }, timeoutDuration);
          } else {
            target.classList.remove(activeClassname);

            setTimeout(() => {
              flag = true;
            }, timeoutDuration);
          }
        });
      }
    });
  }
};


export default mobileMenuOpenHideFixed;
