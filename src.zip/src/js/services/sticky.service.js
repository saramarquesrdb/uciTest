export class StickyService {
    constructor() {
        this.elements = [];
        this.header = document.querySelector('.header__head');
        this.headerElement = document.querySelector('header');
        this.isHeaderVisible = true;
        this.headerHeight = 0;

        this.init();
    }

    init() {
        this.calculateHeaderHeight();
        this.addScrollEvents();
    }

    calculateHeaderHeight() {
        if (this.header) {
            this.headerHeight = this.header.offsetHeight;

            // Asegurar que el header no exceda el ancho de la ventana
            const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
            this.header.style.width = `${viewportWidth}px`;
            if (this.headerElement) {
                this.headerElement.style.width = `${viewportWidth}px`;
            }
        } else {
            this.headerHeight = 0;
        }
    }

    addScrollEvents() {
        window.addEventListener('scroll', () => this.onScroll());
        window.addEventListener('load', () => this.onResize());
        window.addEventListener('resize', () => this.onResize());
    }

    onScroll() {
        this.isHeaderVisible = this.headerElement?.classList.contains('visible') ?? false;
    }

    onResize() {
        this.calculateHeaderHeight();
    }

    addElement(element, options = {}) {
        const stickyElement = new StickyElement(element, options);
        this.elements.push(stickyElement);
        this.updateDependencies();
        this.setHtmlClass();
        return stickyElement;
    }

    updateDependencies() {
        this.elements.forEach((element) => {
            this.elements.forEach((potentialDependency) => {
                if (element !== potentialDependency) {
                    let currentElement = element.element.parentElement;

                    while (currentElement) {
                        if (currentElement == potentialDependency.stickyContainer) {
                            element.addDependency(potentialDependency);
                            break;
                        }
                        currentElement = currentElement.parentElement;
                    }
                }
            });

            element.refresh();
        });
    }

    isElementSticky(element) {
        const style = window.getComputedStyle(element);
        const isSticky = style.position === 'sticky';

        if (!isSticky) {
            return false;
        }

        const rect = element.getBoundingClientRect();
        const parentRect = element.parentElement.getBoundingClientRect();

        return rect.top <= parentRect.top && rect.bottom >= parentRect.top;
    }

    setHtmlClass() {
        document.documentElement.classList.add('sticky');
    }
}

class StickyElement {
    constructor(element, options = {}) {
        this.element = element;
        this.sticking = false;
        this.dependencies = [];
        this.stickyContainer = this.findStickyContainer();
        this.offset = 0;
        this.offsetOverlap = 1;

        this.ignoreHeader = options.ignoreHeader === true;

        if (this.stickyContainer) {
            this.stickyContainer.setAttribute('data-sticky', 'true');
        }

        this.addScrollEvents();
    }

    addScrollEvents() {
        window.addEventListener('scroll', () => this.refresh());
        window.addEventListener('load', () => this.refresh());
        window.addEventListener('resize', () => this.refresh());
    }

    addDependency(element) {
        this.dependencies.push(element);
    }

    clearDependencies() {
        this.dependencies = [];
    }

    refresh() {
        // Refresh Sticking
        const previousSticking = this.sticking;
        this.sticking = window.stickyService.isElementSticky(this.element);
        if (this.sticking !== previousSticking) {
            this.element.dispatchEvent(new CustomEvent('StickyElement.Sticking', { detail: { sticking: this.sticking } }));
            this.element.classList.toggle('sticking', !this.sticking);
            if (this.ignoreHeader) {
                document.documentElement.classList.toggle('sticking', !this.sticking);
            }
        }

        // Refresh Offset
        const dependencyOffset = this.dependencies.reduce((sum, dependency) => {
            return sum + dependency.element.offsetHeight;
        }, 0);

        // Si ignoreHeader es true, no consideramos el header
        const headerOffset = this.ignoreHeader ? 0 :
            (window.stickyService.isHeaderVisible ? window.stickyService.headerHeight : 0);

        const previousOffset = this.offset;
        // Calcula el offset total y luego resta el valor de offsetOverlap
        this.offset = dependencyOffset + headerOffset - (this.offsetOverlap || 0);

        if (this.offset !== previousOffset) {
            // Aplicar el offset al elemento
            this.element.style.top = `${this.offset}px`;

            this.element.dispatchEvent(new CustomEvent('StickyElement.Refresh', { detail: { offset: this.offset } }));
        }
    }

    findStickyContainer() {
        let currentElement = this.element.parentElement;

        while (currentElement) {
            const style = window.getComputedStyle(currentElement);
            const overflowY = style.overflowY;
            const overflowX = style.overflowX;

            if (
                overflowY === 'auto' ||
                overflowY === 'scroll' ||
                overflowY === 'hidden' ||
                overflowX === 'auto' ||
                overflowX === 'scroll' ||
                overflowX === 'hidden'
            ) {
                return currentElement;
            }

            currentElement = currentElement.parentElement;
        }

        return this.element.parentElement;
    }
}