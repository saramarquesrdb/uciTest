export class DatalayerService {
    constructor() {
        // Inicializa el dataLayer si no existe
        if (!window.dataLayer) {
            window.dataLayer = [];
        }

        this.configuration = []; // Configuración de eventos
        this.addedEventElements = new Set(); // Para evitar duplicar eventos

        window.addEventListener('load', () => {
            const { datalayerSiteConfiguration = [], datalayerPageConfiguration = [], datalayerOnDynamicElements } = window.pageInfo ?? {};
            this.configuration = [
                ...[].concat(datalayerSiteConfiguration),
                ...[].concat(datalayerPageConfiguration)
            ];

            this.addEventListenersFromDOM(); // Agrega listeners a elementos existentes en el DOM
            this.addEventListenersFromConfig(); // Agrega eventos desde la configuración de window.pageInfo

            if (datalayerOnDynamicElements ?? false) {
                this.observeDOMChanges();
            }
        });
    }

    // Método para agregar datos al dataLayer
    push(data) {
        if (typeof data === 'object') {
            window.dataLayer.push(data);
            console.log('Data pushed to dataLayer:', data);
        } else {
            console.error('Invalid data format. Must be an object.');
        }
    }

    // Método para obtener el dataLayer actual
    getDataLayer() {
        return window.dataLayer;
    }

    // Método para limpiar el dataLayer
    clear() {
        window.dataLayer = [];
        console.log('DataLayer cleared.');
    }

    // Método para enviar un evento personalizado al dataLayer
    sendCustomEvent(eventName, eventData = {}) {
        this.push({
            event: eventName,
            ...eventData
        });
    }

    // Agrega event listeners a los elementos que tienen clases específicas con el patrón "dl:"
    addEventListenersFromDOM() {
        const elements = document.querySelectorAll('[class*="dl:"]');

        elements.forEach(element => {
            // Evitar agregar eventos duplicados al mismo elemento
            if (this.addedEventElements.has(element)) return;

            element.classList.forEach(className => {
                // Buscar coincidencias con el patrón para identificar eventos y nombres de evento
                const match = className.match(/^dl:(click|change|mouseover|focus|blur):([a-zA-Z0-9_]+)(-.*)?$/);

                if (match) {
                    const eventType = match[1]; // Tipo de evento: click, change, etc.
                    const eventName = match[2]; // Nombre del evento: test_event, submit_event, etc.
                    const paramString = match[3]; // Parámetros adicionales: -param1:valor-param2:valor, etc.

                    const params = {};
                    if (paramString) {
                        // Parsear los parámetros adicionales y agregarlos al objeto params
                        const paramPairs = paramString.slice(1).split('-');
                        paramPairs.forEach(pair => {
                            const [key, value] = pair.split(':');
                            if (key && value) {
                                params[key] = value;
                            }
                        });
                    }

                    // Agregar el listener al elemento para el tipo de evento especificado
                    element.addEventListener(eventType, () => {
                        console.log(`Event '${eventName}' triggered by ${eventType} with params:`, params);
                        this.sendCustomEvent(eventName, {
                            eventType,
                            element: element.tagName,
                            classList: element.classList.toString(),
                            ...params
                        });
                    });
                }
            });

            // Marcar el elemento como procesado para evitar duplicación de eventos
            this.addedEventElements.add(element);
        });
    }

    // Agrega event listeners desde la configuración de window.pageInfo
    addEventListenersFromConfig() {
        // Iterar sobre cada configuración y agregar los listeners correspondientes
        this.configuration.forEach(config => {
            if (Array.isArray(config)) {
                config.forEach(eventConfig => this.addListenerFromConfig(eventConfig));
            } else if (Object.keys(config).length > 0) {
                this.addListenerFromConfig(config);
            }
        });
    }

    // Método para agregar un listener basado en la configuración proporcionada
    addListenerFromConfig(config) {
        const { event, selector, on } = config;

        const props = config.props || [];
        const elements = document.querySelectorAll(selector);

        elements.forEach(element => {
            // Evitar agregar eventos duplicados al mismo elemento
            if (this.addedEventElements.has(element)) return;

            // Agregar el listener al elemento para el tipo de evento especificado
            element.addEventListener(on, () => {
                const eventData = {};

                if (on === 'submit' && !this.isFormValid(element)) return;

                // Iterar sobre las propiedades adicionales para obtener sus valores
                props.forEach(prop => {
                    const { name, value, selector } = prop;
                    let targetElement = element;

                    // Si se especifica un selector, buscar el sub-elemento dentro del elemento principal
                    if (selector) {
                        const subElement = element.querySelector(selector);
                        if (subElement) {
                            targetElement = subElement;
                        }
                    }

                    // Agregar el valor de la propiedad al objeto eventData si existe, sino agregar el valor directamente
                    if (name && value) {
                        if (targetElement[value] !== undefined) {
                            eventData[name] = targetElement[value].trim();
                        }
                        else {
                            eventData[name] = value;
                        }
                    }
                });

                console.log(`Event '${event}' triggered by ${on} with props:`, eventData);
                this.sendCustomEvent(event, eventData);
            });

            // Marcar el elemento como procesado para evitar duplicación de eventos
            this.addedEventElements.add(element);
        });
    }

    isFormValid(form) {
        if (form.matches('form[data-sc-fxb]')) {
            return $(form).valid();
        }

        return form.querySelectorAll('.form-fieldset.error').length === 0;
    }

    // Observa cambios en el DOM para agregar listeners a nuevos elementos dinámicos
    observeDOMChanges() {
        // Usar un MutationObserver para observar cambios en el DOM
        const observer = new MutationObserver(() => {
            this.addEventListenersFromDOM(); // Agregar listeners a nuevos elementos
            this.addEventListenersFromConfig(); // Agregar listeners desde la configuración a nuevos elementos
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
}
