export class GoalsService {
    constructor() {
        this.configuration = []; // Configuración de goals
        this.triggeredGoals = new Set(); // Para evitar duplicar eventos

        window.addEventListener('load', () => {
            const { goalsSiteConfiguration = [], goalsPageConfiguration = [], goalsOnDynamicElements } = window.pageInfo ?? {};
            this.configuration = [
                ...[].concat(goalsSiteConfiguration),
                ...[].concat(goalsPageConfiguration)
            ];

            this.addEventListenersFromConfig(); // Agrega eventos desde la configuración de window.pageInfo

            if (goalsOnDynamicElements ?? false) {
                this.observeDOMChanges();
            }
        });
    }

    register(goal) {
        if (typeof goal === 'string') {
            fetch(`/goals/register?goalId=${goal}`, { method: 'POST' });
            console.log('Goal registered:', goal);
        }
        else {
            console.error('Invalid data format. Must be an string.');
        }
    }

    // Agrega event listeners desde la configuración de window.pageInfo
    addEventListenersFromConfig() {
        // Iterar sobre cada configuración y agregar los listeners correspondientes
        this.configuration.forEach(config => {
            if (Array.isArray(config)) {
                config.forEach(eventConfig => this.addListenerFromConfig(eventConfig));
            } else if (Object.keys(config).length > 0) {
                this.addListenerFromConfig(config);
            }
        });
    }

    // Método para agregar un listener basado en la configuración proporcionada
    addListenerFromConfig(config) {
        //const { goal, selector, on, isUnique } = config;
        const goal = new Goal(config);
        const elements = document.querySelectorAll(goal.selector);

        elements.forEach(element => {
            element.addEventListener(goal.on, () => {
                if (goal.on === 'submit' && !this.isFormValid(element)) return;
                if (goal.isUnique && this.triggeredGoals.has(element)) return;
                this.register(goal.goal);
            });

            // Marcar el elemento como procesado para evitar duplicación de eventos
            this.triggeredGoals.add({ element });
        });
    }
}

class Goal {
    constructor({ goal, selector, on, isUnique }) {
        this.goal = goal;
        this.selector = selector;
        this.on = on;
        this.isUnique = isUnique ?? false;
    }
}
