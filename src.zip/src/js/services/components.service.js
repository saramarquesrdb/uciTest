class ComponentService {
    constructor() {
        if (!window.components) {
            window.components = [];
        }
    }

    addComponent(component) {
        window.components.push(component);
    }

    findComponent(element) {
        return window.components.find(component => component.element === element);
    }
}

export default new ComponentService();
