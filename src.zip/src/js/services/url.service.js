export const UrlService = {
    // Obtener la URL de referencia
    getReferrerUrl: function () {
        return document.referrer;
    },

    // Obtener la URL actual
    getCurrentUrl: function () {
        return window.location.href;
    },

    // Función para extraer parámetros de query string de una URL
    getQueryStringParams: function (url) {
        let params = {};
        let parser = document.createElement('a');
        parser.href = url;
        let queryString = parser.search.substring(1);
        let queries = queryString.split('&');
        for (let i = 0; i < queries.length; i++) {
            let pair = queries[i].split('=');
            if (pair[0]) {
                params[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
            }
        }
        return params;
    },

    // Función para combinar los query strings
    combineQueryStrings: function (currentParams, referrerParams) {
        for (let key in referrerParams) {
            if (!currentParams.hasOwnProperty(key)) {
                currentParams[key] = referrerParams[key];
            }
        }
        return currentParams;
    },

    // Función para añadir query string a una URL
    addQueryStringToUrl: function (url, queryString) {
        if (url.indexOf('?') === -1) {
            return url + '?' + queryString;
        } else {
            return url + '&' + queryString;
        }
    },

    // Actualizar los enlaces en la página para incluir el query string combinado
    updateLinks: function (combinedQueryString) {
        let links = document.querySelectorAll('a');
        for (let i = 0; i < links.length; i++) {
            let href = links[i].getAttribute('href');
            if (href && href.indexOf('#') !== 0 && href.indexOf('javascript:') !== 0) { // Evitar anchors y enlaces JavaScript
                links[i].setAttribute('href', this.addQueryStringToUrl(href, combinedQueryString));
            }
        }
    },

    // Función principal para combinar y actualizar query strings
    combineAndPersistQueryStrings: function () {
        let referrerUrl = this.getReferrerUrl();
        let currentUrl = this.getCurrentUrl();

        // Si no hay referrer, no hacemos nada
        if (!referrerUrl) return;

        let referrerParams = this.getQueryStringParams(referrerUrl);
        let currentParams = this.getQueryStringParams(currentUrl);

        // Combinar los parámetros
        let combinedParams = this.combineQueryStrings(currentParams, referrerParams);

        // Reconstruir el query string combinado
        let combinedQueryString = Object.keys(combinedParams).map(function (key) {
            return encodeURIComponent(key) + '=' + encodeURIComponent(combinedParams[key]);
        }).join('&');

        // Actualizar la URL actual si no contiene ya los parámetros combinados
        if (window.location.search.substring(1) !== combinedQueryString) {
            let newUrl = window.location.pathname + '?' + combinedQueryString + window.location.hash;
            window.history.replaceState({}, '', newUrl); // Actualizar sin recargar la página
        }

        // Actualizar los enlaces con el query string combinado
        //this.updateLinks(combinedQueryString);
    }
};
