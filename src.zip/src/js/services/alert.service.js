export class AlertService {
    constructor() {
        // Almacenar referencias a los handlers de scroll
        this.scrollHandlers = new WeakMap();
        // Guardar el ID del banner actual para cuando se cierre
        this.currentBannerId = null;
    }

    showAlert(model, container = null) {
        // Validar y establecer un estado por defecto si es null o undefined
        const validStates = ['error', 'info', 'success'];
        let state = model.state;

        if (!state || !validStates.includes(state)) {
            state = 'alert'; // Estado por defecto
        }

        // Construir las clases de la alerta
        let alertClasses = `alert ${model.type}`;
        let wrapClass = `alert__wrap not-${state}`;

        // Construir el HTML de la alerta
        let html = `
        <div class="${alertClasses}">
            <div class="${window.innerWidth > 768 ? 'container' : ''}">
                <div class="row">
                    <div class="col-xs-12 col-ms-12 col-sm-12 col-lg-12 col">
                        <div class="${wrapClass}">
                            ${model.icon ? `
                            <div class="alert__icon">
                                ${this.renderIcon(model.icon)}
                            </div>` : ''}
                            <div class="alert__content">
                                ${model.title ? `<h4 class="title-s">${model.title}</h4>` : ''}
                                ${model.message ? `<div class="bodycopy-s">${model.message}</div>` : ''}
                                ${this.renderActions(model.actions)}
                            </div>
                            ${model.isClosable ? this.renderCloseButton() : ''}
                        </div>
                    </div>
                </div>
            </div>
        </div>`;

        // Insertar la alerta en el DOM según el tipo
        switch (model.type) {
            case 'banner':
                this.insertBanner(html, model);
                break;
            case 'toast':
                this.insertToast(html);
                break;
            case 'inline':
                this.insertInline(html, container);
                break;
            default:
                console.error(`Tipo de alerta no reconocido: ${model.type}`);
        }
    }

    // Método para insertar el banner
    insertBanner(html, model) {
        const dismissBehavior = model.dismissBehavior || 'reload';
        const checksum = this.generateChecksum(JSON.stringify(model));
        const bannerId = model.id;

        // Guardar referencia al ID del banner actual
        this.currentBannerId = bannerId;

        // Si no hay ID, usar comportamiento legacy sin persistencia
        if (!bannerId) {
            console.warn('Banner sin ID - usando comportamiento legacy');
            if (dismissBehavior === 'reload') {
                this.insertBannerElement(html);
            }
            return;
        }

        // Verificar si debe mostrarse
        if (!this.shouldShowBanner(dismissBehavior, checksum, bannerId)) {
            return;
        }

        this.insertBannerElement(html);

        // Guardar estado del banner
        this.saveBannerState(dismissBehavior, checksum, bannerId);
    }

    insertBannerElement(html) {
        const header = document.querySelector('header');
        const bannerElement = this.createElementFromHTML(html);

        // Insertar el banner antes del header
        header.parentNode.insertBefore(bannerElement, header);

        const handleScroll = () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            if (scrollTop === 0) {
                bannerElement.style.display = 'block';
                if (window.innerWidth >= 1024) {
                    header.style.top = `${bannerElement.offsetHeight}px`;
                }
            } else {
                bannerElement.style.display = 'none';
                header.style.top = '0';
            }
        };

        // Asegurar que el banner esté visible inicialmente
        bannerElement.style.display = 'block';

        // Ejecutar una vez al inicio
        handleScroll();

        // Añadir el listener y guardar la referencia
        window.addEventListener('scroll', handleScroll, { passive: true });
        this.scrollHandlers.set(bannerElement, handleScroll);

        document.body.classList.add('banner');
    }

    insertToast(html) {
        // Insertar el toast al final del body
        const toastElement = this.createElementFromHTML(html);
        document.body.appendChild(toastElement);

        // Ocultar el toast después de 5 segundos con fade-out
        setTimeout(() => {
            this.fadeOutAndRemove(toastElement);
        }, 5000); // 5 segundos
    }

    insertInline(html, container) {
        // Verificar si container es un selector o un elemento
        let targetElement = null;

        if (typeof container === 'string') {
            targetElement = document.querySelector(container);
        } else if (container instanceof HTMLElement) {
            targetElement = container;
        } else {
            console.error('Se requiere un selector o elemento HTML válido para mostrar una alerta inline.');
            return;
        }

        if (targetElement) {
            targetElement.innerHTML = html;
        } else {
            console.error('Elemento no encontrado para mostrar la alerta inline.');
        }
    }

    // Determinar si el banner debe mostrarse
    shouldShowBanner(dismissBehavior, checksum, bannerId) {
        if (dismissBehavior === 'reload') {
            return true; // Siempre mostrar para 'reload'
        }

        const storedData = this.getBannerState(dismissBehavior, bannerId);

        if (!storedData) {
            return true; // No hay datos, mostrar
        }

        if (storedData.checksum !== checksum) {
            // Contenido cambió, limpiar y mostrar
            this.clearBannerState(bannerId);
            return true;
        }

        // No mostrar si fue dismissed
        return !storedData.dismissed;
    }

    // Guardar estado del banner
    saveBannerState(dismissBehavior, checksum, bannerId) {
        if (dismissBehavior === 'reload') return;

        const data = { dismissed: false, checksum: checksum };
        const storageKey = `bannerState_${bannerId}`;

        // Migrar datos si es necesario
        this.migrateBannerData(dismissBehavior, bannerId, data);

        if (dismissBehavior === 'session') {
            sessionStorage.setItem(storageKey, JSON.stringify(data));
        } else if (dismissBehavior === 'persistent') {
            localStorage.setItem(storageKey, JSON.stringify(data));
        }
    }

    // Obtener estado del banner
    getBannerState(dismissBehavior, bannerId) {
        const storageKey = `bannerState_${bannerId}`;
        let storedData = null;

        if (dismissBehavior === 'session') {
            storedData = sessionStorage.getItem(storageKey);
        } else if (dismissBehavior === 'persistent') {
            storedData = localStorage.getItem(storageKey);
        }

        return storedData ? JSON.parse(storedData) : null;
    }

    // Migrar datos entre storages
    migrateBannerData(newBehavior, bannerId, newData) {
        const storageKey = `bannerState_${bannerId}`;

        const sessionData = sessionStorage.getItem(storageKey);
        const localData = localStorage.getItem(storageKey);

        if (newBehavior === 'session' && localData) {
            const existingData = JSON.parse(localData);
            if (existingData.dismissed) {
                newData.dismissed = true;
            }
            localStorage.removeItem(storageKey);
        } else if (newBehavior === 'persistent' && sessionData) {
            const existingData = JSON.parse(sessionData);
            if (existingData.dismissed) {
                newData.dismissed = true;
            }
            sessionStorage.removeItem(storageKey);
        }
    }

    // Marcar banner como dismissed
    setBannerDismissed(bannerId) {
        const storageKey = `bannerState_${bannerId}`;

        const sessionData = sessionStorage.getItem(storageKey);
        if (sessionData) {
            const data = JSON.parse(sessionData);
            data.dismissed = true;
            sessionStorage.setItem(storageKey, JSON.stringify(data));
        }

        const localData = localStorage.getItem(storageKey);
        if (localData) {
            const data = JSON.parse(localData);
            data.dismissed = true;
            localStorage.setItem(storageKey, JSON.stringify(data));
        }
    }

    // Limpiar estado del banner
    clearBannerState(bannerId) {
        if (bannerId) {
            // Limpiar banner específico
            const storageKey = `bannerState_${bannerId}`;
            sessionStorage.removeItem(storageKey);
            localStorage.removeItem(storageKey);
        }
    }

    // Cerrar alerta
    closeAlert(closeButton) {
        const alertElement = closeButton.closest('.alert');
        const header = document.querySelector('header');

        if (alertElement) {
            const handler = this.scrollHandlers.get(alertElement);
            if (handler) {
                window.removeEventListener('scroll', handler);
                this.scrollHandlers.delete(alertElement);
            }
            header.style.top = '0';
            this.fadeOutAndRemove(alertElement);
        }

        if (document.body.classList.contains('banner')) {
            document.body.classList.remove('banner');
        }

        // Marcar como dismissed usando el ID guardado
        if (this.currentBannerId) {
            this.setBannerDismissed(this.currentBannerId);
        }
    }

    // Métodos auxiliares

    renderIcon(iconName) {
        // Utilizar el icono proporcionado en el modelo
        if (!iconName) {
            return ''; // No devolver nada si no hay icono
        }

        return `<svg class="icon icon-${iconName}">
                    <use xlink:href="/dist/icons/icons.svg#${iconName}"></use>
                </svg>`;
    }

    renderActions(actions) {
        if (!actions || actions.length === 0) return '';
        return `
        <ul class="alert__links">
            ${actions
                .map((action) => {
                    const className = action.isButton ? 'btn btn_secondary' : 'link';
                    return `<li><a href="${action.href}" class="${className}">${action.text}</a></li>`;
                })
                .join('')}
        </ul>`;
    }

    renderCloseButton() {
        return `
        <div class="alert__close" onclick="alertService.closeAlert(this)">
            ${this.renderIcon('x_24x24')}
        </div>`;
    }

    generateChecksum(str) {
        let hash = 0, i, chr;
        if (str.length === 0) return hash;
        for (i = 0; i < str.length; i++) {
            chr = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + chr;
            hash |= 0;
        }
        return hash;
    }

    createElementFromHTML(htmlString) {
        const div = document.createElement('div');
        div.innerHTML = htmlString.trim();
        return div.firstElementChild;
    }

    fadeOutAndRemove(element) {
        element.style.transition = 'opacity 0.3s';
        element.style.opacity = '1';

        // Forzar el reflujo para asegurar que la transición ocurra
        void element.offsetWidth;

        element.style.opacity = '0';

        setTimeout(() => {
            if (element.parentNode) {
                element.parentNode.removeChild(element);
            }
        }, 300);
    }
}