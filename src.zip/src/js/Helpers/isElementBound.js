const isElementBound = (parent, child, padding) => parent.getBoundingClientRect().right
  >= child.getBoundingClientRect().right + padding;

export default isElementBound;
