const hideOrShow = (elementsArray, action) => {
  elementsArray.map(el => {
    const thisElement = document.getElementsByClassName(el);

    for (let i = 0; i < thisElement.length; i++) {
      thisElement[i].style.display = action;
    }
  });
};

export default hideOrShow;
