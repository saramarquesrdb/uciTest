import getClosestElement from './getClosestElement';

const handlePagination = (el, page, pages) => {
  el.querySelectorAll('.pagination__item').forEach(item => { item.classList.remove('active'); });

  const paginationElements = Array.from(el.querySelectorAll('li[class*=pagination-]'));

  paginationElements[0].style.visibility = (page === 1) ? 'hidden' : 'visible';
  if (page === 1) paginationElements[1].classList.add('active');
  paginationElements[2].style.display = (pages > 4 && page > 3) ? 'block' : 'none';

  if (pages === 2) {
    paginationElements[3].style.display = 'none';
    paginationElements[4].style.display = 'none';
    paginationElements[5].style.display = 'none';
  }

  if (pages === 3) {
    paginationElements[3].style.display = 'block';
    paginationElements[3].querySelector('.pagination__link').innerHTML = 2;
    if (page === 2) paginationElements[3].classList.add('active');
    paginationElements[4].style.display = 'none';
    paginationElements[5].style.display = 'none';
  }

  if (pages === 4) {
    paginationElements[3].style.display = 'block';
    paginationElements[3].querySelector('.pagination__link').innerHTML = 2;
    if (page === 2) paginationElements[3].classList.add('active');
    paginationElements[4].style.display = 'block';
    paginationElements[4].querySelector('.pagination__link').innerHTML = 3;
    if (page === 3) paginationElements[4].classList.add('active');
    paginationElements[5].style.display = 'none';
  }

  if (pages > 4) {
    if (page === 1 || page === 2) {
      paginationElements[3].style.display = 'block';
      paginationElements[3].querySelector('.pagination__link').innerHTML = 2;
      if (page === 2) paginationElements[3].classList.add('active');
      paginationElements[4].style.display = 'block';
      paginationElements[4].querySelector('.pagination__link').innerHTML = 3;
      if (page === 3) paginationElements[4].classList.add('active');
      paginationElements[5].style.display = 'none';
    } else if (page === pages || page === (pages - 1)) {
      paginationElements[3].style.display = 'block';
      paginationElements[3].querySelector('.pagination__link').innerHTML = pages - 2;
      paginationElements[4].style.display = 'block';
      paginationElements[4].querySelector('.pagination__link').innerHTML = pages - 1;
      if (page === pages - 1) paginationElements[4].classList.add('active');
      paginationElements[5].style.display = 'none';
    } else {
      paginationElements[3].style.display = 'block';
      paginationElements[3].querySelector('.pagination__link').innerHTML = page - 1;
      paginationElements[4].style.display = 'block';
      paginationElements[4].querySelector('.pagination__link').innerHTML = page;
      paginationElements[4].classList.add('active');
      paginationElements[5].style.display = 'block';
      paginationElements[5].querySelector('.pagination__link').innerHTML = page + 1;
    }
  }

  paginationElements[6].style.display = (pages > 4 && (pages - page > 2)) ? 'block' : 'none';
  if (page === pages) paginationElements[7].classList.add('active');
  paginationElements[7].querySelector('.pagination__link').innerHTML = pages;
  paginationElements[8].style.visibility = (page !== pages) ? 'visible' : 'hidden';

  if (pages > 1) {
    el.style.display = el.getAttribute('data-display') ?? 'block';
  } else {
    el.style.display = 'none';
  }
};


const pagination = function (el, page, pages, skipEventListeners) {
  const totalEl = el.querySelector('.pagination__link.total');
  if (totalEl) {
    totalEl.innerHTML = pages;
  }

  const paginationLinkEventHandler = e => {
    const current = parseInt(el.querySelector('.active').innerText, 10);
    const linkEl = getClosestElement(e.target, '.pagination__link');
    let target;
    if (linkEl.classList.value.includes('pagination__next')) {
      target = parseInt(el.querySelector('.active').innerText, 0) + 1;
    } else if (linkEl.classList.value.includes('pagination__prev')) {
      target = parseInt(el.querySelector('.active').innerText, 0) - 1;
    } else {
      target = parseInt(linkEl.innerText, 0);
    }

    if (current !== target) {
      el.dispatchEvent(new CustomEvent('pageChange', { detail: target }));
      handlePagination(el, target, pages);
    }
  };

  el.querySelectorAll('.pagination__link').forEach(ev => {
    if (!skipEventListeners) {
      ev.addEventListener('click', paginationLinkEventHandler);
    }
  });

  handlePagination(el, page, pages);
};

export default pagination;
