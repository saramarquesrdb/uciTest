const exchangeData = {
    activeLightboxFormID: ""
}
export default exchangeData;
