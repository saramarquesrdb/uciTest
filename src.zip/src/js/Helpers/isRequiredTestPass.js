const isRequiredTestPass = (required, action) => (required ? action : true);

export default isRequiredTestPass;
