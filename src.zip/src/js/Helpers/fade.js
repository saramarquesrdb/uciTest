export const fadeOut = (
  target,
  callback,
  callbackArgument,
  step = 0.01,
  stepDuration = 5,
) => {
  let targetOpacity = 1;
  target.style.opacity = targetOpacity;

  const fadeEffect = setInterval(() => {
    if (targetOpacity > 0) {
      targetOpacity -= step;
      target.style.opacity = targetOpacity;
    } else {
      clearInterval(fadeEffect);
      target.style.display = 'none';

      if (callback) {
        callback(callbackArgument);
      } else if (callback) {
        callback();
      }
    }
  }, stepDuration); // A duration/interval for chosen opacity step change
};

export const fadeIn = (
  target,
  callback,
  callbackArgument,
  step = 0.01,
  stepDuration = 5,
) => {
  let targetOpacity = 0.01;
  target.style.opacity = targetOpacity;
  target.style.display = 'block';

  const fadeEffect = setInterval(() => {
    if (targetOpacity < 1) {
      targetOpacity += step;
      target.style.opacity = targetOpacity;
    } else {
      clearInterval(fadeEffect);

      if (callbackArgument) {
        callback(callbackArgument);
      } else if (callback) {
        callback();
      }
    }
  }, stepDuration); // A duration/interval for chosen opacity step change
};
