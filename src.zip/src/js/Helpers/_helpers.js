export const $ = (selector, context) => (context || document).querySelector(selector);
export const $all = (selector, context) => Array.from((context || document).querySelectorAll(selector));

export const localeFormatNumber = (number, decimalsMax, decimalsMin) => {
  // Sample: 210000.20 -> 210.000,20
  let output = parseFloat(number.replace(/\./g, '').replace(',', '.')).toLocaleString('de-DE', {
    style: 'decimal',
    maximumFractionDigits: decimalsMax,
    minimumFractionDigits: decimalsMin,
  });
  if (output === 'NaN') output = '0';
  return output;
};

export const formatNumberToSpanish = (num) => {
  return new Intl.NumberFormat('es-ES', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(num);
}

export const stdNumber = number => {
  let output = parseFloat(number.toString().replace(/\./g, '').replace(',', '.'));
  if (Number.isNaN(output)) {
    output = '';
  }
  return output;
};

export const restrictInputOnlyNumbersAndPeriods = event => {
  const inputField = event.target;
  const inputValue = inputField.value;

  // Remove any characters that are not numbers or periods
  const sanitizedValue = inputValue.replace(/[^0-9.]/g, '');

  // Update the input field with the sanitized value
  inputField.value = sanitizedValue;
};

export const fractal = () => {
  return location.href.includes('components') || location.host.startsWith('local');
  //if run in Fractal return true;
}

export const local = () => {
    return location.host.startsWith('localhost');
    //if run in Fractal return true;
}

export const debug = () => {
  return location.host.startsWith('localhost') || location.href.includes('debug');
}

export const jsLog = (...args) => {
  if (debug() || location.href.includes('local')) {
    console.log(...args);
  }
}

export const setAccessSelect = (accessClass, optionValue) => {
  const accessElement = document.querySelector(accessClass);
  const selectOption =  accessElement.querySelector('.access-select__option[value="' + optionValue + '"]')
  selectOption.click()
}

export const smoothScroll = (target, targetOffset, duration) => {
    const isWindow = target === window;
    const start = isWindow ? window.scrollY || window.pageYOffset : target.scrollTop;
    const startTime = performance.now();
    const targetPosition = typeof targetOffset === 'number' ? targetOffset : targetOffset.offsetTop;

    function scroll(timestamp) {
        const elapsed = timestamp - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const newPosition = start + (targetPosition - start) * progress;

        if (isWindow) {
            window.scrollTo(0, newPosition - 100);
        } else {
            target.scrollTop = newPosition;
        }

        if (progress < 1) {
            requestAnimationFrame(scroll);
        }
    }

    requestAnimationFrame(scroll);
/*
    SAMPLES OF USe
// Scroll on the window
    smoothScroll(window, 500, 1000); // Scroll to offset 500 on the window in 1 second

// Scroll within an element
    const container = document.getElementById('scrollContainer');
    const section = document.getElementById('sectionToScrollTo');
    smoothScroll(container, section, 1500); // Scroll to 'sectionToScrollTo' within 'scrollContainer' in 1.5 seconds
*/
}
