const lightboxScrollOnError = (form, duration) => {
    const lightboxWindow = form.closest(".lightbox__window");
    const error = form.querySelector('.form-fieldset.error');

    function calculateDistanceToParent(element, parent) {
        let distance = 0;
        while (element && element !== parent) {
            distance += element.offsetTop + 30;
            element = element.offsetParent;
        }
        return distance;
    }

    const start = lightboxWindow.scrollTop;
    const end = calculateDistanceToParent(error, lightboxWindow);
    const startTime = performance.now();

    function scroll(timestamp) {
        const elapsed = timestamp - startTime;
        const progress = Math.min(elapsed / duration, 1);
        lightboxWindow.scrollTop = start + (end - start) * progress;

        if (progress < 1) {
            requestAnimationFrame(scroll);
        }
    }

    requestAnimationFrame(scroll);
};

export default lightboxScrollOnError;