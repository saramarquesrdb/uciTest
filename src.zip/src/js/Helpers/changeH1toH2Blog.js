const changeH1ToH2 = () => {
  const h1Fix = document.querySelector('.post-headline__head-wrapper.sticky-clone__wrapper').querySelector('.post-headline__title');
  const newH2 = document.createElement('p');
  newH2.classList.add('bodycopy-l');
  newH2.innerText = h1Fix.querySelector('.title-xl').textContent.replace(/[\n]/g, '');
  h1Fix.removeChild(h1Fix.querySelector('.title-xl'));
  h1Fix.appendChild(newH2);
};

export default changeH1ToH2;
