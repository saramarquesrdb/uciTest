import getElementPosition from './getElementPosition';

const scrollTo = (
    destination,
    duration = 200, // ignored legacy parameter for backwards compatibility
    offset = 0,
    easing = 'linear', // ignored legacy parameter for backwards compatibility
    callback
) => {
    let targetScroll = undefined;

    if (typeof destination === 'number') {
        targetScroll = destination - offset;
        window.scrollTo({
            top: targetScroll,
            behavior: 'smooth'
        });
    } else {
        targetScroll = getElementPosition(destination).y - offset
        window.scroll({
            top: targetScroll,
            behavior: 'smooth'
        });
    }

    if (typeof callback === 'function') {
        // used 200ms as the time to wait for to trigger the callback as it's 
        // not possible to know when the scroll is over
        setTimeout(callback, 200);
    }
};

export default scrollTo;