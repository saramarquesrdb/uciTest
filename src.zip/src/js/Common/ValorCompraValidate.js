
const valorCompraValidate = (
    inputValorCompra,
    inputCapitalPropio,
    fieldValidationCapitalPropio,
    percentageNumber,
    spanErrorMessageElement, 
    percentageErrorMessage,
    isAdquisicion,
    errorClassname = 'error',
    validClassname = 'valid', 
  ) => {
  
    var vc = Number(inputValorCompra.value.replace('.', ''));
    var cp = Number(inputCapitalPropio.value.replace('.', ''));
  
    //Validate depending on valor compra
    if((cp == 0 || cp < vc*percentageNumber) && (isAdquisicion))
    {
      if (!fieldValidationCapitalPropio.classList.contains(errorClassname)) {
        fieldValidationCapitalPropio.classList.remove(validClassname);
        fieldValidationCapitalPropio.classList.add(errorClassname);
      }
      if(spanErrorMessageElement)
      {
        spanErrorMessageElement.textContent = percentageErrorMessage;
      }
  
      return false;
    }
    else{
      if (!fieldValidationCapitalPropio.classList.contains(validClassname)) {
        fieldValidationCapitalPropio.classList.add(validClassname);
        fieldValidationCapitalPropio.classList.remove(errorClassname);
      }
      return true;
    }  
  
  };
  
  export default valorCompraValidate;
