import pagination from '../Helpers/jsPagination';

const initPagination = () => {
    document.querySelectorAll('.pagination.generic').forEach(x => {
        pagination(x, 1, parseInt(x.getAttribute('data-pages')), false);
        const paginationContainer = document.querySelector(`[data-pagination-id="${x.getAttribute('data-reference')}"]`);
        if (paginationContainer) {
            x.addEventListener('pageChange', function (data) {
                const display = paginationContainer.getAttribute('data-display') ?? 'block';
                Array.from(paginationContainer.children).forEach(element => {
                    element.style.display = parseInt(element.getAttribute('data-page')) === data.detail ? display : 'none';
                });
            })
        }

    });
}

export default initPagination;
