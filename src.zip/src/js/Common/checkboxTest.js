const checkboxTest = checkbox => {
  if (checkbox) {
    for (let i = 0; i < checkbox.length; i++) {
      const thisCheckbox = checkbox[i];

      if (!thisCheckbox.checked) {
        return false;
      }
      if (i === checkbox.length - 1) {
        return true;
      }
    }
  }
  return false;
};

export default checkboxTest;
