import noUiSlider from 'nouislider';
import divideANumberWithDots from '../Helpers/divideANumberWithDots';

const rangeSlider = (sliderSelector, inputSelector, step) => {
  const slider = document.querySelector(sliderSelector);
  const input = document.querySelector(inputSelector);
  const minValue = input ? Number(input.min) : null;
  const maxValue = input ? Number(input.max) : null;
  const defaultValue = input ? Number(input.dataset.default) : null;
  let inputValue = "";
  let realValue = "";

  if (slider && input) {
    const obj = noUiSlider.create(slider, {
      start: defaultValue,
      connect: [true, false],
      step,
      range: {
        min: minValue,
        max: maxValue,
      },
    });

    slider.noUiSlider.on('update', (values, handle) => {
      inputValue = values[handle];
      input.value = divideANumberWithDots(Math.round(inputValue));
      input.focus({ preventScroll: true });
    });

    slider.noUiSlider.on('end', () => {
      input.dispatchEvent(new Event('change'));
    });

    input.addEventListener('change', function (e) {
      slider.noUiSlider.set(this.value.split('.').join(''));
    });

    input.addEventListener('keyup', (event) => {
      input.value = input.value.replace(/[a-zA-Z]/g, '');
    });

    return obj;
  }
};

export default rangeSlider;
