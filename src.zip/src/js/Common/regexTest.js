const regexTest = (regex, input) => {
  if (input != null && !regex.test(input.value)) {
    return false;
  }

  return true;
};

export default regexTest;
