const NumberValidate = (
    input,
    parent,
    errorClassname = 'error',
    validClassname = 'valid',
    required = false,
    min,
    max,
    spanMessageElement,
    requiredMessage  = "",
    rangeMessage = "", 
    InputItem,
  ) => {

   var inputVisible = true; 
  if(InputItem !== null)
    {
    if (window.getComputedStyle(InputItem).display === "none")
    {
      inputVisible = false; 
    }

    if((InputItem.classList.contains('hidden') && 
    ((window.getComputedStyle(InputItem).display === "block") || (window.getComputedStyle(InputItem).display === "flex"))))
    {
      inputVisible = true; 
    }

  }
  if(!inputVisible)
    {
  
      if (parent.classList.contains(errorClassname)) {
        parent.classList.remove(errorClassname);
        
      }
      parent.classList.add(validClassname);
      return true; 
    }
  
  
  
  var valueNumber = Number(input.value.replace('.', ''));
    if(required && valueNumber == 0)
    {
      if (!parent.classList.contains(errorClassname)) {
        parent.classList.remove(validClassname);
        parent.classList.add(errorClassname);
      }
  
      if(spanMessageElement)
        {
          spanMessageElement.textContent = requiredMessage;
        }
        return false; 
    }
    
    
  
    if(max && min)
    {
      if(valueNumber < min || valueNumber > max)
      {
        if (!parent.classList.contains(errorClassname)) {
          parent.classList.remove(validClassname);
          parent.classList.add(errorClassname);
          
        }
        if(spanMessageElement)
        {
          spanMessageElement.textContent = rangeMessage;
        }
  
        return false;
  
      }
    }
  
  //Has been validated
      if (parent.classList.contains(errorClassname)) {
        parent.classList.remove(errorClassname);
      }
      parent.classList.add(validClassname);
      return true; 
    
  };
  
  export default NumberValidate;
  