// Old Edge polyfiills for iMask
import 'core-js/features/object/assign';
import 'core-js/features/string/repeat';
import 'core-js/features/string/pad-start';
import 'core-js/features/string/pad-end';
import 'core-js/features/global-this';
//--

import proceduresLoginForms from '@/js/Common/forms/proceduresLoginForms';
import userAccessAjax from '@/js/Pages/digitalJourney/userAccessAjax';
import applicationFormDJ from '@/js/Forms/djForm/djForm';
import inputEvents from '@/js/Common/forms/inputEvents';
import fixNumberField from '@/js/Common/forms/fixNumberField';
import contactForm from './forms/contactForms';
import simulatorForms from './forms/simulatorForms';
import simulatorFormsUciPt from './forms/simulatorFormsUciPt';
import applicationForms from './forms/applicationForm';
import applicationFormsUciPt from './forms/applicationFormUciPt';
import landingForms from './forms/landingForms';
import prequalifierForms from './forms/prequalifierForm';
import calculatorForms from './forms/calculatorform';
import maxFinanceCalculatorForm from './forms/calculatorform-max-finance';
import communityCalculator from '../Modules/communityCalculator/communityCalculator';
import mortgagePaymentCalculator from '../Modules/mortgagePaymentCalculator/mortgagePaymentCalculator';
import mortgagePaymentSummary from '../Modules/mortgagePaymentCalculator/mortgagePaymentSummary';


import mortgageApplicationProduct from '../Modules/MortgageApplicationProduct/mortgageApplicationProduct';
import IcoCalculator from '../Modules/ICOCalculator/IcoCalculator';
import { IcoSimulator } from './forms/icoSimulator';


const forms = () => {
  // /////////////////////    VALIDATE AND TEST FORMS   ///////////////////////////

  // Application form - Unique Form
  const applicationForm = document.getElementById('applicationForm');
  if (applicationForm) {
    applicationForms(applicationForm);
  }


  // Application form Digital Journey - Unique Form
  const appFormDJ = document.getElementById('applicationFormDJ');
  if (appFormDJ) {
    applicationFormDJ(appFormDJ);
  }

  // Application form uciPt - Unique Form
  const applicationFormUciPt = document.getElementById(
    'applicationFormUciPt'
  );
  if (applicationFormUciPt) {
    applicationFormsUciPt(applicationFormUciPt);
  }

  // Contact Form - Multiple forms
  const contactForms = document.getElementsByClassName(
    'form-distinguisher_contact-form'
  );
  for (let q = 0; q < contactForms.length; q++) {
    const thisForm = contactForms[q];
    contactForm(thisForm);
  }

  // Simulator Form - Unique Form
  const simulatorForm = document.getElementById('simulatorForm');
  if (simulatorForm) {
    simulatorForms(simulatorForm);
  }

  // Simulator Form - Unique Form
  const simulatorFormUciPt = document.getElementById('simulatorFormUciPt');
  if (simulatorFormUciPt) {
    simulatorFormsUciPt(simulatorFormUciPt);
  }

  // Landing Form - Multiple Forms
  const landingForm = document.querySelectorAll('.formLanding');
  for (let j = 0; j < landingForm.length; j++) {
    landingForms(landingForm[j]);
  }

  // Format Numeric Fields (needs class format-type-number
  const allInputTypeNumber = document.querySelectorAll('input[type="number"].format-type-number');

  if (allInputTypeNumber.length > 0) {
    [...allInputTypeNumber].forEach(input => {
      fixNumberField(input.closest('form'), input);
    });
  }

  // PrequalifierForm - Unique Form
  const prequalifierForm = document.querySelector('.prequalifier-form-main');
  if (prequalifierForm) {
    prequalifierForms(prequalifierForm);
  }

  // DJ Login Formm - Multiple Forms
  const djLoginForm = document.querySelectorAll('.login-form__form');
  for (let i = 0; i < djLoginForm.length; i++) {
    proceduresLoginForms(djLoginForm[i]);
  }

  // Reset Pass Form
  const changePassForm = document.getElementById('change-pass-form');
  if (changePassForm) {
    userAccessAjax.changePass(changePassForm);
  }

  // Application form - Unique Form
  const calculatorForm = document.getElementById('calculatorForm');
  if (calculatorForm) {
    calculatorForms(calculatorForm);
  }

  const maxFinanceCalculator = document.getElementById(
    'maxFinanceCalculatorForm'
  );
  if (maxFinanceCalculator) {
    maxFinanceCalculatorForm(maxFinanceCalculator);
  }

  // // Calc form - Communities
  const communityCalculatorElement = document.getElementById('community-calculator');
  communityCalculatorElement && communityCalculator(communityCalculatorElement);


  // // Calc form - Mortgages payments
  const mortgagePaymentCalculatorElement = document.getElementById('mortgage-payment-calculator-form-with-result');
  mortgagePaymentCalculatorElement && mortgagePaymentCalculator(mortgagePaymentCalculatorElement);

  const mortgagePaymentSummaryElement = document.getElementById('quota-simulation-summary');
  mortgagePaymentSummaryElement && mortgagePaymentSummary(mortgagePaymentSummaryElement);


  const IcoCalculatorElement = document.getElementById('ico-simulator');
  IcoCalculatorElement && IcoCalculator(IcoCalculatorElement);

  // ICO Simulator
  const icoSimulatorForm = document.getElementById('icoSimulatorForm');
  icoSimulatorForm && new IcoSimulator(icoSimulatorForm);

  //mortgageApplicationProduct
  const mortgageApplicationProductForm = document.getElementById('mortgageApplicationProduct');
  mortgageApplicationProductForm && new mortgageApplicationProduct(mortgageApplicationProductForm);


    //mortgageApplicationProductçSteps
    const mortgageApplicationProductSteps = document.getElementById('mortgageApplicationProductSteps');
    mortgageApplicationProductSteps && new mortgageApplicationProduct(mortgageApplicationProductSteps);

  // Events for form elements
  inputEvents();
};

export default forms;
