const moveLast = (
  elementClassname,
  afterClassname,
  activeClassname = 'active',
  from = ''
) => {
  const elements = document.getElementsByClassName(elementClassname);

  if (!elements) return;

  let parent = document;
  if (from !== '') {
    const index = 0;
    const arrayOfElement = document.getElementsByClassName(from);
    parent = arrayOfElement[index];
  }

  if (!parent) return;

  const objToMove = [];

  for (let i = 0, len = elements.length; i < len; i++) {
    const element = elements[i];
    element.classList.remove(afterClassname);
    objToMove.push(element);
  }

  const elementList = parent.getElementsByClassName(afterClassname);
  if (!elementList) return;
  const lastElement = elementList[elementList.length - 1];

  for (let i = 0, len = objToMove.length; i < len; i++) {
    const element = objToMove[i];
      if (lastElement) {
          lastElement.parentElement.insertBefore(element, lastElement.nextSibling);
      }
    element.classList.add(afterClassname);
    element.classList.add(activeClassname);
  }
};

export default moveLast;
