// Vendor
import 'dom-slider';
//--

// Faq
const accordion = (
  accordionClassname,
  triggerClassname,
  contentClassname,
  mediaQueryString,
  duration = 400,
  activeClassname = 'active',
) => {
  const instance = document.getElementsByClassName(accordionClassname);
  let flag = true;

  for (let i = 0; i < instance.length; i++) {
    const trigger = instance[i].getElementsByClassName(triggerClassname);
    const content = instance[i].getElementsByClassName(contentClassname);

    for (let j = 0; j < trigger.length; j++) {
      const thisTrigger = trigger[j];
      const thisContent = content[j];

      const activateAccordion = () => {
        if (flag) {
          flag = false;

          if (!thisTrigger.classList.contains(activeClassname)) {
            for (let k = 0; k < trigger.length; k++) {
              if (
                trigger[k] !== thisTrigger
                && trigger[k].classList.contains(activeClassname)
              ) {
                trigger[k].classList.remove(activeClassname);
                content[k].slideUp(duration);
              }
            }

            thisTrigger.classList.add(activeClassname);
            thisContent.slideDown(duration).then(() => {
              flag = true;
            });
          } else {
            thisTrigger.classList.remove(activeClassname);
            thisContent.slideUp(duration).then(() => {
              flag = true;
            });
          }
        }
      };

      if (mediaQueryString) {
        const doesMediaQueryMatch = mediaQuery => {
          if (mediaQuery.matches) {
            trigger[j].addEventListener('click', activateAccordion);

            trigger[j].addEventListener('focus', activateAccordion);
          } else {
            trigger[j].removeEventListener('click', activateAccordion);

            trigger[j].removeEventListener('focus', activateAccordion);
          }
        };

        const mediaQuery = window.matchMedia(mediaQueryString);
        doesMediaQueryMatch(mediaQuery);
        mediaQuery.addListener(doesMediaQueryMatch);
      } else {
        trigger[j].addEventListener('click', activateAccordion);
      }
    }
  }
};

export default accordion;
