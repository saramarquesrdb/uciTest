import Swiper from 'swiper';
import YouTubePlayer from 'youtube-player';

// Testimonials
const testimonialsBgSlider = new Swiper(
  '.testimonials__swiper-background .swiper-container',
  {
    effect: 'fade',
    watchSlidesVisibility: true,
    watchSlidesProgress: true,
    noSwipingClass: 'testimonials__swiper-background',
  },
);

if (!window.matchMedia('(min-width: 1024px)').matches) {
  const testimonialsSlider = new Swiper(
    '.testimonials__swiper .swiper-container',
    {
      slidesPerView: 'auto',
      effect: 'slide',
      spaceBetween: 10,
      centeredSlides: true,
      watchOverflow: true,
      navigation: {
        nextEl: '.tile-testimonial__forward',
        prevEl: '.tile-testimonial__back',
      },
      grabCursor: true,
      thumbs: {
        swiper: testimonialsBgSlider,
      },
      breakpoints: {
        768: {
          spaceBetween: 30,
        },
        1024: {
          slidesPerView: 1,
          spaceBetween: 0,
          centeredSlides: false,
          grabCursor: false,
          noSwipingClass: 'testimonials__swiper',
        },
      },
    },
  );
} else {
  const testimonialsSlider = new Swiper(
    '.testimonials__swiper .swiper-container',
    {
      effect: 'fade',
      noSwipingClass: 'testimonials__swiper',
      watchOverflow: true,
      navigation: {
        nextEl: '.tile-testimonial__forward',
        prevEl: '.tile-testimonial__back',
      },
      thumbs: {
        swiper: testimonialsBgSlider,
      },
    },
  );
}

// Reviews
document.querySelectorAll('.reviews__swiper .swiper-container').forEach(slider => new Swiper(slider, {
  slidesPerView: 1,
  effect: 'slide',
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: `#${slider.dataset.id} .reviews__nav-forward`,
    prevEl: `#${slider.dataset.id} .reviews__nav-back`,
  },
  grabCursor: true,
  breakpoints: {
    768: {
      slidesPerView: 2,
      slidesPerGroup: 2,
      spaceBetween: 30,
    },
    1024: {
      slidesPerView: 2,
      slidesPerGroup: 2,
      spaceBetween: 447,
      speed: 1000,
      grabCursor: false,
      noSwipingClass: 'reviews__swiper',
    },
  }
}));


// Product
document.querySelectorAll('.product-swiper .swiper-container').forEach(slider => {
  const swiper = new Swiper(slider, {
    slidesPerView: 1,
    spaceBetween: 10,
    watchOverflow: true,
    autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
    navigation: {
      nextEl: `#${slider.id} .product__nav-forward`,
      prevEl: `#${slider.id} .product__nav-back`,
    },
    grabCursor: true,
    breakpoints: {
      768: {
        spaceBetween: 30,
      },
    },
  });

  // Variables globales
  const players = [];
  const states = [];

  // Inicializar Swiper si hay un iframe en el slider
  if (slider.querySelector('iframe')) {
    window.swiper = swiper;
  }

  // Event Listeners para el slider
  slider.addEventListener('mouseenter', stopAutoplay);
  slider.addEventListener('mouseleave', resumeAutoplayIfNoPlaying);

  // Inicializar YouTube Players para cada iframe
  initializeYouTubePlayers();

  // Pausar videos al cambiar de slide
  swiper.on('slideChangeTransitionStart', pauseAllVideos);

  // Funciones

  function stopAutoplay() {
    swiper.autoplay.stop();
  }

  function resumeAutoplayIfNoPlaying() {
    if (!states.some(state => state.state === 1)) {
      if (slider.dataset.autoplay == "1") {
        swiper.autoplay.start();
      }
    }
  }

  function initializeYouTubePlayers() {
    slider.querySelectorAll('iframe').forEach(iframe => {
      const player = YouTubePlayer(iframe);

      player.on('stateChange', handlePlayerStateChange);

      players.push(player);
    });
    window.players = players;
  }

  function handlePlayerStateChange(event) {
    const { id } = event.target;
    const { data } = event;

    updatePlayerState(id, data);

    if (data === 1) {
      swiper.autoplay.stop();
    } else if (data === 0 || data === 2) {
      swiper.autoplay.start();
    }
  }

  function updatePlayerState(id, state) {
    const existingState = states.find(x => x.id === id);
    if (existingState) {
      existingState.state = state;
    } else {
      states.push({ id, state });
    }
  }

  function pauseAllVideos() {
    players.forEach(player => {
      player.pauseVideo();
    });
  }
});

// Featured
const featuredSlider = new Swiper('.featured-swiper .swiper-container', {
  slidesPerView: 1,
  spaceBetween: 10,
  watchOverflow: true,
  navigation: {
    nextEl: '.featured__nav-forward',
    prevEl: '.featured__nav-back',
  },
  grabCursor: true,
  breakpoints: {
    768: {
      spaceBetween: 30,
    },
  },
});

// Figures module
document.querySelectorAll('.figures-module-swiper .swiper-container').forEach(slider => new Swiper(slider, {
  slidesPerView: 1,
  spaceBetween: 0,
  watchOverflow: true,
  navigation: {
    nextEl: `#${slider.dataset.id} .figures-module__nav-forward`,
    prevEl: `#${slider.dataset.id} .figures-module__nav-back`,
  },
  grabCursor: true,
  breakpoints: {
    768: {
      slidesPerView: 2,
      slidesPerGroup: 2,
      spaceBetween: 40,
    },
    1024: {
      slidesPerView: 3,
      slidesPerGroup: 3,
      speed: 1000,
      spaceBetween: 0,
    },
    1280: {
      slidesPerView: 3,
      slidesPerGroup: 3,
      speed: 1000,
      spaceBetween: 10,
    },
  },
}));

// Access blog module
const accessBlogSlider = new Swiper('.access-blog-swiper .swiper-container', {
  slidesPerView: 1,
  spaceBetween: 0,
  watchOverflow: true,
  navigation: {
    nextEl: '.access-blog__nav-forward',
    prevEl: '.access-blog__nav-back',
  },
  grabCursor: true,
  breakpoints: {
    1024: {
      slidesPerView: 2,
      slidesPerGroup: 2,
      speed: 1000,
      spaceBetween: 30,
    },
  },
});

// Slider Highlight
document.querySelectorAll('.slider-highlight .swiper-container').forEach(slider => new Swiper(slider, {
  effect: slider.dataset.effect ?? 'swipe',
  pagination: {
    el: slider.querySelector('.swiper-pagination'),
    clickable: true,
  },
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: slider.querySelector('.swiper-button-next'),
    prevEl: slider.querySelector('.swiper-button-prev'),
  },
}));

// Interest Rates
if (!window.matchMedia('(min-width: 1024px)').matches) {
  document.querySelectorAll('.interest-rates .swiper-container').forEach(slider => new Swiper(slider, {
    effect: slider.dataset.effect ?? 'swipe',
    centeredSlides: true,
    pagination: {
      el: slider.querySelector('.swiper-pagination'),
      clickable: true,
    },
    autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
    navigation: {
      nextEl: slider.querySelector('.swiper-button-next'),
      prevEl: slider.querySelector('.swiper-button-prev'),
    },
  }));
}

// Mortgage steps
if (!window.matchMedia('(min-width: 1024px)').matches) {
  document.querySelectorAll('.mortgage-steps_slider .swiper-container').forEach(slider => new Swiper(slider, {
    slidesPerView: 1,
    effect: slider.dataset.effect ?? 'swipe',
    // centeredSlides: true,
    pagination: {
      el: slider.querySelector('.swiper-pagination'),
      clickable: true,
    },
    autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
    navigation: {
      nextEl: slider.querySelector('.swiper-button-next'),
      prevEl: slider.querySelector('.swiper-button-prev'),
    },
    breakpoints: {
      768: {
        slidesPerView: 2,
        slidesPerGroup: 2,
        spaceBetween: 30,
      }
    }
  }));
}

// Distributor
document.querySelectorAll('.distributor .swiper-container').forEach(slider => new Swiper(slider, {
  slidesPerView: "auto",
  effect: slider.dataset.effect ?? 'swipe',
  // centeredSlides: true,
  pagination: {
    el: slider.querySelector('.swiper-pagination'),
    clickable: true,
  },
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: slider.querySelector('.swiper-button-next'),
    prevEl: slider.querySelector('.swiper-button-prev'),
  },
  breakpoints: {
  }
}))

// Access Product
document.querySelectorAll('.access-product .swiper-container').forEach(slider => new Swiper(slider, {
  slidesPerView: "auto",
  effect: slider.dataset.effect ?? 'swipe',
  // centeredSlides: true,
  pagination: {
    el: slider.querySelector('.swiper-pagination'),
    clickable: true,
  },
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: slider.querySelector('.swiper-button-next'),
    prevEl: slider.querySelector('.swiper-button-prev'),
  },
  breakpoints: {
  }
}))

// Steps
document.querySelectorAll('.steps .swiper-container').forEach(slider => new Swiper(slider, {
  slidesPerView: "auto",
  effect: slider.dataset.effect ?? 'swipe',
  // centeredSlides: true,
  pagination: {
    el: slider.querySelector('.swiper-pagination'),
    clickable: true,
  },
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: slider.querySelector('.swiper-button-next'),
    prevEl: slider.querySelector('.swiper-button-prev'),
  },
  breakpoints: {

  }
}))

// menu-tab
document.querySelectorAll('.menu-tab:not(.tabs)').forEach(menu => {
  const slider = menu.querySelector('.swiper-container');
  if (slider) {
    new Swiper(slider, {
      slidesPerView: "auto",
      effect: slider.dataset.effect ?? 'swipe',
      // centeredSlides: true,
      autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
      pagination: {
        el: slider.querySelector('.swiper-pagination'),
        clickable: true,
      },
      navigation: {
        nextEl: menu.querySelector('.swiper-button-next'),
        prevEl: menu.querySelector('.swiper-button-prev'),
      },
      breakpoints: {
        40000: {
          slidesPerView: 1,
          slidesPerGroup: 1,
          spaceBetween: 0,
        }
      }
    })
  }
})
// advantages-extra
document.querySelectorAll('.advantages-extra .swiper-container').forEach(slider => new Swiper(slider, {
  slidesPerView: "auto",
  effect: slider.dataset.effect ?? 'swipe',
  // centeredSlides: true,
  pagination: {
    el: slider.querySelector('.swiper-pagination'),
    clickable: true,
  },
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: slider.querySelector('.swiper-button-next'),
    prevEl: slider.querySelector('.swiper-button-prev'),
  },
  breakpoints: {
    40000: {
      slidesPerView: 1,
      slidesPerGroup: 1,
      spaceBetween: 0,
    }
  }
}))

// image-carrousel
document.querySelectorAll('.image-carrousel-normal .swiper-container').forEach(slider => new Swiper(slider, {
  slidesPerView: "auto",
  effect: slider.dataset.effect ?? 'swipe',
  // centeredSlides: true,
  pagination: {
    el: slider.querySelector('.swiper-pagination'),
    clickable: true,
  },
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: slider.querySelector('.swiper-button-next'),
    prevEl: slider.querySelector('.swiper-button-prev'),
  },
  breakpoints: {
    40000: {
      slidesPerView: 1,
      slidesPerGroup: 1,
      spaceBetween: 0,
    }
  }
}))
