const landingUrl = () => {
    const sessionData = sessionStorage.getItem("LandingUrl")

    if (sessionData){
        setLandingUrl(sessionData);
        return;
    }

    sessionStorage.LandingUrl = window.location.href;
    setLandingUrl(window.location.href);
}

const setLandingUrl = (landingUrlValue) => {
    document.querySelectorAll('.landing-url').forEach(function(landingUrlInput){
        landingUrlInput.value = landingUrlValue
    })
}

export default landingUrl;