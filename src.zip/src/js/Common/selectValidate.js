const selectValidate = (
  chosenOption,
  parent,
  errorClassname = 'error',
  validClassname = 'valid',
  hidden  = false, 
) => {

  if (chosenOption && (chosenOption.value == "" || chosenOption.value == undefined)) {
    if (!parent.classList.contains(errorClassname)) {
      parent.classList.remove(validClassname);
      parent.classList.add(errorClassname);
    }
  } else {
    if (parent.classList.contains(errorClassname)) {
      parent.classList.remove(errorClassname);
    }

    parent.classList.add(validClassname);
  }


  if(hidden)
  {
    if (parent.classList.contains(errorClassname)) {
      parent.classList.remove(errorClassname);
    }
  }
};

export default selectValidate;
