import noUiSlider from 'nouislider';
import divideANumberWithDots from '../Helpers/divideANumberWithDots';

const valueBannerRangeSlider = (inputSelector, sliderSelector) => {
  const slider = document.querySelector(sliderSelector);
  const input = document.querySelector(inputSelector);
  const minValue = input ? Number(input.min) : null;
  const maxValue = input ? Number(input.max) : null;
  const defaultValue = input ? Number(input.dataset.default) : null;

  if (slider) {
    noUiSlider.create(slider, {
      start: defaultValue,
      connect: [true, false],
      range: {
        min: minValue,
        max: maxValue,
      },
    });

    slider.noUiSlider.on('update', (values, handle) => {
      const value = values[handle];

      input.value = divideANumberWithDots(Math.round(value));

      if (window.matchMedia('(min-width: 1280px)').matches) {
        input.style.width = `${(value.length + 1) * 18}px`;
      } else if (window.matchMedia('(min-width: 1024px)').matches) {
        input.style.width = `${(value.length + 1) * 13}px`;
      } else {
        input.style.width = `${(value.length + 1) * 11.5}px`;
      }
    });

    window.addEventListener('resize', () => {
      const value = slider.noUiSlider.get();

      if (window.matchMedia('(min-width: 1280px)').matches) {
        input.style.width = `${(value.length + 1) * 18}px`;
      } else if (window.matchMedia('(min-width: 1024px)').matches) {
        input.style.width = `${(value.length + 1) * 13}px`;
      } else {
        input.style.width = `${(value.length + 1) * 11.5}px`;
      }
    });
  } else if (input) {
    input.value = divideANumberWithDots(Math.round(input.value));

    if (window.matchMedia('(min-width: 1280px)').matches) {
      input.style.width = `${(input.value.length + 2) * 18}px`;
    } else if (window.matchMedia('(min-width: 1024px)').matches) {
      input.style.width = `${(input.value.length + 2) * 13}px`;
    } else {
      input.style.width = `${(input.value.length + 2) * 11.5}px`;
    }

    window.addEventListener('resize', () => {
      if (window.matchMedia('(min-width: 1280px)').matches) {
        input.style.width = `${(input.value.length + 2) * 18}px`;
      } else if (window.matchMedia('(min-width: 1024px)').matches) {
        input.style.width = `${(input.value.length + 2) * 13}px`;
      } else {
        input.style.width = `${(input.value.length + 2) * 11.5}px`;
      }
    });
  }
};

export default valueBannerRangeSlider;
