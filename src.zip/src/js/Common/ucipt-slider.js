import Swiper from 'swiper';

document.querySelectorAll('.ucipt-higlight-multi-slide .swiper-container').forEach(slider => new Swiper(slider, {
  effect: slider.dataset.effect ?? 'swipe',
  pagination: {
    el: slider.querySelector('.swiper-pagination'),
    clickable: true,
  },
  autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
  navigation: {
    nextEl: slider.querySelector('.swiper-button-next'),
    prevEl: slider.querySelector('.swiper-button-prev'),
  },
}));
