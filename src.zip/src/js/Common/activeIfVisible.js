import isInViewport from '../Helpers/isInViewport';

const activeIfVisible = (
  visibleElementClassname,
  activeElementClassname,
  activeClassname = 'active',
) => {
  const active = document.querySelectorAll(activeElementClassname);
  const visible = document.getElementsByClassName(visibleElementClassname);

  const manageActiveState = () => {
    for (let i = 0; i < visible.length; i++) {
      if (active.length < i + 1) return;
      if (isInViewport(visible[i])) {
        active[i].classList.add(activeClassname);
      } else {
        active[i].classList.remove(activeClassname);
        active[i].blur();
      }
    }
  };

  window.addEventListener('scroll', manageActiveState);
};

export default activeIfVisible;
