const regexValidate = (
  regex,
  input,
  parent,
  errorClassname = 'error',
  validClassname = 'valid',
) => {
  if (!regex.test(input.value)) {
    if (!parent.classList.contains(errorClassname)) {
      parent.classList.remove(validClassname);
      parent.classList.add(errorClassname);
    }
  } else {
    if (parent.classList.contains(errorClassname)) {
      parent.classList.remove(errorClassname);
    }

    parent.classList.add(validClassname);
  }
};

export default regexValidate;
