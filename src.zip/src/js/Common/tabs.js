const tabs = (
  radioGroupClassname,
  radioInputClassname,
  labelClassname,
  targetClassname,
  activeClassname,
  isHoverEnabled = false,
  dataset,
) => {
  const radioGroup = document.getElementsByClassName(radioGroupClassname);
  const radio = document.getElementsByClassName(radioInputClassname);
  const label = document.getElementsByClassName(labelClassname);
  const target = document.getElementsByClassName(targetClassname);

  for (let i = 0; i < radioGroup.length; i++) {
    const thisRadio = radioGroup[i].querySelector(`.${radioInputClassname}`);
    const thisLabel = radioGroup[i].querySelector(`.${labelClassname}`);

    if (!dataset) {
      thisRadio.addEventListener('click', () => {
        for (let j = 0; j < radioGroup.length; j++) {
          label[j].classList.remove(activeClassname);
          radio[j].blur();

          if (target[j]) {
            target[j].classList.remove(activeClassname);
          }
        }

        thisLabel.classList.add(activeClassname);
        thisRadio.focus();

        if (target[i]) {
          target[i].classList.add(activeClassname);
        }
      });
    } else {
      const thisRadioData = radioGroup[i].dataset[dataset];

      thisRadio.addEventListener('click', () => {
        for (let j = 0; j < radioGroup.length; j++) {
          label[j].classList.remove(activeClassname);
          radio[j].blur();

          if (target[j]) {
            target[j].classList.remove(activeClassname);
          }
        }

        thisLabel.classList.add(activeClassname);
        thisRadio.focus();

        for (let k = 0; k < target.length; k++) {
          const thisTargetData = target[k].dataset[dataset];

          if (thisRadioData === thisTargetData) {
            target[k].classList.add(activeClassname);
          }
        }
      });
    }

    if (isHoverEnabled) {
      thisLabel.addEventListener('mouseover', () => {
        for (let j = 0; j < radioGroup.length; j++) {
          label[j].classList.remove(activeClassname);
          radio[j].blur();

          if (target[j]) {
            target[j].classList.remove(activeClassname);
          }
        }

        thisLabel.classList.add(activeClassname);
        thisRadio.focus();

        if (target[i]) {
          target[i].classList.add(activeClassname);
        }
      });
    }
  }
};

export default tabs;
