import SimpleBar from 'simplebar';

const simplebarInit = () => {
  var elements = document.querySelectorAll('[data-simplebar="init"]');
  elements.forEach(function (element) {
    new SimpleBar(element, {
      autoHide: false
    });
  });
};

export default simplebarInit;
