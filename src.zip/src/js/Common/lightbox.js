import { fadeOut, fadeIn } from '../Helpers/fade';
import exchangeData from "@/js/Helpers/exchangeData";


const lightbox = () => {
  const activeClassname = 'active';
  const fadeDuration = 100; // It is a static value. A real duration is defined in fadeIn/fadeOut functions
  const body = document.getElementsByTagName('body')[0];
  const lightboxCollection = document.getElementsByClassName('lightbox');


  const overlayCollection = document.getElementsByClassName('lightbox__overlay');

  for (let i = 0; i < lightboxCollection.length; i++) {
    const existoverlay = (lightboxCollection[i].querySelector('.lightbox__overlay') !== null);
    const idlightbox = lightboxCollection[i].getAttribute('value');

    for (let j = 0; j < overlayCollection.length; j++) {
      if (overlayCollection[j].querySelector(`.${idlightbox}`)) {
        const overlay = overlayCollection[j];
        const lightboxWindow = overlay.querySelector('.lightbox__window');
        lightboxWindow.id = idlightbox + '-' + j;
        const trigger = lightboxCollection[i].querySelector('.lightbox__trigger');
        const close = overlay.querySelector('.lightbox__close');
        let flag = true;

        if (existoverlay) {
          overlay.id = idlightbox;
          body.appendChild(overlay);
        }
        if (existoverlay && idlightbox === 'TestHipotecas') {
          body.appendChild(overlay);
        }
        if (trigger) {
          trigger.addEventListener('click', () => {
            if (!overlay.classList.contains('active')) {
              if (flag) {
                flag = false;
                overlay.classList.add(activeClassname);
                fadeIn(overlay, null, null, 0.1, 10);
                setTimeout(() => {
                  flag = true;
                }, fadeDuration);
                exchangeData.activeLightboxFormID = overlay.querySelector('form').id;
              }
            }
            const hideLightbox = () => {
              flag = false;
              overlay.classList.remove(activeClassname);
              fadeOut(overlay, null, null, 0.1, 10);
              setTimeout(() => {
                flag = true;
              }, fadeDuration);
            };
            const clickOutside = () => {
              const handler = e => {
                const isClickedInsideLightboxWindow = lightboxWindow.contains(
                  e.target,
                );
                if (!isClickedInsideLightboxWindow && flag) {
                  hideLightbox();
                }
              };
              return handler;
            };

            const clickClose = () => {
              const handler = () => {
                if (flag) {
                  hideLightbox();
                }
              };
              return handler;
            };

            overlay.addEventListener('click', clickOutside());
            close.addEventListener('click', clickClose());
          });
        }
      }
    }
  }

  // Removes lightbox_overlay duplicates
  const allOverlays = document.querySelectorAll('.lightbox__overlay');
  const allOverlaysIds = [];

  allOverlays.forEach(overlay => {
    if (allOverlaysIds.includes(overlay.id)) {
      overlay.remove();
    }
    allOverlaysIds.push(overlay.id);
  });


};

export default lightbox;
