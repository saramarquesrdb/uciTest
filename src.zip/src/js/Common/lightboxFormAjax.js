import { fadeOut, fadeIn } from '../Helpers/fade';

const lightboxFormAjax = async (form, successMessageSelector) => {
  const hiddenClassname = 'hidden';
  const lightboxWindow = form.closest('.lightbox__window'); // Using .closest for better support
  const lightboxHead = lightboxWindow.querySelector('.lightbox__head');
  const successMessage = lightboxWindow.querySelector(successMessageSelector);

  const changeTheScene = () => {
    lightboxHead.classList.add(hiddenClassname);
    form.classList.add(hiddenClassname);
    successMessage.classList.remove(hiddenClassname);
    fadeIn(lightboxWindow);
  };

  try {
    const data = new FormData(form);
    const response = await fetch(form.getAttribute('action'), {
      method: 'POST',
      body: data,
    });

    if (response.ok) {
      fadeOut(lightboxWindow, changeTheScene);
    } else {
      throw new Error(`Error: ${response.statusText}`);
    }
  } catch (error) {
    console.error('Form submission error:', error.message);
    fadeOut(lightboxWindow, changeTheScene);
  }
};


export default lightboxFormAjax;
