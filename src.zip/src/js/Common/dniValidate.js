const dniValidate = (
    input,
    parent,
    isRequired,
    modifyClasses,
    errorClassname = 'error',
    validClassname = 'valid'
) => {
    let dni = input.value.toUpperCase().trim(); // Convertir a mayúsculas y eliminar espacios en blanco

    // Si el campo no es obligatorio y está vacío, no marcar error ni éxito
    if (!isRequired && dni === '') {
        if (modifyClasses) {
            parent.classList.remove(errorClassname, validClassname);
        }
        return true; // Considerar válido si no es obligatorio y está vacío
    }

    // Validar formato DNI o NIE
    const dniRegex = /^[0-9]{8}[A-Z]$/; // Formato de DNI
    const nieRegex = /^[XYZ][0-9]{7}[A-Z]$/; // Formato de NIE

    if (!dniRegex.test(dni) && !nieRegex.test(dni)) {
        if (modifyClasses && !parent.classList.contains(errorClassname)) {
            parent.classList.remove(validClassname);
            parent.classList.add(errorClassname);
        }
        return false; // Si no cumple el formato de DNI o NIE
    }

    // Si es NIE, convertir la letra inicial en número para validación
    if (/^[XYZ]/.test(dni)) {
        const map = { X: '0', Y: '1', Z: '2' };
        dni = map[dni[0]] + dni.slice(1); // Reemplazar la primera letra por el número correspondiente
    }

    // Validación de la letra final
    const numero = dni.slice(0, 8); // Obtener los primeros 8 dígitos
    const letra = dni.slice(8, 9); // Obtener la letra

    const letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
    const letraCorrecta = letras[numero % 23]; // Cálculo de la letra correcta

    if (letra !== letraCorrecta) {
        if (modifyClasses && !parent.classList.contains(errorClassname)) {
            parent.classList.remove(validClassname);
            parent.classList.add(errorClassname);
        }
        return false; // Si la letra es incorrecta
    } else {
        if (modifyClasses) {
            if (parent.classList.contains(errorClassname)) {
                parent.classList.remove(errorClassname);
            }
            parent.classList.add(validClassname);
        }
        return true; // DNI o NIE válido
    }
};

export default dniValidate;
