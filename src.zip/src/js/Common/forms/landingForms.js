import IMask from 'imask';
import { assignmentAllowOnlyLetters, assigmentMillionslandings, ValidateNumberLanding, assigmentValidatePhoneLandings } from '../formsFunctions';



const landingForms = landingForm => {
  const phoneNumberMaskOptions = { mask: '000 000 000 000', };

 
   // Single Text
   const nameInputs = landingForm.querySelectorAll('.input-distinguisher_name_landings');
   for (let j = 0; j < nameInputs.length; j++) {
     if (nameInputs[j]) assignmentAllowOnlyLetters(nameInputs[j]);
   }


   const phoneNumberInput = landingForm.querySelectorAll('.input-distinguisher_phone-number_landings');
   for (let j = 0; j < phoneNumberInput.length; j++) {
     if (phoneNumberInput[j]) 
      {
        IMask(phoneNumberInput[j], phoneNumberMaskOptions)
        assigmentValidatePhoneLandings(phoneNumberInput[j]);
      };
   }

   const millionsInput = landingForm.querySelectorAll('.millions');
   for (let j = 0; j < millionsInput.length; j++) {
     if (millionsInput[j]) assigmentMillionslandings(millionsInput[j]);
   }


   // On submit
  landingForm.addEventListener('submit', e => {
    for (let j = 0; j < millionsInput.length; j++) {
      if (millionsInput[j])
      {
        ValidateNumberLanding(millionsInput[j]);
        var value = millionsInput[j].value.replace(/\./g, '');  // Eliminar los puntos de miles
        millionsInput[j].value = value;
      }
    
    }
});




};

export default landingForms;
