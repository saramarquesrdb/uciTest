import IMask from 'imask';

import getClosestElement from '../../Helpers/getClosestElement';
import { fadeOut, fadeIn } from '../../Helpers/fade';
import scrollTo from '../../Helpers/scrollTo';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import regexTest from '../regexTest';
import selectTest from '../selectTest';
import radioTest from '../radioTest';
import checkboxTest from '../checkboxTest';
import regexValidate from '../regexValidate';
import selectValidate from '../selectValidate';
import radioValidate from '../radioValidate';
import checkboxValidate from '../checkboxValidate';
import { assignmentRequired, assignmentRequiredRegex, isFieldRequired, assignmentNumberRequired, assignmentValidateDownpayment } from '../formsFunctions';
import constants from './_constants';
import valorCompraValidate from '../ValorCompraValidate';
import NumberValidate from '../NumberValidate';

const applicationForm = applicationForm => {
  // Common variables
  const scrollToPosition = 0;
  const fadeDuration = 500; // It is a static value. A real duration is defined in fade.js
  const scrollToErrorDuration = 500;
  const scrollToErrorOffset = 125;
  const errorClassname = 'error';

  // Functions
  const getFieldset = input => getClosestElement(input, '.form-fieldset');
  const getSelectFieldset = input => (input ? input.querySelector('.form-select') : null);
  const getField = element => getClosestElement(element, '.form-list__field');

  // Variables
  const step1 = applicationForm.querySelector('.application-form__step-1');
  const step2 = applicationForm.querySelector('.application-form__step-2');
  const step1Text = applicationForm.querySelector('.application-form__text_step-1');
  const step2Text = applicationForm.querySelector('.application-form__text_step-2');
  const applicationFormContinueBtn = applicationForm ? applicationForm.querySelector('.form-btn__continue .btn') : null;
  const backBtn = applicationForm ? document.querySelector('.ancho-completo-header__back .link') : null;
  const backBtnForm = applicationForm ? applicationForm.querySelector('.btn_secondary_pt') : null;
  const stepsHeaderStepsList = document.querySelector('.steps-header__steps-list');
  const stepsHeaderStep1 = document.getElementsByClassName('steps-header__steps-item')[0];
  const stepsHeaderStep2 = document.getElementsByClassName('steps-header__steps-item')[1];
  const loader = document.getElementById('mortgageUciPtLoader');
  const stepsHeaderStep1Text = stepsHeaderStep1 ? stepsHeaderStep1.querySelector('.steps-header__steps-step') : null;
  const stepsHeaderStep2Text = stepsHeaderStep2 ? stepsHeaderStep2.querySelector('.steps-header__steps-step') : null;
  const stepsHeaderStep1InitialText = stepsHeaderStep1Text ? stepsHeaderStep1Text.innerHTML : null;
  const stepsHeaderStep2InitialText = stepsHeaderStep2Text ? stepsHeaderStep2Text.innerHTML : null;
  const stepsHeaderStep1VisibleText = stepsHeaderStep1Text ? stepsHeaderStep1Text.querySelector('.always-visible').innerHTML : null;
  const stepsHeaderStep2VisibleText = stepsHeaderStep2Text ? stepsHeaderStep2Text.querySelector('.always-visible').innerHTML : null;

  if (stepsHeaderStep2Text) {
    stepsHeaderStep2Text.innerHTML = stepsHeaderStep2VisibleText;
  }

  // BackButton
  if (backBtn) {
    backBtn.style.opacity = 0;
  }

  // -----------------------------
  // STEP 2 FIELDS INITIALIZATION
  // -----------------------------  

  // Name
  const nameInput = applicationForm.querySelector('.input-distinguisher_name');
  const nameFieldset = getFieldset(nameInput);
  const isNameRequired = isFieldRequired(nameInput);
  if (nameInput) assignmentRequiredRegex(isNameRequired, nameInput, constants.nameRegex, nameFieldset);

  // Surname
  const surnameInput = applicationForm.querySelector('.input-distinguisher_surname');
  const surnameFieldset = getFieldset(surnameInput);
  const isSurnameRequired = isFieldRequired(surnameInput);
  if (surnameInput) assignmentRequiredRegex(isSurnameRequired, surnameInput, constants.nameRegex, surnameFieldset);

  // Prefix
  const prefixInput = applicationForm.querySelector('.input-distinguisher_prefix');
  const prefixFieldset = getFieldset(prefixInput);
  const isPrefixRequired = isFieldRequired(prefixInput);
  const prefixMinLength = prefixInput ? prefixInput.getAttribute('minlength') : null;
  const prefixRegex = prefixInput ? new RegExp(`^[+0-9]{${prefixMinLength},}$`) : null;
  // Mask Prefix
  if (prefixInput) {
    IMask(prefixInput, constants.prefixMaskOptions);
    assignmentRequiredRegex(isPrefixRequired, prefixInput, prefixRegex, prefixFieldset);
  }

  // Phone number
  const phoneNumberInput = applicationForm.querySelector('.input-distinguisher_phone-number');
  const phoneNumberFieldset = getFieldset(phoneNumberInput);
  const isPhoneNumberRequired = isFieldRequired(phoneNumberInput);
  const phoneNumberMinLength = phoneNumberInput ? phoneNumberInput.getAttribute('minlength') : null;
  const phoneNumberRegex = phoneNumberInput ? new RegExp(`^[0-9 ]{${phoneNumberMinLength},}$`) : null;
  // Mask Phone
  if (phoneNumberInput) {
    IMask(phoneNumberInput, constants.phoneNumberMaskOptions);
    assignmentRequiredRegex(isPhoneNumberRequired, phoneNumberInput, phoneNumberRegex, phoneNumberFieldset);
  }

  // Email
  const emailInput = applicationForm.querySelector('.input-distinguisher_email');
  const emailFieldset = getFieldset(emailInput);
  const isEmailRequired = isFieldRequired(emailInput);
  if (emailInput) assignmentRequiredRegex(isEmailRequired, emailInput, constants.emailRegex, emailFieldset);

  // More info Text Area Contact Form
  const moreInfoTextarea = applicationForm.querySelector('.input-distinguisher_more-info-textarea');
  const moreInfoTextareaFieldset = getFieldset(moreInfoTextarea);
  const isMoreInfoTextareaRequired = isFieldRequired(moreInfoTextarea);
  const moreInfoTextareaMinLength = moreInfoTextarea ? moreInfoTextarea.getAttribute('minlength') : null;
  const moreInfoTextareaMaxLength = moreInfoTextarea ? moreInfoTextarea.getAttribute('maxlength') : null;
  const moreInfoTextareaRegex = moreInfoTextarea ? new RegExp(`^[\\S\\s]{${moreInfoTextareaMinLength},${moreInfoTextareaMaxLength}}$`) : null;
  if(moreInfoTextarea){
    moreInfoTextarea.addEventListener('input', () => {
      const charCount = moreInfoTextarea.value.length;
      const errorContainer = moreInfoTextarea.closest('.form-textarea')
      .querySelector('.field-bottom__error-message');

      if (charCount >= moreInfoTextareaMaxLength) {
        errorContainer.style.display = 'block';
      }
      else{
        if(errorContainer.style.display !== "none"){
          errorContainer.style.display = 'none';
        }
      }
  });
  }
  // On blur
  if (moreInfoTextarea) assignmentRequiredRegex(isMoreInfoTextareaRequired, moreInfoTextarea, moreInfoTextareaRegex, moreInfoTextareaFieldset);

  // Legal checkboxes
  const contactCheckLegal = applicationForm.querySelector('#checkLegal');
  const checkLegal = contactCheckLegal ? contactCheckLegal.getElementsByClassName('checkbox-input') : null;
  const checkLegalField = contactCheckLegal ? getClosestElement(contactCheckLegal, '.form-list__field') : null;
  const isCheckRequired = contactCheckLegal ? checkLegalField.classList.contains('required') : null;
  if (contactCheckLegal) {
    // On blur
    if (isCheckRequired) {
      for (let i = 0; i < checkLegal.length; i++) {
        checkLegal[i].addEventListener('blur', () => {
          if (contactCheckLegal.classList.contains('error')) {
            checkboxValidate(checkLegal, contactCheckLegal);
          }
        });
      }
    }
  }

  // -----------------------------
  // STEP 1 FIELDS INITIALIZATION
  // -----------------------------

  // Holders
  const holders = applicationForm.querySelector('#holders');
  const holdersRadio = holders ? holders.getElementsByClassName('radio-input') : null;
  const holdersField = holders ? getClosestElement(holders, '.form-list__field') : null;
  const isHoldersRequired = holders ? holdersField.classList.contains('required') : null;
  if (holders) assignmentRequired(isHoldersRequired, holders, holdersRadio, 'radio');

  //Main Age
  var MainAge = applicationForm ? applicationForm.querySelector('#ageRangeInput') : null;
  var parentMainAge = getClosestElement(MainAge, '.form-input');
  var MainAgeInputItem = getClosestElement(MainAge, '.form-list__item');
  var spanErrorMessageMainAge = parentMainAge ? parentMainAge.querySelector(".error-message") : null;
  const isMainAgeRequired = isFieldRequired(MainAge);

  // Main Age Validations
  var mainAgeMin = MainAge.getAttribute('data-min');
  var mainAgeMax = MainAge.getAttribute('data-max');
  var mainAgeRequiredMessage = MainAge.getAttribute('data-reqMessage');
  var mainAgeRangeMessage = MainAge.getAttribute('data-rangeMessage');

  if (MainAge && parentMainAge) assignmentNumberRequired(isMainAgeRequired, mainAgeMin, mainAgeMax, MainAge, parentMainAge, spanErrorMessageMainAge, mainAgeRequiredMessage, mainAgeRangeMessage, MainAgeInputItem);

  //MainHolderInput
  var MainHolderInput = applicationForm ? applicationForm.querySelector('#netRangeInput') : null;
  var parentMainHolderInput = getClosestElement(MainHolderInput, '.form-input');
  var MainHolderInputItem = getClosestElement(MainHolderInput, '.form-list__item');
  var spanErrorMessageMainHolderInput = parentMainHolderInput ? parentMainHolderInput.querySelector(".error-message") : null;
  const isMainHolderInputRequired = isFieldRequired(MainHolderInput);

  // Main Age Validations
  var MainHolderInputMin = MainHolderInput.getAttribute('data-min');
  var MainHolderInputMax = MainHolderInput.getAttribute('data-max');
  var MainHolderInputRequiredMessage = MainHolderInput.getAttribute('data-reqMessage');
  var MainHolderInputRangeMessage = MainHolderInput.getAttribute('data-rangeMessage');

  if (MainHolderInput && parentMainHolderInput) assignmentNumberRequired(isMainHolderInputRequired, MainHolderInputMin, MainHolderInputMax, MainHolderInput, parentMainHolderInput, spanErrorMessageMainHolderInput, MainHolderInputRequiredMessage, MainHolderInputRangeMessage, MainHolderInputItem);

  // secondary holder input
  var secondaryHolderInput = applicationForm ? applicationForm.querySelector('#secondHolderNetRangeInput') : null;
  var parentsecondaryHolderInput = getClosestElement(secondaryHolderInput, '.form-input');
  var secondaryHolderInputItem = getClosestElement(secondaryHolderInput, '.form-list__item');
  var spanErrorMessagesecondaryHolderInput = parentsecondaryHolderInput ? parentsecondaryHolderInput.querySelector(".error-message") : null;
  const issecondaryHolderInputRequired = isFieldRequired(secondaryHolderInput);

  // Secondary holder Validations
  var secondaryHolderInputMin = secondaryHolderInput.getAttribute('data-min');
  var secondaryHolderInputMax = secondaryHolderInput.getAttribute('data-max');
  var secondaryHolderInputRequiredMessage = secondaryHolderInput.getAttribute('data-reqMessage');
  var secondaryHolderInputRangeMessage = secondaryHolderInput.getAttribute('data-rangeMessage');

  if (secondaryHolderInput && parentsecondaryHolderInput) assignmentNumberRequired(issecondaryHolderInputRequired, secondaryHolderInputMin, secondaryHolderInputMax, secondaryHolderInput, parentsecondaryHolderInput, spanErrorMessagesecondaryHolderInput, secondaryHolderInputRequiredMessage, secondaryHolderInputRangeMessage, secondaryHolderInputItem);



  //Valor Compra y capital propio
  var valorCompra = applicationForm ? applicationForm.querySelector('#MortgageHousePrice') : null;
  var parentValorCompra = getClosestElement(valorCompra, '.form-input');
  var valorCompraInputItem = getClosestElement(valorCompra, '.form-list__item');
  var spanErrorMessageValorCompra = parentValorCompra ? parentValorCompra.querySelector(".error-message") : null;
  const isValorCompraRequired = isFieldRequired(valorCompra);

  var capitalPropio = applicationForm ? applicationForm.querySelector('#MortgageSaving') : null;
  var parentCapitalPropio = getClosestElement(capitalPropio, '.form-input');
  var capitalPropioInputItem = getClosestElement(capitalPropio, '.form-list__item');
  var spanErrorMessageCapitalPropio = parentCapitalPropio ? parentCapitalPropio.querySelector(".error-message") : null;
  const iscapitalPropioRequired = isFieldRequired(capitalPropio);

  // Valor Compra validations
  var downpayment = valorCompra.getAttribute('data-downpayment');
  var valorCompraMin = valorCompra.getAttribute('data-min');
  var valorCompraMax = valorCompra.getAttribute('data-max');
  var requiredMessage = valorCompra.getAttribute('data-reqMessage');
  var rangeMessage = valorCompra.getAttribute('data-rangeMessage');

  //Capital propio validation
  var downpaymentMessage = capitalPropio.getAttribute('data-dpmessage');
  var capitalPropioMin = capitalPropio.getAttribute('data-min');
  var capitalPropioMax = capitalPropio.getAttribute('data-max');
  var capitalPropiorequiredMessage = capitalPropio.getAttribute('data-reqMessage');
  var capitalPropiorangeMessage = capitalPropio.getAttribute('data-rangeMessage');
  var dp = (downpayment && downpayment !== '') ? Number(downpayment) / 100 : 0;
  let isAdquisisao = document.querySelector('#propertyTypeNew').checked;

  if (valorCompra && parentValorCompra) assignmentNumberRequired(isValorCompraRequired, valorCompraMin, valorCompraMax, valorCompra, parentValorCompra, spanErrorMessageValorCompra, requiredMessage, rangeMessage, valorCompraInputItem);
  if (capitalPropio && parentCapitalPropio) assignmentNumberRequired(iscapitalPropioRequired, capitalPropioMin, capitalPropioMax, capitalPropio, parentCapitalPropio, spanErrorMessageCapitalPropio, capitalPropiorequiredMessage, capitalPropiorangeMessage, capitalPropioInputItem);
  if (valorCompra && capitalPropio && parentCapitalPropio) assignmentValidateDownpayment(valorCompra, capitalPropio, parentCapitalPropio, dp, spanErrorMessageCapitalPropio, downpaymentMessage, isAdquisisao);

  capitalPropio.addEventListener('blur', () => {
    isAdquisisao = document.querySelector('#propertyTypeNew').checked;
    ValidateDownpayment();
  });

  // Other loans
  const otherLoans = applicationForm.querySelector('#otherLoans');
  const otherLoansRadio = otherLoans ? otherLoans.getElementsByClassName('radio-input') : null;
  const otherLoansField = otherLoans ? getClosestElement(otherLoans, '.form-list__field') : null;
  const isOtherLoansRequired = otherLoans ? otherLoansField.classList.contains('required') : null;
  if (otherLoans) assignmentRequired(isOtherLoansRequired, otherLoans, otherLoansRadio, 'radio');
  const otherLoanYes = applicationForm.querySelector('#otherLoansYes');
  const otherLoanNo = applicationForm.querySelector('#otherLoansNo');
  const otherLoanRange = applicationForm.querySelector('#otherLoansRange');
  if (otherLoanNo && otherLoanYes) {
    otherLoanNo.addEventListener('click', () => {
      if (!otherLoanYes.checked) {
        otherLoanRange.style.display = '';
      }
    });

    otherLoanYes.addEventListener('click', () => {
      if (otherLoanYes.checked) {
        otherLoanRange.style.display = 'flex';
      }
    });
  }

  // Other Loans Amount
  var OtherLoansAmountInput = applicationForm ? applicationForm.querySelector('#otherLoansRangeInput') : null;
  var parentOtherLoansAmountInput = getClosestElement(OtherLoansAmountInput, '.form-input');
  var OtherLoansAmountItem = getClosestElement(OtherLoansAmountInput, '.form-list__field');
  var spanErrorMessageOtherLoansAmountInput = parentOtherLoansAmountInput ? parentOtherLoansAmountInput.querySelector(".error-message") : null;
  const isOtherLoansAmountRequired = isFieldRequired(OtherLoansAmountInput);

  // Other Loans Amount Validations
  var OtherLoansAmountInputMin = OtherLoansAmountInput.getAttribute('data-min');
  var OtherLoansAmountInputMax = OtherLoansAmountInput.getAttribute('data-max');
  var OtherLoansAmountInputRequiredMessage = OtherLoansAmountInput.getAttribute('data-reqMessage');
  var OtherLoansAmountInputRangeMessage = OtherLoansAmountInput.getAttribute('data-rangeMessage');

  if (OtherLoansAmountInput && parentOtherLoansAmountInput) assignmentNumberRequired(isOtherLoansAmountRequired, OtherLoansAmountInputMin, OtherLoansAmountInputMax, OtherLoansAmountInput, parentOtherLoansAmountInput, spanErrorMessageOtherLoansAmountInput, OtherLoansAmountInputRequiredMessage, OtherLoansAmountInputRangeMessage, OtherLoansAmountItem);

  // Province
  const province = applicationForm.querySelector('.form-select-distinguisher_province');
  const provinceChosenOption = province ? province.querySelector('.access-select__chosen-option_hidden') : null;
  const provinceSelectInput = province ? province.getElementsByClassName('access-select__input') : null;
  const isProvinceRequired = isFieldRequired(province);
  if (province) assignmentRequired(isProvinceRequired, province, provinceSelectInput, 'select');

  // Property type
  const propertyType = applicationForm.querySelector('#propertyType');
  const propertyTypeRadio = propertyType ? propertyType.getElementsByClassName('radio-input') : null;
  const propertyTypeField = propertyType ? getClosestElement(propertyType, '.form-list__field') : null;
  const isPropertyTypeRequired = propertyType ? propertyTypeField.classList.contains('required') : null;
  if (propertyType) assignmentRequired(isPropertyTypeRequired, propertyType, propertyTypeRadio, 'radio');


  // Purpose
  const purpose = applicationForm.querySelector('#purpose');
  const purposeRadio = purpose ? purpose.getElementsByClassName('radio-input') : null;
  const purposeField = purpose ? getClosestElement(purpose, '.form-list__field') : null;
  const isPurposeRequired = purpose ? purposeField.classList.contains('required') : null;
  if (purpose) assignmentRequired(isPurposeRequired, purpose, purposeRadio, 'radio');

  // PurchasePhase
  const purchasePhase = applicationForm.querySelector('.form-select-distinguisher_purchasephase');
  const purchasePhaseChosenOption = purchasePhase ? purchasePhase.querySelector('.access-select__chosen-option_hidden') : null;
  const purchasePhaseSelectInput = purchasePhase ? purchasePhase.getElementsByClassName('access-select__input') : null;
  let isPurchasePhaseRequired = true;
  if (purchasePhase) assignmentRequired(isPurchasePhaseRequired, purchasePhase, purchasePhaseSelectInput, 'select');

  document.querySelector('#propertyType').addEventListener('change', () => {
    isPurchasePhaseRequired = document.querySelector('#propertyTypeNew').checked;
    assignmentRequired(isPurchasePhaseRequired, purchasePhase, purchasePhaseSelectInput, 'select');
    isAdquisisao = document.querySelector('#propertyTypeNew').checked;
  })

  // IntendedPurchaseTime
  const intendedPurchaseTime = applicationForm.querySelector('.form-select-distinguisher_intendedpurchasetime');
  const intendedPurchaseTimeChosenOption = intendedPurchaseTime ? intendedPurchaseTime.querySelector('.access-select__chosen-option_hidden') : null;
  const intendedPurchaseTimeSelectInput = intendedPurchaseTime ? intendedPurchaseTime.getElementsByClassName('access-select__input') : null;
  let isIntendedPurchaseTimeRequired = true;
  document.querySelector('#propertyType').addEventListener('change', () => {
    isIntendedPurchaseTimeRequired = document.querySelector('#propertyTypeNew').checked;
    assignmentRequired(isIntendedPurchaseTimeRequired, intendedPurchaseTime, intendedPurchaseTimeSelectInput, 'select');
    isAdquisisao = document.querySelector('#propertyTypeNew').checked;
  })

  // Resident
  const resident = applicationForm.querySelector('.form-radio-group-distinguisher_resident');
  const residentRadio = resident ? resident.getElementsByClassName('radio-input') : null;
  const residentField = getField(resident);
  const isResidentRequired = isFieldRequired(null, residentField);
  if (resident) assignmentRequired(isResidentRequired, resident, residentRadio, 'radio');

  // Other country
  const otherCountry = applicationForm.querySelector('.form-list__field-distinguisher_other-country');
  const otherCountryChosenOption = otherCountry ? otherCountry.querySelector('.access-select__chosen-option_hidden') : null;
  const otherCountrySelectInput = otherCountry ? otherCountry.getElementsByClassName('access-select__input') : null;
  let isOtherCountryRequired = isFieldRequired(null, otherCountry);
  if (otherCountry) assignmentRequired(isOtherCountryRequired, otherCountry, otherCountrySelectInput, 'select');

  // More info checkboxes
  const moreInfo = applicationForm.querySelector('#moreInfo');
  const moreInfoCheckbox = moreInfo ? moreInfo.getElementsByClassName('checkbox-input') : null;
  const moreInfoField = moreInfo ? getClosestElement(moreInfo, '.form-list__field') : null;
  const isMoreInfoRequired = moreInfo ? moreInfoField.classList.contains('required') : null;
  if (moreInfo) {
    // On blur
    if (isMoreInfoRequired) {
      for (let i = 0; i < moreInfoCheckbox.length; i++) {
        moreInfoCheckbox[i].addEventListener('blur', () => {
          if (moreInfo.classList.contains(errorClassname)) {
            checkboxValidate(moreInfoCheckbox, moreInfo);
          }
        });
      }
    }
  }

  // -----------------------------
  // PROPERTY TYPE CONDITIONS
  // -----------------------------
  // Depending on the selected value for PropertyType, some labels in the form will change. 
  // The code here will handle this situations
  document.querySelector('#propertyType').addEventListener('change', () => {
    const checked = document.querySelector('#propertyTypeNew').checked;
    const MortgageHousePriceInputElement =  document.querySelector('#MortgageHousePriceInputId');
    const MortgageSavingInputElement = document.querySelector('#MortgageSavingInputId');
    if(MortgageHousePriceInputElement){
      if(checked){
        MortgageHousePriceInputElement.querySelector('.HousePriceLabel')?.classList.remove('hidden');
        MortgageHousePriceInputElement.querySelector('.ImovelPriceLabel')?.classList.add('hidden');
        document.getElementById('MortgageHousePrice').setAttribute('title', MortgageHousePriceInputElement.querySelector('.HousePriceLabel label')?.textContent)
      }
      else{
        MortgageHousePriceInputElement.querySelector('.HousePriceLabel')?.classList.add('hidden');
        MortgageHousePriceInputElement.querySelector('.ImovelPriceLabel')?.classList.remove('hidden');
        document.getElementById('MortgageHousePrice').setAttribute('title', MortgageHousePriceInputElement.querySelector('.ImovelPriceLabel label')?.textContent)
      }
    }
    if(MortgageSavingInputElement){
      if(checked){
        MortgageSavingInputElement.querySelector('.MortgageSavingLabel')?.classList.remove('hidden');
        MortgageSavingInputElement.querySelector('.ValorEmprestimoTranferirLabel')?.classList.add('hidden');
        document.getElementById('MortgageSaving').setAttribute('title', MortgageSavingInputElement.querySelector('.MortgageSavingLabel label')?.textContent)
      }
      else{
        MortgageSavingInputElement.querySelector('.MortgageSavingLabel')?.classList.add('hidden');
        MortgageSavingInputElement.querySelector('.ValorEmprestimoTranferirLabel')?.classList.remove('hidden');
        document.getElementById('MortgageSaving').setAttribute('title', MortgageSavingInputElement.querySelector('.ValorEmprestimoTranferirLabel label')?.textContent)
      }
    }

    if (document.querySelector('#HousePriceLabel')) document.querySelector('#HousePriceLabel').classList.toggle('hidden', !checked);
    if (document.querySelector('#MortgageSavingLabel')) document.querySelector('#MortgageSavingLabel').classList.toggle('hidden', !checked);
    if (document.querySelector('#ImovelPriceLabel')) document.querySelector('#ImovelPriceLabel').classList.toggle('hidden', checked);
    if (document.querySelector('#ValorEmprestimoTranferirLabel')) document.querySelector('#ValorEmprestimoTranferirLabel').classList.toggle('hidden', checked);
    if (document.querySelector('#HousePriceLabelTooltip')) document.querySelector('#HousePriceLabelTooltip').classList.toggle('hidden', !checked);
    if (document.querySelector('#MortgageSavingLabelTooltip')) document.querySelector('#MortgageSavingLabelTooltip').classList.toggle('hidden', !checked);
    if (document.querySelector('#HousePriceLabelTooltip')) document.querySelector('#HousePriceLabelTooltip').classList.toggle('flex', checked);
    if (document.querySelector('#MortgageSavingLabelTooltip')) document.querySelector('#MortgageSavingLabelTooltip').classList.toggle('flex', checked);
    if (document.querySelector('#ImovelPriceLabelTooltip')) document.querySelector('#ImovelPriceLabelTooltip').classList.toggle('hidden', checked);
    if (document.querySelector('#ValorEmprestimoTranferirLabelTooltip')) document.querySelector('#ValorEmprestimoTranferirLabelTooltip').classList.toggle('hidden', checked);
    if (document.querySelector('#ImovelPriceLabelTooltip')) document.querySelector('#ImovelPriceLabelTooltip').classList.toggle('flex', !checked);
    if (document.querySelector('#ValorEmprestimoTranferirLabelTooltip')) document.querySelector('#ValorEmprestimoTranferirLabelTooltip').classList.toggle('flex', !checked);
    if (document.querySelector('#purchase-phase')) document.querySelector('#purchase-phase').classList.toggle('hidden', !checked)
    if (document.querySelector('#intended-purchase-time')) document.querySelector('#intended-purchase-time').classList.toggle('hidden', !checked)

    if (!checked) {
      document.querySelectorAll('input[name="PurchasePhase"], input[name="IntendedPurchaseTime"]').forEach((radio) => {
        radio.checked = false;
      });

    }
    isAdquisisao = document.querySelector('#propertyTypeNew').checked;
    ValidateDownpayment();

  });

  // -----------------------------
  // SINGLE/MULTIPLE HOLDER CONDITIONS
  // -----------------------------
  // Depending on the selected value for the number of holders as well as 
  // the resident/non-resident value, we show/hide certain labels and fields
  // The code here will handle this situations:
  applicationForm.querySelectorAll('#holders, .form-radio-group-distinguisher_resident').forEach(group => {
    group.addEventListener('change', () => {
      const oneHolderChecked = applicationForm.querySelector('#oneHolder').checked;
      const residentNoChecked = applicationForm.querySelector('.radio-distinguisher_resident-no').checked;
      isOtherCountryRequired = residentNoChecked;

      // Toggle visibility based on conditions
      document.querySelector('#otherCountrySelect').style.display = residentNoChecked ? 'block' : 'none';
      applicationForm.querySelectorAll('.form-list__tooltip-label_default').forEach(label => label.style.display = oneHolderChecked ? 'flex' : 'none');
      applicationForm.querySelectorAll('.form-list__tooltip-label_option_2').forEach(label => label.style.display = oneHolderChecked ? 'none' : 'flex');
      applicationForm.querySelectorAll('.form-list__item_second-holder').forEach(item => item.style.display = oneHolderChecked ? 'none' : 'block');

      const wrappers = oneHolderChecked ? 
        applicationForm.querySelectorAll('.form-list__tooltip-label_default') :
        applicationForm.querySelectorAll('.form-list__tooltip-label_option_2');
      
      wrappers.forEach(wrapper => {
        const label = wrapper.querySelector('label');
        if (label) {
          const inputId = label.getAttribute('for');
          const input = document.getElementById(inputId);
          input.setAttribute('title', label.textContent);
        }
      });

      if (!residentNoChecked) {
        selectValidate(otherCountryChosenOption, otherCountry, 'error', 'valid', true);
      }
    });
  });

  // -----------------------------
  // VALIDATION METHODS
  // -----------------------------
  // Some methods required for validation
  const isCountrySelectNeeded = () => {
    return applicationForm.querySelector('.radio-distinguisher_resident-no').checked
      ? selectTest(otherCountryChosenOption)
      : true;
  };

  const ValidateDownpayment = () => {
    if (valorCompra && capitalPropio && parentCapitalPropio) {
      return valorCompraValidate(valorCompra, capitalPropio, parentCapitalPropio, dp, spanErrorMessageCapitalPropio, downpaymentMessage, isAdquisisao);
    }
    return true;
  }

  const ValidateValorCompraRequired = () => {
    if (valorCompra && parentValorCompra) {
      return NumberValidate(valorCompra, parentValorCompra, 'error', 'valid', isValorCompraRequired, valorCompraMin, valorCompraMax, spanErrorMessageValorCompra, requiredMessage, rangeMessage, valorCompraInputItem);
    }
    return true;
  }


  const ValidateCapitalPropioRequired = () => {
    if (capitalPropio && parentCapitalPropio) {
      return NumberValidate(capitalPropio, parentCapitalPropio, 'error', 'valid', iscapitalPropioRequired, capitalPropioMin, capitalPropioMax, spanErrorMessageCapitalPropio, capitalPropiorequiredMessage, capitalPropiorangeMessage, capitalPropioInputItem);
    }

    return true;
  }

  const ValidateMainAge = () => {
    if (MainAge && parentMainAge) {
      return NumberValidate(MainAge, parentMainAge, 'error', 'valid', isMainAgeRequired, mainAgeMin, mainAgeMax, spanErrorMessageMainAge, mainAgeRequiredMessage, mainAgeRangeMessage, MainAgeInputItem);
    }

    return true;
  }


  const ValidateMainHolderInput = () => {
    if (MainHolderInput && parentMainHolderInput) {
      return NumberValidate(MainHolderInput, parentMainHolderInput, 'error', 'valid', isMainHolderInputRequired, MainHolderInputMin, MainHolderInputMax, spanErrorMessageMainHolderInput, MainHolderInputRequiredMessage, MainHolderInputRangeMessage, MainHolderInputItem);
    }

    return true;
  }

  const ValidateSecondaryHolderInput = () => {
    if (secondaryHolderInput && parentsecondaryHolderInput) {
      return NumberValidate(secondaryHolderInput, parentsecondaryHolderInput, 'error', 'valid', issecondaryHolderInputRequired, secondaryHolderInputMin, secondaryHolderInputMax, spanErrorMessagesecondaryHolderInput, secondaryHolderInputRequiredMessage, secondaryHolderInputRangeMessage, secondaryHolderInputItem);
    }

    return true;
  }

  const ValidateOtherLoansAmountInput = () => {
    if (OtherLoansAmountInput && parentOtherLoansAmountInput) {
      return NumberValidate(OtherLoansAmountInput, parentOtherLoansAmountInput, 'error', 'valid', isOtherLoansAmountRequired, OtherLoansAmountInputMin, OtherLoansAmountInputMax, spanErrorMessageOtherLoansAmountInput, OtherLoansAmountInputRequiredMessage, OtherLoansAmountInputRangeMessage, OtherLoansAmountItem);
    }

    return true;
  }



  // -----------------------------
  // VALIDATIONS STEP 1
  // -----------------------------
  const validateStep1 = () => {
    if (
      isRequiredTestPass(isHoldersRequired, radioTest(holdersRadio)) &&
      isRequiredTestPass(isOtherLoansRequired, radioTest(otherLoansRadio)) &&
      isRequiredTestPass(isProvinceRequired, selectTest(provinceChosenOption)) &&
      isRequiredTestPass(isPropertyTypeRequired, radioTest(propertyTypeRadio)) &&
      isRequiredTestPass(isPurposeRequired, radioTest(purposeRadio)) &&
      isRequiredTestPass(isPurchasePhaseRequired, selectTest(purchasePhaseChosenOption)) &&
      isRequiredTestPass(isIntendedPurchaseTimeRequired, selectTest(intendedPurchaseTimeChosenOption)) &&
      isRequiredTestPass(isResidentRequired, radioTest(residentRadio)) &&
      isRequiredTestPass(isOtherCountryRequired, isCountrySelectNeeded()) &&
      isRequiredTestPass(isMoreInfoRequired, checkboxTest(moreInfoCheckbox))
      && ValidateValorCompraRequired()
      && ValidateCapitalPropioRequired()
      && ValidateMainAge()
      && ValidateMainHolderInput()
      && ValidateSecondaryHolderInput()
      && ValidateOtherLoansAmountInput()
      && ValidateDownpayment()
    ) {
      return true;
    }

    return false;
  };

  const showValidationErrorsStep1 = () => {
    let flag = true;

    if (isHoldersRequired && !radioTest(holdersRadio)) {
      for (let i = 0; i < holdersRadio.length; i++) {
        radioValidate(holdersRadio[i], holders);
      }

      if (flag) {
        scrollTo(holdersField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateMainAge()) {
      if (flag) {
        scrollTo(MainAge, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateMainHolderInput()) {
      if (flag) {
        scrollTo(MainHolderInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateSecondaryHolderInput()) {
      if (flag) {
        scrollTo(secondaryHolderInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateOtherLoansAmountInput()) {
      if (flag) {
        scrollTo(OtherLoansAmountInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }


    if (isOtherLoansRequired && !radioTest(otherLoansRadio)) {
      for (let i = 0; i < otherLoansRadio.length; i++) {
        radioValidate(otherLoansRadio[i], otherLoans);
      }

      if (flag) {
        scrollTo(otherLoansField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isProvinceRequired && !selectTest(provinceChosenOption)) {
      selectValidate(provinceChosenOption, province);
      if (flag) {
        scrollTo(province, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isPropertyTypeRequired && !radioTest(propertyTypeRadio)) {
      for (let i = 0; i < propertyTypeRadio.length; i++) {
        radioValidate(propertyTypeRadio[i], propertyType);
      }

      if (flag) {
        scrollTo(
          propertyTypeField,
          scrollToErrorDuration,
          scrollToErrorOffset
        );
        flag = false;
      }
    }

    if (isPurposeRequired && !radioTest(purposeRadio)) {
      for (let i = 0; i < purposeRadio.length; i++) {
        radioValidate(purposeRadio[i], purpose);
      }

      if (flag) {
        scrollTo(purposeField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isPurchasePhaseRequired && !selectTest(purchasePhaseChosenOption)) {
      selectValidate(purchasePhaseChosenOption, purchasePhase);
      if (flag) {
        scrollTo(purchasePhase, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isIntendedPurchaseTimeRequired && !selectTest(intendedPurchaseTimeChosenOption)) {
      selectValidate(intendedPurchaseTimeChosenOption, intendedPurchaseTime);
      if (flag) {
        scrollTo(intendedPurchaseTime, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateValorCompraRequired()) {
      if (flag) {
        scrollTo(valorCompra, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateCapitalPropioRequired()) {
      if (flag) {
        scrollTo(capitalPropio, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isResidentRequired && !radioTest(residentRadio)) {
      for (let i = 0; i < residentRadio.length; i++) {
        radioValidate(residentRadio[i], resident);
      }

      if (flag) {
        scrollTo(residentField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isOtherCountryRequired && !isCountrySelectNeeded()) {
      selectValidate(otherCountryChosenOption, otherCountry);
      if (flag) {
        scrollTo(
          otherCountry,
          scrollToErrorDuration,
          scrollToErrorOffset
        );
        flag = false;
      }
    }

    if (isMoreInfoRequired && !checkboxTest(moreInfoCheckbox)) {
      checkboxValidate(moreInfoCheckbox, moreInfo);
      if (flag) {
        scrollTo(moreInfoField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }


    if (!ValidateDownpayment()) {
      if (flag) {
        scrollTo(valorCompra, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }
  };

  // -----------------------------
  // VALIDATIONS STEP 2
  // -----------------------------
  const validateStep2 = () => {
    if (
      isRequiredTestPass(isNameRequired, regexTest(constants.nameRegex, nameInput)) &&
      isRequiredTestPass(isSurnameRequired, regexTest(constants.nameRegex, surnameInput)) &&
      isRequiredTestPass(isPrefixRequired, regexTest(prefixRegex, prefixInput)) &&
      isRequiredTestPass(isPhoneNumberRequired, regexTest(phoneNumberRegex, phoneNumberInput)) &&
      isRequiredTestPass(isEmailRequired, regexTest(constants.emailRegex, emailInput)) &&
      isRequiredTestPass(isCheckRequired, checkboxTest(checkLegal))
    ) {
      return true;
    }

    return false;
  };

  const showValidationErrorsStep2 = () => {
    let flag = true;

    if (isNameRequired && !regexTest(constants.nameRegex, nameInput)) {
      regexValidate(constants.nameRegex, nameInput, nameFieldset);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isSurnameRequired && !regexTest(constants.nameRegex, surnameInput)) {
      regexValidate(constants.nameRegex, surnameInput, surnameFieldset);
      if (flag) {
        scrollTo(surnameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isPrefixRequired && !regexTest(prefixRegex, prefixInput)) {
      regexValidate(prefixRegex, prefixInput, prefixFieldset);
      if (flag) {
        scrollTo(prefixInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isPhoneNumberRequired && !regexTest(phoneNumberRegex, phoneNumberInput)
    ) {
      regexValidate(phoneNumberRegex, phoneNumberInput, phoneNumberFieldset);
      if (flag) {
        scrollTo(phoneNumberInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isEmailRequired && !regexTest(constants.emailRegex, emailInput)) {
      regexValidate(constants.emailRegex, emailInput, emailFieldset);

      if (flag) {
        scrollTo(emailInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isCheckRequired && !checkboxTest(checkLegal)) {
      checkboxValidate(checkLegal, contactCheckLegal);
      if (flag) {
        scrollTo(emailInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }
  };




  // -----------------------------
  // CONTINUE BUTTON
  // -----------------------------
  if (applicationFormContinueBtn) {
    applicationFormContinueBtn.addEventListener('click', () => {
      if (validateStep1()) {
        fadeOut(step1, fadeIn, step2);

        if (step2Text) {
          fadeOut(step1Text, fadeIn, step2Text);
        }
        if (backBtn) backBtn.style.transition = 'opacity 1s';

        if (stepsHeaderStepsList) {
          stepsHeaderStepsList.style.transition = 'opacity 1s';
          stepsHeaderStepsList.style.opacity = 0;
        }

        setTimeout(() => {
          backBtn.style.opacity = 1;
          if (stepsHeaderStepsList) {
            stepsHeaderStep1.classList.remove('active');
            stepsHeaderStep2.classList.add('active');
            stepsHeaderStep1Text.innerHTML = stepsHeaderStep1VisibleText;
            stepsHeaderStep2Text.innerHTML = stepsHeaderStep2InitialText;
            stepsHeaderStepsList.style.opacity = 1;
          }
          scrollTo(scrollToPosition, fadeDuration);
        }, fadeDuration);
      } else {
        showValidationErrorsStep1();
      }
    });
  }

  // -----------------------------
  // BACK BUTTON
  // -----------------------------
  function backUciPtForm() {
    fadeOut(step2, fadeIn, step1);

    if (step2Text) { fadeOut(step2Text, fadeIn, step1Text); }

    backBtn.style.opacity = 0;
    if (stepsHeaderStepsList) {
      stepsHeaderStepsList.style.opacity = 0;
    }

    setTimeout(() => {
      if (stepsHeaderStepsList) {
        stepsHeaderStep2.classList.remove('active');
        stepsHeaderStep1.classList.add('active');
        stepsHeaderStep1Text.innerHTML = stepsHeaderStep1InitialText;
        stepsHeaderStep2Text.innerHTML = stepsHeaderStep2VisibleText;
        stepsHeaderStepsList.style.opacity = 1;
      }
      scrollTo(scrollToPosition, fadeDuration);
    }, fadeDuration);
  }

  if (backBtn && backBtnForm) {
    backBtn.addEventListener('click', e => {
      e.preventDefault();
      backUciPtForm();
    });
    backBtnForm.addEventListener('click', e => {
      e.preventDefault();
      backUciPtForm();
    });
  }

  // -----------------------------
  // SUBMIT
  // -----------------------------
  applicationForm.addEventListener('submit', e => {
    if (!validateStep1()) {
      e.preventDefault();
      showValidationErrorsStep1();
    } else if (!validateStep2()) {
      e.preventDefault();
      showValidationErrorsStep2();
    } else if (loader) {
      loader.classList.add('active');
    }
  });
};

export default applicationForm;
