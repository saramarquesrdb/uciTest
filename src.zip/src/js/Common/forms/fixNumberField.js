import { localeFormatNumber, restrictInputOnlyNumbersAndPeriods, stdNumber } from '@/js/Helpers/_helpers';

const fixNumberField = (form, inputNumber) => {
  // Transform type number input
  inputNumber.setAttribute('type', 'text');
  inputNumber.removeAttribute('onblur');
  inputNumber.style.pointerEvents = 'none';
  inputNumber.style.color = 'white';

  const functions = {
    cloneInput() {
      // Create a text to number input element
      const inputInterface = document.createElement('input');
      inputInterface.setAttribute('class', 'text-number-input');
      inputInterface.setAttribute('type', 'text');
      inputInterface.setAttribute('pattern', '[0-9.]*');

      // Append element to the form
      inputNumber.insertAdjacentElement('afterend', inputInterface);

      // Copy value content to new inputInterface
      const textNumberInput = document.querySelector('.text-number-input');
      inputInterface.addEventListener('input', () => {
        inputInterface.value = localeFormatNumber(inputInterface.value).toString();
        inputNumber.value = stdNumber(inputInterface.value);
      });

      // UI behaviours
      inputInterface.addEventListener('focus', () => {
        inputNumber.closest('.fieldset').classList.add('active');
      });

      inputInterface.addEventListener('blur', () => {
        if (inputInterface.value == '') {
          inputNumber.closest('.fieldset').classList.remove('active');
        }
      });

      // Format number on writting
      textNumberInput.addEventListener('input', restrictInputOnlyNumbersAndPeriods);
    },
  };
  functions.cloneInput();
};

export default fixNumberField;
