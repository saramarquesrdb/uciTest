import getClosestElement from '../../Helpers/getClosestElement';
import scrollTo from '../../Helpers/scrollTo';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import selectTest from '../selectTest';
import radioTest from '../radioTest';
import selectValidate from '../selectValidate';
import radioValidate from '../radioValidate';
import formSubmitPreloader from '../formSubmitPreloader';
import checkboxValidate from '../checkboxValidate';
import checkboxTest from '../checkboxTest';
import { assignmentRequired } from '../formsFunctions';

const simulatorForms = simulatorForm => {
  // Common variables
  const scrollToErrorDuration = 500;
  const scrollToErrorOffset = 25;
  // const errorClassname = 'error';

  // Common functions
  const getField = element => getClosestElement(element, '.form-list__field');

  // One Holder
  const oneHolderInput = simulatorForm.querySelector('#oneHolder');
  const secondHolderItem = simulatorForm.getElementsByClassName('form-list__item_second-holder');
  const defaultLabel = simulatorForm.getElementsByClassName('form-list__tooltip-label_default');
  const twoHoldersLabel = simulatorForm.getElementsByClassName('form-list__tooltip-label_option_2');

  // TwoHolders
  const twoHoldersInput = simulatorForm.querySelector('#twoHolders');

  // Job status second holder
  const jobStatusSecondHolder = simulatorForm.querySelector('#jobStatusSecondHolder');
  // if second holder is activated changes null to true
  let isJobStatusSecondHolderRequired = null;
  const jobStatusSecondHolderChosenOption = jobStatusSecondHolder ? jobStatusSecondHolder.querySelector('.access-select__chosen-option_hidden') : null;
  const jobStatusSecondHolderSelectInput = jobStatusSecondHolder ? jobStatusSecondHolder.getElementsByClassName('access-select__input') : null;

  // Country Ucimortgages
  const CountryUcimortgage = simulatorForm.querySelector('.form-select-distinguisher_country');
  const CountryUcimortgageChosenOption = CountryUcimortgage ? CountryUcimortgage.querySelector('.access-select__chosen-option_hidden') : null;
  const CountryUcimortgageSelectInput = CountryUcimortgage ? CountryUcimortgage.getElementsByClassName('access-select__input') : null;
  const CountryField = CountryUcimortgage ? getClosestElement(CountryUcimortgage, '.form-list__field') : null;
  const isCountryUcimortgageRequired = CountryUcimortgage ? CountryField.classList.contains('required') : null;
  if (CountryUcimortgage) assignmentRequired(isCountryUcimortgageRequired, CountryUcimortgage, CountryUcimortgageSelectInput, 'select');

  // Holders
  const holders = simulatorForm.querySelector('#holders');
  const holdersRadio = holders ? holders.getElementsByClassName('radio-input') : null;
  const holdersField = holders ? getClosestElement(holders, '.form-list__field') : null;
  const isHoldersRequired = holders ? holdersField.classList.contains('required') : null;

  if (holders) assignmentRequired(isHoldersRequired, holders, holdersRadio, 'radio');

  // Employees
  const employees = simulatorForm.querySelector('#employees');
  const employeesRadio = employees ? employees.getElementsByClassName('radio-input') : null;
  const employeesField = employees ? getClosestElement(employees, '.form-list__field') : null;
  const isEmployeesRequired = employees ? employeesField.classList.contains('required') : null;

  if (employees) assignmentRequired(isEmployeesRequired, employees, employeesRadio, 'radio');

  // Employes Yes
  const employeesYes = simulatorForm.querySelector('#employeesYes');
  const employeesNo = simulatorForm.querySelector('#employeesNo');
  const employeesNumber = simulatorForm.querySelector('#employeesNumber');

  if (employeesNo && employeesYes) {
    employeesNo.addEventListener('click', () => {
      if (!employeesYes.checked) {
        employeesNumber.style.display = '';
      }
    });

    employeesYes.addEventListener('click', () => {
      if (employeesYes.checked) {
        employeesNumber.style.display = 'flex';
      }
    });
  }

  // Job status
  const jobStatus = simulatorForm.querySelector('#jobStatus');
  const isJobStatusRequired = jobStatus ? getClosestElement(jobStatus, '.form-list__field').classList.contains('required') : null;
  const jobStatusChosenOption = jobStatus ? jobStatus.querySelector('.access-select__chosen-option_hidden') : null;
  const jobStatusSelectInput = jobStatus ? jobStatus.getElementsByClassName('access-select__input') : null;
  if (jobStatus) assignmentRequired(isJobStatusRequired, jobStatus, jobStatusSelectInput, 'select');

  // Other loans
  const otherLoans = simulatorForm.querySelector('#otherLoans');
  const otherLoansRadio = otherLoans ? otherLoans.getElementsByClassName('radio-input') : null;
  const otherLoansField = otherLoans ? getClosestElement(otherLoans, '.form-list__field') : null;
  const isOtherLoansRequired = otherLoans ? otherLoansField.classList.contains('required') : null;
  if (otherLoans) assignmentRequired(isOtherLoansRequired, otherLoans, otherLoansRadio, 'radio');

  const otherLoanYes = simulatorForm.querySelector('#otherLoansYes');
  const otherLoanNo = simulatorForm.querySelector('#otherLoansNo');
  const otherLoanRange = simulatorForm.querySelector('#otherLoansRangeSlider');

  if (otherLoanNo && otherLoanYes && otherLoanRange) {
    otherLoanNo.addEventListener('click', () => {
      if (otherLoanNo.checked) {
        otherLoanRange.classList.add('hidden');
      }
    });

    otherLoanYes.addEventListener('click', () => {
      if (otherLoanYes.checked) {
        otherLoanRange.classList.remove('hidden');
      }
    });
  }



  // Legal checkboxes
  const contactCheckLegal = simulatorForm.querySelector('#checkLegal');
  const checkLegal = contactCheckLegal ? contactCheckLegal.getElementsByClassName('checkbox') : null;
  const checkLegalField = contactCheckLegal ? getClosestElement(contactCheckLegal, '.form-list__field') : null;
  const isCheckRequired = contactCheckLegal ? checkLegalField.classList.contains('required') : null;

  if (contactCheckLegal) {
    // On blur
    if (isCheckRequired) {
      for (let i = 0; i < checkLegal.length; i++) {
        checkLegal[i].addEventListener('blur', () => {
          if (contactCheckLegal.classList.contains('error')) {
            checkboxValidate(checkLegal, contactCheckLegal);
          }
        });
      }
    }
  }
  // Special conditions for Simulator Form
  if (oneHolderInput && twoHoldersInput) {
    oneHolderInput.addEventListener('click', () => {
      if (!twoHoldersInput.checked) {
        jobStatusSecondHolder.parentElement.classList.remove('required');
        isJobStatusSecondHolderRequired = null;
        for (let i = 0; i < twoHoldersLabel.length; i++) {
          if (defaultLabel[i]) {
            defaultLabel[i].style.display = '';
          }

          twoHoldersLabel[i].style.display = '';
        }
        for (let i = 0; i < secondHolderItem.length; i++) {
          secondHolderItem[i].style.display = '';
        }
      }
    });

    twoHoldersInput.addEventListener('click', () => {
      if (twoHoldersInput.checked) {
        jobStatusSecondHolder.parentElement.classList.add('required');
        isJobStatusSecondHolderRequired = true;

        for (let i = 0; i < twoHoldersLabel.length; i++) {
          if (defaultLabel[i]) {
            defaultLabel[i].style.display = 'none';
          }
          twoHoldersLabel[i].style.display = 'flex';
        }
        for (let i = 0; i < secondHolderItem.length; i++) {
          secondHolderItem[i].style.display = 'block';
        }
      }
    });
  }

  // On blur
  for (let j = 0; j < jobStatusSecondHolderSelectInput.length; j++) {
    jobStatusSecondHolderSelectInput[j].addEventListener('blur', () => {
      selectValidate(jobStatusSecondHolderChosenOption, jobStatusSecondHolder);
    });
  }

  // Test form (Light validation variant without visuals, used in regular validation)
  const simulatorFormTest = () => {
    if (
      isRequiredTestPass(isHoldersRequired, radioTest(holdersRadio)) &&
      isRequiredTestPass(isEmployeesRequired, radioTest(employeesRadio)) &&
      isRequiredTestPass(
        isJobStatusRequired,
        selectTest(jobStatusChosenOption)
      ) &&
      isRequiredTestPass(
        isCountryUcimortgageRequired,
        selectTest(CountryUcimortgageChosenOption)
      ) &&
      isRequiredTestPass(
        isJobStatusSecondHolderRequired,
        selectTest(jobStatusSecondHolderChosenOption)
      ) &&
      isRequiredTestPass(isOtherLoansRequired, radioTest(otherLoansRadio))
      && isRequiredTestPass(isCheckRequired, checkboxTest(checkLegal))
    ) {
      return true;
    }

    return false;
  };

  // Validate form
  const simulatorFormValidate = () => {
    let flag = true;
    const isEdge = /Edge/.test(navigator.userAgent);

    if (isHoldersRequired && !radioTest(holdersRadio)) {
      for (let i = 0; i < holdersRadio.length; i++) {
        radioValidate(holdersRadio[i], holders);
      }

      if (flag) {
        scrollTo(holdersField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isEmployeesRequired && !radioTest(employeesRadio)) {
      for (let i = 0; i < employeesRadio.length; i++) {
        radioValidate(employeesRadio[i], employees);
      }

      if (flag) {
        scrollTo(employeesField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isJobStatusRequired && !selectTest(jobStatusChosenOption)) {
      selectValidate(jobStatusChosenOption, jobStatus);

      if (flag) {
        if (!isEdge) {
          scrollTo(holders, scrollToErrorDuration, scrollToErrorOffset);
        } else {
          const elementHolders = simulatorForm.querySelector('#holders');
          elementHolders.scrollIntoView();
        }
        flag = false;
      }
    }

    if (isCountryUcimortgageRequired && !selectTest(CountryUcimortgageChosenOption)) {
      selectValidate(CountryUcimortgageChosenOption, CountryUcimortgage);

      if (flag) {
        if (!isEdge) {
          scrollTo(CountryUcimortgage, scrollToErrorDuration, scrollToErrorOffset);
        } else {
          const elementCountries = simulatorForm.querySelector('.form-select-distinguisher_country');
          elementCountries.scrollIntoView();
        }
        flag = false;
      }
    }


    if (isJobStatusSecondHolderRequired && !selectTest(jobStatusSecondHolderChosenOption)) {
      selectValidate(jobStatusSecondHolderChosenOption, jobStatusSecondHolder);

      if (flag) {
        if (!isEdge) {
          scrollTo(holders, scrollToErrorDuration, scrollToErrorOffset);
        } else {
          const elementSecondHolder = simulatorForm.querySelector('#holders');
          elementSecondHolder.scrollIntoView();
        }
        flag = false;
      }
    }

    if (isOtherLoansRequired && !radioTest(otherLoansRadio)) {
      for (let i = 0; i < otherLoansRadio.length; i++) {
        radioValidate(otherLoansRadio[i], otherLoans);
      }

      if (flag) {
        scrollTo(otherLoansField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isCheckRequired && !checkboxTest(checkLegal)) {
      checkboxValidate(checkLegal, contactCheckLegal);
    }
  };
  // On submit
  simulatorForm.addEventListener('submit', e => {
    e.preventDefault();
    if (!simulatorFormTest()) {
      simulatorFormValidate();
    } else {
      formSubmitPreloader(simulatorForm, '.simulator-form', [
        'body',
        '.header',
        '.splitter_header-before',
      ]);
    }
  });
};
export default simulatorForms;
