import {$, $all, localeFormatNumber} from '@/js/Helpers/_helpers';
import IMask from 'imask';

const inputsEvents = () => {
  if ($('.eu-number-format')) {
    const formatNumber = $all('.eu-number-format');
    formatNumber.forEach(input => {
      IMask(input, {
        mask: /(\d+)(((.|,)\d+)+)?/g
      });
      input.addEventListener('blur', () => {
        input.value = localeFormatNumber(input.value).toString();
      });
    });
  }

  // Input text on Focus clear value if === "0"
  if ($('input[type="text"]')) {
    const allInputText = $all('input[type="text"]');
    allInputText.forEach(inputText => {
      inputText.addEventListener('focus', () => {
        if (inputText.value === '0') {
          inputText.value = '';
          inputText.addEventListener('blur', () => {
            if (inputText.value === '') {
              inputText.value = '0';
            }
          });
        }
      });
    })
  }
};

export default inputsEvents;
