import IMask from 'imask';
import { fadeOut, fadeIn } from '../../Helpers/fade';
import getClosestElement from '../../Helpers/getClosestElement';
import selectValidate from '../selectValidate';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import selectTest from '../selectTest';
import scrollTo from '../../Helpers/scrollTo';
import divideANumberWithDots from '../../Helpers/divideANumberWithDots';
import regexValidate from '../regexValidate';
import regexTest from '../regexTest';
import { assignmentRequiredRegex, isFieldRequired } from '../formsFunctions';

// Common variables
const scrollToErrorDuration = 500;
const scrollToErrorOffset = 25;
const regexMoney = /(?:- ?)?(?:\d{4,}|\d{1,3}(?:\.\d{3})*)(?:,\d+)?\d* €$/;
const regexAge = /(^1[8-9])$|(^[2-5][0-9])$|(^6[0-5])$/;
const nameRegex = /^\s*([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]{1,}([.,] |[-']| )?)+[A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]+\.?\s*$/;
const emailRegex = /^[-a-z0-9~!$%^&*_=+}{'?]+(\.[-a-z0-9~!$%^&*_=+}{'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;
const regexMonths = /^[1-9][0-9]?$/;

// Common functions
const getFieldset = input => getClosestElement(input, '.form-fieldset');

function erasePoints(input, max) {
  let inputErasePoints = '';
  for (let i = 0; i < input.length; i++) {
    if (input[i].charCodeAt(0) === 44 || (input[i].charCodeAt(0) >= 48 && input[i].charCodeAt(0) <= 57)) {
      inputErasePoints += input[i];
    }
  }
  return Math.round(parseInt(inputErasePoints, 10)).toString().substring(0, max);
}

function checkInput(input, max) {
  const inputCheck = divideANumberWithDots(erasePoints(input, max));
  if (inputCheck !== 'NaN') { return inputCheck; }
  return 0;
}

// prequalifierForm
const prequalifierForms = prequalifierForm => {
  // Validate Selects Prequalifier
  // const formSelect = prequalifierForm.getElementsByClassName('form-select');
  // for (let i = 0; i < formSelect.length; i++) {
  //  const formSelectItem = formSelect[i];
  //  const SelectInput = formSelectItem ? formSelectItem.getElementsByClassName('access-select__input') : null;
  // On blur

  // if (formSelectItem) assignmentRequired(1, formSelectItem, SelectInput, 'select');
  // }

  // Add maxlenght Money
  document.querySelector('#ID-5').setAttribute('maxlength', '9');
  document.querySelector('#ID-6').setAttribute('maxlength', '9');

  // Add maxlenght Income
  document.querySelector('#ID-11').setAttribute('maxlength', '7');
  document.querySelector('#ID-16').setAttribute('maxlength', '7');

  // Add maxlenght other loans
  document.querySelector('#ID-13').setAttribute('maxlength', '7');
  document.querySelector('#ID-18').setAttribute('maxlength', '7');

  // Add maxlenght Money
  document.querySelector('#ID-5').setAttribute('maxlength', '9');
  document.querySelector('#ID-6').setAttribute('maxlength', '9');

  // Add maxlenght Income
  document.querySelector('#ID-11').setAttribute('maxlength', '7');
  document.querySelector('#ID-16').setAttribute('maxlength', '7');

  // Add maxlenght other loans
  document.querySelector('#ID-13').setAttribute('maxlength', '7');
  document.querySelector('#ID-18').setAttribute('maxlength', '7');

  // Validate Money Input
  const moneyInputs = prequalifierForm.getElementsByClassName('input-distinguisher_money');
  for (let i = 0; i < moneyInputs.length; i++) {
    const moneyInput = moneyInputs[i];
    const moneyFieldset = getFieldset(moneyInput);
    const maxL = moneyInput.maxLength;

    moneyInput.addEventListener('blur', () => {
      const money = checkInput(moneyInput.value, maxL);
      const contL = maxL + 4;
      if (money !== 0) { moneyInput.setAttribute('maxlength', `${contL}`); moneyInput.value = `${money} €`; } else {
        // moneyInput.value = '';
        moneyInput.setAttribute('maxlength', `${maxL}`);
        // moneyFieldset.querySelector('.fieldset').classList.remove('active');
      }
      regexValidate(regexMoney, moneyInput, moneyFieldset);
    });
  }


  // Add maxlenght Age
  document.querySelector('#ID-9').setAttribute('maxlength', '2');
  document.querySelector('#ID-14').setAttribute('maxlength', '2');


  // Validate Months Input and Add maxlenght
  const month = document.querySelector('#ID-7');
  month.setAttribute('maxlength', '2');
  const monthFieldset = getFieldset(month);

  month.addEventListener('blur', () => {
    regexValidate(regexMonths, month, monthFieldset);
  });

  // Validate Age Input
  const ageInputs = prequalifierForm.getElementsByClassName('input-distinguisher_edad');
  for (let i = 0; i < ageInputs.length; i++) {
    const ageInput = ageInputs[i];
    const ageFieldset = getFieldset(ageInput);
    if (ageInput) assignmentRequiredRegex(1, ageInput, regexAge, ageFieldset);
  }

  // Name
  const nameInput = prequalifierForm.querySelector('.input-distinguisher_name');
  const nameFieldset = getFieldset(nameInput);
  const isNameRequired = isFieldRequired(nameInput);

  if (nameInput) assignmentRequiredRegex(isNameRequired, nameInput, nameRegex, nameFieldset);

  // Surname
  const surnameInput = prequalifierForm.querySelector('.input-distinguisher_surname');
  const surnameFieldset = getFieldset(surnameInput);
  const isSurnameRequired = isFieldRequired(surnameInput);

  if (surnameInput) assignmentRequiredRegex(isSurnameRequired, surnameInput, nameRegex, surnameFieldset);

  // Email
  const emailInput = prequalifierForm.querySelector('.input-distinguisher_email');
  const emailFieldset = getFieldset(emailInput);
  const isEmailRequired = isFieldRequired(emailInput);

  if (emailInput) assignmentRequiredRegex(isEmailRequired, emailInput, emailRegex, emailFieldset);

  // Numbers' masks
  // const prefixMaskOptions = { mask: '{+}000', };
  const phoneNumberMaskOptions = { mask: '000 000 000 000', };

  // Phone number
  const phoneNumberInput = prequalifierForm.querySelector('.input-distinguisher_phone-number');
  const phoneNumberFieldset = getFieldset(phoneNumberInput);
  const isPhoneNumberRequired = isFieldRequired(phoneNumberInput);
  const phoneNumberRegex = phoneNumberInput ? new RegExp(`^[0-9 ]{${9},}$`) : null;

  // Mask Phone
  if (isPhoneNumberRequired) {
    IMask(phoneNumberInput, phoneNumberMaskOptions);
    assignmentRequiredRegex(isPhoneNumberRequired, phoneNumberInput, phoneNumberRegex, phoneNumberFieldset);
  }

  // Choose between two options
  const prequalifierTestOrValidateStepSelects = (id, type) => {
    const idStep = document.getElementById(id).getElementsByClassName('form-select');
    let flag = true;
    for (let k = 0; k < idStep.length; k++) {
      const stepSelects = idStep[k];
      const stepSelectsChosenOption = stepSelects ? stepSelects.querySelector('.access-select__chosen-option') : null;
      const SelectInput = stepSelects ? stepSelects.getElementsByClassName('access-select__input') : null;
      const isStepSelectsRequired = isFieldRequired(stepSelects);

      if (type === 'test') {
        if (!(isRequiredTestPass(isStepSelectsRequired, selectTest(stepSelectsChosenOption)))) {
          return false;
        }
      } else {
        if (isStepSelectsRequired) {
          for (let i = 0; i < SelectInput.length; i++) {
            selectValidate(stepSelectsChosenOption, stepSelects);
          }
          if (flag) {
            scrollTo(stepSelectsChosenOption, scrollToErrorDuration, scrollToErrorOffset);
            flag = false;
          }
        }
      }
    }
    return true;
  };

  // Active or Desactive Radio Group 2Holders prequalifierForm
  const titular2 = prequalifierForm.querySelector('#titular2');
  const radioGroup = prequalifierForm.querySelector('#ID-8').getElementsByClassName('radio');
  const titular2form = titular2.getElementsByClassName('form-list__field');
  for (let i = 0; i < radioGroup.length; i++) {
    radioGroup[i].addEventListener('click', () => {
      if (i) { titular2.className = 'titular active'; } else { titular2.className = 'titular inactive'; }
      for (let j = 0; j < titular2form.length; j++) {
        if (i) { titular2form[j].className = 'form-list__field required'; } else { titular2form[j].className = 'form-list__field'; }
      }
    });
  }

  // Test Steps Prequalifier
  const prequalifierTest = idStep => {
    switch (idStep) {
      case 'step1':
        if (prequalifierTestOrValidateStepSelects(idStep, 'test')
        && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-5')), regexTest(regexMoney, prequalifierForm.querySelector('#ID-5')))
        && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-6')), regexTest(regexMoney, prequalifierForm.querySelector('#ID-6')))
        && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-7')), regexTest(regexMonths, prequalifierForm.querySelector('#ID-7')))
        ) return true;
        break;
      case 'step2':
        if (prequalifierTestOrValidateStepSelects(idStep, 'test')
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-9')), regexTest(regexAge, prequalifierForm.querySelector('#ID-9')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-11')), regexTest(regexMoney, prequalifierForm.querySelector('#ID-11')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-13')), regexTest(regexMoney, prequalifierForm.querySelector('#ID-13')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-14')), regexTest(regexAge, prequalifierForm.querySelector('#ID-14')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-16')), regexTest(regexMoney, prequalifierForm.querySelector('#ID-16')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-18')), regexTest(regexMoney, prequalifierForm.querySelector('#ID-18')))
        ) return true;
        break;
      case 'step3':
        if (isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-19')), regexTest(nameRegex, prequalifierForm.querySelector('#ID-19')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-20')), regexTest(nameRegex, prequalifierForm.querySelector('#ID-20')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-21')), regexTest(emailRegex, prequalifierForm.querySelector('#ID-21')))
         && isRequiredTestPass(isFieldRequired(prequalifierForm.querySelector('#ID-22')), regexTest(phoneNumberRegex, prequalifierForm.querySelector('#ID-22')))
        ) return true;
        break;
      default:
        return false;
    }
  };

  // Validate Steps Prequalifier
  const prequalifierFormValidate = idStep => {
    switch (idStep) {
      case 'step1':
        prequalifierTestOrValidateStepSelects(idStep, 'validate');
        // Cambiar aqui
        regexValidate(regexMoney, prequalifierForm.querySelector('#ID-5'), getFieldset(prequalifierForm.querySelector('#ID-5')));
        regexValidate(regexMoney, prequalifierForm.querySelector('#ID-6'), getFieldset(prequalifierForm.querySelector('#ID-6')));
        regexValidate(regexMonths, prequalifierForm.querySelector('#ID-7'), getFieldset(prequalifierForm.querySelector('#ID-7')));
        break;
      case 'step2':
        prequalifierTestOrValidateStepSelects(idStep, 'validate');
        regexValidate(regexAge, prequalifierForm.querySelector('#ID-9'), getFieldset(prequalifierForm.querySelector('#ID-9')));
        regexValidate(regexMoney, prequalifierForm.querySelector('#ID-11'), getFieldset(prequalifierForm.querySelector('#ID-11')));
        regexValidate(regexMoney, prequalifierForm.querySelector('#ID-13'), getFieldset(prequalifierForm.querySelector('#ID-13')));
        if (titular2.className === 'titular active') {
          regexValidate(regexAge, prequalifierForm.querySelector('#ID-14'), getFieldset(prequalifierForm.querySelector('#ID-14')));
          regexValidate(regexMoney, prequalifierForm.querySelector('#ID-16'), getFieldset(prequalifierForm.querySelector('#ID-16')));
          regexValidate(regexMoney, prequalifierForm.querySelector('#ID-18'), getFieldset(prequalifierForm.querySelector('#ID-18')));
        }
        break;
      case 'step3':
        regexValidate(nameRegex, prequalifierForm.querySelector('#ID-19'), getFieldset(prequalifierForm.querySelector('#ID-19')));
        regexValidate(nameRegex, prequalifierForm.querySelector('#ID-20'), getFieldset(prequalifierForm.querySelector('#ID-20')));
        regexValidate(emailRegex, prequalifierForm.querySelector('#ID-21'), getFieldset(prequalifierForm.querySelector('#ID-21')));
        regexValidate(phoneNumberRegex, prequalifierForm.querySelector('#ID-22'), getFieldset(prequalifierForm.querySelector('#ID-22')));
        break;
      default:
      // code block
    }
  };


  const prequalifierFormSteps = prequalifierForm.getElementsByClassName('prequalifier-step');
  // Changes Steps pages
  for (let i = 0; i < prequalifierFormSteps.length; i++) {
    const idStep = prequalifierFormSteps[i].id;
    const buttonsStep = prequalifierFormSteps[i].getElementsByClassName('btn');
    for (let j = 0; j < buttonsStep.length; j++) {
      if (buttonsStep[j].getAttribute('type') === 'continue' || (buttonsStep[j].getAttribute('type') === 'submit')) {
        buttonsStep[j].addEventListener('click', e => {
          if (!prequalifierTest(idStep)) {
            e.preventDefault();
            prequalifierFormValidate(idStep);
          } else {
            if (!(buttonsStep[j].getAttribute('type') === 'submit')) { fadeOut(prequalifierFormSteps[i], fadeIn, prequalifierFormSteps[i + 1]); }
          }
        });
      } else {
        if (buttonsStep[j].getAttribute('type') === 'back') {
          buttonsStep[j].addEventListener('click', () => {
            fadeOut(prequalifierFormSteps[i], fadeIn, prequalifierFormSteps[i - 1]);
          });
        }
      }
    }
  }
};
export default prequalifierForms;
