import userAccessAjax from '@/js/Pages/digitalJourney/userAccessAjax';
import getClosestElement from '../../Helpers/getClosestElement';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import regexTest from '../regexTest';
import regexValidate from '../regexValidate';
import { assignmentRequiredRegex, isFieldRequired } from '../formsFunctions';

const proceduresLoginForms = djLoginForm => {
  const emailRegex = /^[-a-z0-9~!$%^&*_=+}{'?]+(\.[-a-z0-9~!$%^&*_=+}{'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;
  const getFieldset = input => getClosestElement(input, '.form-fieldset');
  const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z#?!@$%^&*-]{8,}$/;


  // Email
  const emailInput = djLoginForm ? djLoginForm.querySelector('.input-distinguisher_email') : null;
  const emailFieldset = getFieldset(emailInput);
  const isEmailRequired = isFieldRequired(emailInput);

  if (emailInput) assignmentRequiredRegex(isEmailRequired, emailInput, emailRegex, emailFieldset);

  // Password
  const passwordInput = djLoginForm ? djLoginForm.querySelector('.input-distinguisher_password') : null;
  const passwordFieldset = getFieldset(passwordInput);
  const isPasswordRequired = isFieldRequired(passwordInput);

  // On blur
  if (passwordInput) assignmentRequiredRegex(isPasswordRequired, passwordInput, passwordRegex, passwordFieldset);

  // Test form (Light validation variant without visuals, used in regular validation)
  const procedureLoginTest = () => {
    if (isRequiredTestPass(
      isEmailRequired,
      regexTest(emailRegex, emailInput)
    ) &&
    isRequiredTestPass(
      isPasswordRequired,
      regexTest(passwordRegex, passwordInput)
    )) {
      return true;
    }
    return false;
  };

  // Validate form
  const procedureLoginValidate = () => {
    if (isEmailRequired && !regexTest(emailRegex, emailInput)) {
      regexValidate(emailRegex, emailInput, emailFieldset);
    }
    if (isPasswordRequired && !regexTest(passwordRegex, passwordInput)) {
      regexValidate(passwordRegex, passwordInput, passwordFieldset);
    }
  };

  djLoginForm.addEventListener('submit', e => {
    e.preventDefault();
    if (!procedureLoginTest()) {
      // Not passing validation
      procedureLoginValidate();
    } else {
      // is validated
      if (djLoginForm.id === 'login-form') {
        userAccessAjax.sendLogin();
      }
      if (djLoginForm.id === 'reset-pass') {
        userAccessAjax.resetPass();
      }
    }
  });
};

export default proceduresLoginForms;
