import { fadeOut } from '@/js/Helpers/fade';

const contactPageAjax = contactForm => {
  const feedbackLightboxContainer = document.querySelector('.contact-form-page.lightbox');
  const LightboxTrigger = feedbackLightboxContainer.querySelector('.lightbox__trigger button');
  const msgSuccess = feedbackLightboxContainer.querySelector('.contact-form__success');
  const msgError = feedbackLightboxContainer.querySelector('.contact-form__error');
  msgSuccess.style.display = 'none';
  msgError.style.display = 'none';


  const xhr = new XMLHttpRequest();
  const data = new FormData(contactForm);


  function feedbackForm(status) {
    if (status === 'OK') {
      msgSuccess.style.display = 'block';
      LightboxTrigger.click();
    } else {
      msgError.style.display = 'block';
      LightboxTrigger.click();
    }
  }


  xhr.open('POST', contactForm.getAttribute('action'));
  xhr.onload = () => {
    if (xhr.status === 200) {
      // Success
      feedbackForm('OK');
      // console.log('xhr.status Success', xhr.status);
    } else if (xhr.status !== 200) {
      // Error
      feedbackForm('KO');
      // console.log('xhr.status Error', xhr.status);
    }
  };

  xhr.send(data);
};

export default contactPageAjax;
