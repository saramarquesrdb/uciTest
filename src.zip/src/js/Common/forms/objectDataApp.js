const objectDataApp = {
  errorCounterFormCommunities: 0
}

export default objectDataApp
