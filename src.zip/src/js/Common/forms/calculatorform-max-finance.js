import scrollTo from '../../Helpers/scrollTo';
import rangeSlider from '../rangeSlider';

const maxFinanceCalculatorForm = form => {
  let hasRun = false;
  const scrollToErrorDuration = 500;
  const scrollToErrorOffset = 25;

  const formEl = document.querySelector('#maxFinanceCalculatorForm');
  const vars = JSON.parse(formEl.getAttribute('data-variables'));
  formEl.removeAttribute('data-variables');

  let savingsSlider = rangeSlider(
    '#SavingsRangeSlider .range-slider__slider',
    '#SavingsRangeSlider .range-slider__input'
  );

  const toEUR = src => src.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
  const digits = (src, n) => src.toLocaleString('es-ES', { minimumFractionDigits: n, maximumFractionDigits: n });

  const provinces = [
    {
      name: 'ALAVA', AJD: 0, ITP: 4, IVA: 10
    },
    {
      name: 'ALBACETE', AJD: 1.5, ITP: 9, IVA: 10
    },
    {
      name: 'ALICANTE', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'ALMERIA', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'ASTURIAS', AJD: 1.2, ITP: 8, IVA: 10
    },
    {
      name: 'AVILA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'BADAJOZ', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'BALEARES', AJD: 1.2, ITP: 8, IVA: 10
    },
    {
      name: 'BARCELONA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'BURGOS', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'CACERES', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'CADIZ', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'CANTABRIA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'CASTELLON', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'CEUTA', AJD: 0.5, ITP: 6, IVA: 10
    },
    {
      name: 'CIUDAD REAL', AJD: 1.5, ITP: 9, IVA: 10
    },
    {
      name: 'CORDOBA', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'CUENCA', AJD: 1.5, ITP: 9, IVA: 10
    },
    {
      name: 'GIRONA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'GRANADA', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'GUADALAJARA', AJD: 1.5, ITP: 9, IVA: 10
    },
    {
      name: 'GUIPUZCOA', AJD: 0, ITP: 4, IVA: 10
    },
    {
      name: 'HUELVA', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'HUESCA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'JAEN', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'LA CORUÑA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'LA RIOJA', AJD: 1, ITP: 7, IVA: 10
    },
    {
      name: 'LAS PALMAS', AJD: 0.4, ITP: 6.5, IVA: 6.5
    },
    {
      name: 'LEON', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'LERIDA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'LUGO', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'MADRID', AJD: 0.7, ITP: 6, IVA: 10
    },
    {
      name: 'MALAGA', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'MELILLA', AJD: 0.5, ITP: 6, IVA: 10
    },
    {
      name: 'MURCIA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'NAVARRA', AJD: 0.5, ITP: 6, IVA: 10
    },
    {
      name: 'ORENSE', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'PALENCIA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'PONTEVEDRA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'SALAMANCA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'SEGOVIA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'SEVILLA', AJD: 1.2, ITP: 7, IVA: 10
    },
    {
      name: 'SORIA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'TARRAGONA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'TENERIFE', AJD: 0.4, ITP: 6.5, IVA: 10
    },
    {
      name: 'TERUEL', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'TOLEDO', AJD: 1.5, ITP: 9, IVA: 10
    },
    {
      name: 'VALENCIA', AJD: 1.5, ITP: 10, IVA: 10
    },
    {
      name: 'VALLADOLID', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'VIZCAYA', AJD: 0, ITP: 4, IVA: 10
    },
    {
      name: 'ZAMORA', AJD: 1.5, ITP: 8, IVA: 10
    },
    {
      name: 'ZARAGOZA', AJD: 1.5, ITP: 8, IVA: 10
    }
  ];

  let province;
  const getProvince = p => {
    province = p ?
      provinces.find(x => x.name === p) :
      provinces.find(x => x.name === document.querySelector('#province-input').value);
  };

  const validateProvince = ignoreErrors => {
    if (ignoreErrors || province) {
      if (form.querySelector('#province').classList.contains('error')) {
        form.querySelector('#province').classList.remove('error');
      }

      form.querySelector('#province').classList.add('valid');
      return true;
    }

    if (!form.querySelector('#province').classList.contains('error')) {
      form.querySelector('#province').classList.remove('valid');
      form.querySelector('#province').classList.add('error');
    }

    scrollTo(form.querySelector('#province'), scrollToErrorDuration, scrollToErrorOffset);
    return false;
  };

  const income = form.querySelector('#ingresosMes');
  const validateIncome = ignoreErrors => {
    if (income.value === '0' || income.value === '' ||
      (parseInt(income.value, 10) < 0 && parseInt(income.value, 10) > 400000)) {
      if (ignoreErrors !== true) {
        form.querySelector('#ingresos-Mes').classList.add('error');
      }

      scrollTo(form, scrollToErrorDuration, scrollToErrorOffset);
      return false;
    }

    form.querySelector('#ingresos-Mes').classList.remove('error');
    return true;
  };

  let importe = vars.DefaultHousePrice;
  let financiamos = Math.min(parseFloat((importe * vars.MaxFinancingPercentage) / 100), vars.MaxMortgageAmount);
  let aportacion = importe - financiamos;
  let maxAportacion = parseInt(importe - vars.MinMortgageAmount, 10);
  let minAportacion = parseInt(importe - financiamos, 10);

  getProvince();
  validateProvince(true);
  validateIncome(true);
  const validateCalculator = () => {
    const provinceValidation = validateProvince();
    const incomeValidation = validateIncome();
    return provinceValidation && incomeValidation;
  };

  const goToResults = () => {
    const divResultados = document.getElementById('DivResultados');
    if (divResultados.style.display !== 'none') {
      scrollTo(divResultados, scrollToErrorDuration, scrollToErrorOffset);
    }
  };

  const calcularFinanciacion = () => {
    importe = parseFloat(document.getElementById('MortgageHousePriceRangeInput').value.replace('.', ''));
    financiamos = Math.min(parseFloat((importe * vars.MaxFinancingPercentage) / 100), vars.MaxMortgageAmount);
    aportacion = importe - financiamos;
    maxAportacion = parseInt(importe - vars.MinMortgageAmount, 10);
    minAportacion = parseInt(importe - financiamos, 10);
  };

  const mostrarFinanciacion = () => {
    document.getElementById('MortgageAmountInput').value = digits(parseInt(financiamos, 10), 0);
    document.getElementById('SavingsRangeInput').value = digits(parseInt(aportacion, 10), 0);
    document.getElementById('SavingsRangeInput').setAttribute('max', maxAportacion);
    document.getElementById('SavingsRangeInput').setAttribute('min', minAportacion);
    document.getElementById('SavingsRangeInput').setAttribute('data-default', aportacion);
    savingsSlider.destroy();
    savingsSlider = rangeSlider(
      '#SavingsRangeSlider .range-slider__slider',
      '#SavingsRangeSlider .range-slider__input'
    );
    document.getElementById('aportacion-end').innerText = toEUR(maxAportacion);
    document.getElementById('aportacion-start').innerText = toEUR(minAportacion);
    document.getElementById('entrada-value').innerText = toEUR(aportacion);
    document.getElementById('lb-entrada-value').innerText = toEUR(aportacion);
  };

  const calcularGastos = () => {
    if (validateCalculator()) {
      let impuesto;
      let IAJD = 0;
      if (document.getElementById('tipoViviendaNueva').checked === true) {
        impuesto = province.IVA;
        IAJD = importe * province.AJD / 100;
      }
      if (document.getElementById('tipoViviendaSegundaMano').checked === true) {
        impuesto = province.ITP;
      }

      // const tasacion = vars.Appraisal * 1.21;
      // if (importe > 500000) {
      //   tasacion = ((importe * 0.06) / 100) * 1.21;
      // }
      // const comisionAperturaImporte = vars.OpeningCommission * importe / 100;

      const impuestoPagar = (importe * impuesto) / 100;
      const gastos = vars.Notary + vars.Registry + vars.ProcessingAgency + impuestoPagar;

      document.getElementById('impuestos-value').innerText = toEUR(gastos);
      document.getElementById('total-value').innerText = toEUR(aportacion + gastos);
      document.getElementById('lb-notaria-value').innerText = toEUR(vars.Notary);
      document.getElementById('lb-registro-value').innerText = toEUR(vars.Registry);
      document.getElementById('lb-gestoria-value').innerText = toEUR(vars.ProcessingAgency);
      document.getElementById('lb-impuestos-value').innerText = toEUR(impuestoPagar);
      document.getElementById('lb-total-value').innerText = toEUR(aportacion + gastos);
      goToResults();
    }
  };

  const validarPuntos = evt => {
    evt.currentTarget.value = evt.currentTarget.value
      .replace(/\D/g, '')
      .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, '.');
  };

  const quitarCero = evt => {
    if (document.getElementById(evt.currentTarget.id).value === '0') {
      document.getElementById(evt.currentTarget.id).value = '';
    }
  };

  const fullCalculator = (e, firstRun) => {
    if (validateCalculator()) {
      hasRun = true;
      e.preventDefault();
      if (!firstRun) calcularFinanciacion();
      form.querySelector('#DivSubmit').style.display = 'none';
      form.querySelector('#DivResultados').style.display = 'block';
      mostrarFinanciacion();
      calcularGastos();
      e.stopPropagation();
    }
  };

  const savingsUpdated = () => {
    const savings = parseInt(document.getElementById('SavingsRangeInput').value.replace('.', ''), 10);
    const diff = importe - savings;
    if (diff < vars.MinMortgageAmount) {
      financiamos = vars.MinMortgageAmount;
      aportacion = maxAportacion;
    } else {
      financiamos = diff;
      aportacion = savings;
    }

    mostrarFinanciacion();
    calcularGastos();
  };

  // Eventos
  document.getElementById('bntCalcular').addEventListener('click', e => { fullCalculator(e, true); });
  document.getElementById('ingresosMes').addEventListener('focus', quitarCero, true);
  document.getElementById('ingresosMes').addEventListener('keyup', validarPuntos, false);
  document.getElementById('ingresosMes').addEventListener('keyup', validateIncome, false);
  document.getElementById('gastosMes').addEventListener('focus', quitarCero, true);
  document.getElementById('gastosMes').addEventListener('keyup', validarPuntos, false);
  document.getElementById('tipoViviendaNueva').addEventListener('change', calcularGastos);
  document.getElementById('tipoViviendaSegundaMano').addEventListener('change', calcularGastos);
  document.getElementById('SavingsRangeInput').addEventListener('change', savingsUpdated);
  document.getElementById('MortgageHousePriceRangeInput').addEventListener('change', fullCalculator);
  document.querySelectorAll('#province .access-select__item').forEach(e => {
    e.addEventListener('click', ev => {
      getProvince(ev.target.value);
      if (hasRun) {
        calcularGastos();
      }
    });
  });
  document.getElementById('LnkGastos').addEventListener('click', () => {
    document.getElementById('calculatorLightbox3').style.display = 'block';
  });
  document.getElementById('CloseGastos').addEventListener('click', () => {
    document.getElementById('calculatorLightbox3').style.display = 'none';
  });
};

export default maxFinanceCalculatorForm;
