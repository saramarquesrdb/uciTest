import { jsLog, localeFormatNumber } from "@/js/Helpers/_helpers";
import IMask from 'imask';

export const formValidator = (form) => {
  const allInputs = form.querySelectorAll('input');
  const allInputsTextRequired = form.querySelectorAll(
    '.required input[type="text"], .required input[type="radio"]'
  );

  const regex = {
    integer: /^[0-9]+$/,
    monthYear: /^(0[1-9]|1[0-2])\/\d{4}$/,
    YYYY_MM_DD: /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/
  };

  const functions = {
    fieldIterator() {
      allInputsTextRequired.forEach(input => {
        if (input.classList.contains('integer')) {
          IMask(input, { mask: regex.integer });
        }

        input.addEventListener('blur', e => {
          this.handleInputEvents(e);
          this.tagFormAsValid();
        });

        input.addEventListener('input', e => this.handleInputEvents(e));

        if (input.type === 'radio') {
          input.addEventListener('change', e => {
            this.handleInputEvents(e);
            this.tagFormAsValid();
          });
        }
      });
    },

    handleInputEvents(event) {
      const input = event.target;
      this.fieldValidator(input);

      if (input.getAttribute("inputmode") === "numeric" && input.type === 'text') {
        input.value = localeFormatNumber(input.value).toString();
      }
    },

    tagFormAsValid() {
      if (this.isFormValid()) {
        form.classList.add('valid');
        form.classList.remove('not-valid');
        jsLog("--> IS VALID");
      } else {
        form.classList.remove('valid');
        form.classList.add('not-valid');
        jsLog("--> IS NOT VALID");
      }
    },

    fieldValidator(input) {
      const controlParent = this.elementControlParent(input);
      const dataVal = input.getAttribute('data-validate');

      const validations = {
        isEmpty: (() => {
          if (input.type === 'radio') {
            const group = form.querySelectorAll(`input[name="${input.name}"]`);
            return !Array.from(group).some(radio => radio.checked);
          }
          return input.value.trim() === '';
        })(),

        max() {
          if (!input.hasAttribute('data-max') || input.type !== 'text') return false;
          const val = parseFloat(input.value.replace(/\./g, '').replace(',', '.'));
          const max = parseFloat(input.getAttribute('data-max'));
          return val > max;
        },

        min() {
          if (!input.hasAttribute('data-min') || input.type !== 'text') return false;
          const val = parseFloat(input.value.replace(/\./g, '').replace(',', '.'));
          const min = parseFloat(input.getAttribute('data-min'));
          return val < min;
        },

        date() {
          if (dataVal === "YYYY_MM_DD") {
            return !regex.YYYY_MM_DD.test(input.value);
          }
          return false;
        }
      };

      const hasError = validations.isEmpty || validations.max() || validations.min() || validations.date();

      if (hasError) {
        controlParent?.classList.add('error');
        return false;
      } else {
        controlParent?.classList.remove('error');
        return true;
      }
    },

    elementControlParent(input) {
      if (input.closest('.form-input')) return input.closest('.form-input');
      if (input.closest('.form-select')) return input.closest('.form-select');
      if (input.closest('.form-fieldset')) return input.closest('.form-fieldset');
      return input.parentElement;
    },

    isFormValid() {
      let valid = true;
      allInputsTextRequired.forEach(input => {
        const controlParent = this.elementControlParent(input);
        if (controlParent?.classList.contains('error') && controlParent.parentElement?.classList.contains('required')) {
          valid = false;
        }
      });
      return valid;
    },

    changeListener() {
      allInputs.forEach(input => {
        input.addEventListener('change', () => {
          this.tagFormAsValid();
        });
      });
    },

    init() {
      this.fieldIterator();
      this.changeListener();
      this.tagFormAsValid();
    }
  };

  functions.init();
  return functions;
};

export default formValidator;