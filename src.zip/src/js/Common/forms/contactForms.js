import IMask from 'imask';
import getClosestElement from '../../Helpers/getClosestElement';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import scrollTo from '../../Helpers/scrollTo';
import regexTest from '../regexTest';
import selectTest from '../selectTest';
import radioTest from '../radioTest';
import checkboxTest from '../checkboxTest';
import regexValidate from '../regexValidate';
import selectValidate from '../selectValidate';
import radioValidate from '../radioValidate';
import checkboxValidate from '../checkboxValidate';
import lightboxFormAjax from '../lightboxFormAjax';
import contactPageAjax from './contactPageAjax';
import { assignmentRequired, assignmentRequiredRegex, isFieldRequired, getFieldset, getField, assignmentAllowOnlyLetters } from '../formsFunctions';
import exchangeData from "@/js/Helpers/exchangeData";
import { $, smoothScroll } from "@/js/Helpers/_helpers";
import constants from './_constants'

const contactForms = contactForm => {
  const nonAjaxForms = ['contact-highlight-form', 'contact-form', 'resource-form', 'newsletter-form'];
  const isAjax = !nonAjaxForms.includes(contactForm.id);
  contactForm.setAttribute('data-ajax', isAjax.toString());

  SetGoogleId(contactForm);
  const scrollToErrorDuration = 500;
  const scrollToErrorOffset = 100;

  const resourceFormLoader = document.getElementById('resourceFormLoader');
  const newsletterFormLoader = document.getElementById('newsletterFormLoader');
  const ptContactFormLoader = document.getElementById('ptContactFormLoader');
  const contactFormPtLoader = document.getElementById('contactFormPt');

  // Name
  const nameInput = contactForm.querySelector('.input-distinguisher_name');
  const nameFieldset = getFieldset(nameInput);
  const isNameRequired = isFieldRequired(nameInput);


  if (nameInput) assignmentRequiredRegex(isNameRequired, nameInput, constants.nameRegex, nameFieldset);
  if (nameInput) assignmentAllowOnlyLetters(nameInput);
  // Surname
  const surnameInput = contactForm.querySelector('.input-distinguisher_surname');
  const surnameFieldset = getFieldset(surnameInput);
  const isSurnameRequired = isFieldRequired(surnameInput);

  if (surnameInput) assignmentRequiredRegex(isSurnameRequired, surnameInput, constants.nameRegex, surnameFieldset);
  if (surnameInput) assignmentAllowOnlyLetters(surnameInput);

  // Prefix (input)
  const prefixInput = contactForm.querySelector('.input-distinguisher_prefix');
  const prefixFieldset = getFieldset(prefixInput);
  const isPrefixRequired = isFieldRequired(prefixInput);
  const prefixMinLength = prefixInput ? prefixInput.getAttribute('minlength') : null;
  const prefixRegex = prefixInput ? new RegExp(`^[+0-9]{${prefixMinLength},}$`) : null;

  // Mask Prefix
  if (prefixInput) {
    IMask(prefixInput, constants.prefixMaskOptions);
    assignmentRequiredRegex(isPrefixRequired, prefixInput, prefixRegex, prefixFieldset);
  }

  // Prefix (select)
  const prefix = contactForm.querySelector('.form-select-distinguisher_prefix');
  const prefixChosenOption = prefix ? prefix.querySelector('.access-select__chosen-option_hidden') : null;
  const prefixSelectInput = prefix ? prefix.getElementsByClassName('access-select__input') : null;
  const isPrefixSelectRequired = isFieldRequired(prefix);
  if (prefix) assignmentRequired(isPrefixSelectRequired, prefix, prefixSelectInput, 'select');

  // Phone number
  const phoneNumberInput = contactForm.querySelector('.input-distinguisher_phone-number');
  const phoneNumberFieldset = getFieldset(phoneNumberInput);
  const isPhoneNumberRequired = isFieldRequired(phoneNumberInput);
  const phoneNumberMinLength = phoneNumberInput ? phoneNumberInput.getAttribute('minlength') : null;
  const phoneNumberRegex = phoneNumberInput ? new RegExp(`^[0-9 ]{${phoneNumberMinLength},}$`) : null;

  if (phoneNumberInput) {
    IMask(phoneNumberInput, constants.phoneNumberMaskOptions);
    assignmentRequiredRegex(isPhoneNumberRequired, phoneNumberInput, phoneNumberRegex, phoneNumberFieldset);
  }

  // Email
  const emailInput = contactForm.querySelector('.input-distinguisher_email');
  const emailFieldset = getFieldset(emailInput);
  const isEmailRequired = isFieldRequired(emailInput);

  if (emailInput) assignmentRequiredRegex(isEmailRequired, emailInput, constants.emailRegex, emailFieldset);

  // Is Client (radio)
  const isClient = contactForm.querySelector('#radio-group-uciclient');
  const isClientRadio = isClient ? isClient.getElementsByClassName('radio-input') : null;
  const isClientField = getField(isClient);
  const isIsClientRequired = isFieldRequired(null, isClientField);
  if (isClient) assignmentRequired(isIsClientRequired, isClient, isClientRadio, 'radio');

  // Plans to request a credit 
  const wantsCredit = contactForm.querySelector('#radio-group-creditrequest');
  const wantsCreditRadio = wantsCredit ? wantsCredit.getElementsByClassName('radio-input') : null;
  const wantsCreditField = getField(wantsCredit);
  const isWantsCreditRequired = isFieldRequired(null, wantsCreditField);
  if (wantsCredit) assignmentRequired(isWantsCreditRequired, wantsCredit, wantsCreditRadio, 'radio');

  // Contact type
  const contactType = contactForm.querySelector('.form-radio-group-distinguisher_contact-type');
  const contactTypeRadio = contactType ? contactType.getElementsByClassName('radio-input') : null;
  const contactTypeField = getField(contactType);
  const isContactTypeRequired = isFieldRequired(null, contactTypeField);

  if (contactType) assignmentRequired(isContactTypeRequired, contactType, contactTypeRadio, 'radio');

  // Call time
  const callTime = contactForm.querySelector('.form-select-distinguisher_call-time');
  const callTimeChosenOption = callTime ? callTime.querySelector('.access-select__chosen-option') : null;
  const callTimeSelectInput = callTime ? callTime.getElementsByClassName('access-select__input') : null;
  const isCallTimeRequired = isFieldRequired(callTime);

  if (callTime) assignmentRequired(isCallTimeRequired, callTime, callTimeSelectInput, 'select');

  // More info Text Area Contact Form
  const moreInfoTextarea = contactForm.querySelector('.input-distinguisher_more-info-textarea');
  const moreInfoTextareaFieldset = getFieldset(moreInfoTextarea);
  const isMoreInfoTextareaRequired = isFieldRequired(moreInfoTextarea);
  const moreInfoTextareaMinLength = moreInfoTextarea ? moreInfoTextarea.getAttribute('minlength') : null;
  const moreInfoTextareaMaxLength = moreInfoTextarea ? moreInfoTextarea.getAttribute('maxlength') : null;
  const moreInfoTextareaRegex = moreInfoTextarea ? new RegExp(`^[\\S\\s]{${moreInfoTextareaMinLength},${moreInfoTextareaMaxLength}}$`) : null;
  if(moreInfoTextarea){
    moreInfoTextarea.addEventListener('input', () => {
      const charCount = moreInfoTextarea.value.length;
      const errorContainer = moreInfoTextarea.closest('.form-textarea')
      .querySelector('.field-bottom__error-message');

      if (charCount >= moreInfoTextareaMaxLength) {
        errorContainer.style.display = 'block';
      }
      else{
        if(errorContainer.style.display !== "none"){
          errorContainer.style.display = 'none';
        }
      }
  });
  }
  // On blur
  if (moreInfoTextarea) assignmentRequiredRegex(isMoreInfoTextareaRequired, moreInfoTextarea, moreInfoTextareaRegex, moreInfoTextareaFieldset);

  // contactThroughPhone - Contact Call CallMeback
  const contactThroughPhone = contactForm ? contactForm.querySelector('.radio-distinguisher_contact-through-phone') : null;
  const isContactThroughPhoneChecked = () => {
    if (contactThroughPhone) {
      if (contactThroughPhone.checked) {
        return selectTest(callTimeChosenOption);
      }
      return true;
    }
    return true;
  };

  const callTimeSelectField = contactForm.querySelector('.form-list__field_call-time');
  const contactThroughCallMeNow = contactForm.querySelector('.radio-distinguisher_contact-through-callme');

  if (contactThroughPhone) {
    contactThroughPhone.addEventListener('click', () => {
      if (contactThroughPhone.checked) {
        callTimeSelectField.style.display = 'block';
      }
    });

    if (contactThroughCallMeNow) {
      contactThroughCallMeNow.addEventListener('click', () => {
        if (!contactThroughPhone.checked) {
          callTimeSelectField.style.display = '';
        }
      });
    }
  }

  // Legal checkboxes
  const contactCheckLegal = contactForm.querySelector('.check-legal');

  const checkLegal = contactCheckLegal ? contactCheckLegal.getElementsByClassName('checkbox-input') : null;
  const checkLegalField = contactCheckLegal ? getClosestElement(contactCheckLegal, '.form-list__field') : null;
  const isCheckRequired = contactCheckLegal ? checkLegalField.classList.contains('required') : null;

  if (contactCheckLegal) {
    // On blur
    if (isCheckRequired) {
      for (let i = 0; i < checkLegal.length; i++) {
        checkLegal[i].addEventListener('blur', () => {
          if (contactCheckLegal.classList.contains('error')) {
            checkboxValidate(checkLegal, contactCheckLegal);
          }
        });
      }
    }
  }

  function CheckUserType() {
    if (contactForm.id === "resource-form") {
      const userType = contactForm.querySelector("#utilizador");
      const userTypeInput = userType.querySelector(".access-select__chosen-option_hidden");
      if (userTypeInput && userTypeInput.value === "") {
        return false;
      } else {
        return true;
      }
    }

    return true;
  }

  function CheckHouseSearch() {
    if (contactForm.id === "resource-form") {
      const houseSearch = contactForm.querySelector("#select2");
      const houseSearchInput = houseSearch.querySelector(".access-select__chosen-option_hidden");
      if (houseSearchInput && houseSearchInput.value === "") {
        return false;
      } else {
        return true;
      }
    }

    return true;
  }

  function SetGoogleId(form) {
    var gIDContact = form.getElementsByClassName('gIdContact');
    var co = document.cookie.match(/_ga=(.+?)(;|$)/) != null ? document.cookie.match(/_ga=(.+?)(;|$)/)[1].split('.').slice(-2).join(".") : "Incognito";
    if (gIDContact.length > 0) {
      gIDContact[0].value = window.location + "{#}" + co;
    }
  }

  // Test form (Light validation variant without visuals, used in regular validation)
  const contactFormTest = () => {
    if (
      isRequiredTestPass(isNameRequired, regexTest(constants.nameRegex, nameInput)) &&
      isRequiredTestPass(
        isSurnameRequired,
        regexTest(constants.nameRegex, surnameInput)
      ) &&
      isRequiredTestPass(
        isEmailRequired,
        regexTest(constants.emailRegex, emailInput)
      ) &&
      isRequiredTestPass(
        isPrefixRequired,
        regexTest(prefixRegex, prefixInput)
      ) &&
      isRequiredTestPass(
        isPrefixSelectRequired,
        selectTest(prefixChosenOption)
      ) &&
      isRequiredTestPass(
        isPhoneNumberRequired,
        regexTest(phoneNumberRegex, phoneNumberInput)
      ) &&
      isRequiredTestPass(
        isMoreInfoTextareaRequired,
        regexTest(moreInfoTextareaRegex, moreInfoTextarea)
      ) &&
      isRequiredTestPass(
        isIsClientRequired,
        radioTest(isClientRadio)
      ) &&
      isRequiredTestPass(
        isWantsCreditRequired,
        radioTest(wantsCreditRadio)
      ) &&
      isRequiredTestPass(
        isContactTypeRequired,
        radioTest(contactTypeRadio)
      ) &&
      isRequiredTestPass(isCallTimeRequired, isContactThroughPhoneChecked())
      && isRequiredTestPass(isCheckRequired, checkboxTest(checkLegal))
      && CheckUserType()
      && CheckHouseSearch()
    ) {
      return true;
    }
    return false;
  };
  // Validate form
  const contactFormValidate = () => {
    let flag = true;

    if (isNameRequired && !regexTest(constants.nameRegex, nameInput)) {
      regexValidate(constants.nameRegex, nameInput, nameFieldset);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isSurnameRequired && !regexTest(constants.nameRegex, surnameInput)) {
      regexValidate(constants.nameRegex, surnameInput, surnameFieldset);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isEmailRequired && !regexTest(constants.emailRegex, emailInput)) {
      regexValidate(constants.emailRegex, emailInput, emailFieldset);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isPrefixRequired && !regexTest(prefixRegex, prefixInput)) {
      regexValidate(prefixRegex, prefixInput, prefixFieldset);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isPrefixSelectRequired && !selectTest(prefixChosenOption)) {
      selectValidate(prefixChosenOption, prefix);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (
      isPhoneNumberRequired &&
      !regexTest(phoneNumberRegex, phoneNumberInput)
    ) {
      regexValidate(phoneNumberRegex, phoneNumberInput, phoneNumberFieldset);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (
      isMoreInfoTextareaRequired &&
      !regexTest(moreInfoTextareaRegex, moreInfoTextarea)
    ) {
      regexValidate(
        moreInfoTextareaRegex,
        moreInfoTextarea,
        moreInfoTextareaFieldset
      );
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isIsClientRequired && !radioTest(isClientRadio)) {
      for (let i = 0; i < isClientRadio.length; i++) {
        radioValidate(isClientRadio[i], isClient);
      }
    }

    if (isWantsCreditRequired && !radioTest(wantsCreditRadio)) {
      for (let i = 0; i < wantsCreditRadio.length; i++) {
        radioValidate(wantsCreditRadio[i], wantsCredit);
      }
    }

    if (isContactTypeRequired && !radioTest(contactTypeRadio)) {
      for (let i = 0; i < contactTypeRadio.length; i++) {
        radioValidate(contactTypeRadio[i], contactType);
      }
    }

    if (isCallTimeRequired && !isContactThroughPhoneChecked()) {
      selectValidate(callTimeChosenOption, callTime);
    }

    if (isCheckRequired && !checkboxTest(checkLegal)) {
      checkboxValidate(checkLegal, contactCheckLegal);
      if (flag) {
        scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (contactForm.id == "resource-form") {
      const userType = contactForm.querySelector("#utilizador");
      const userTypeField = userType ? getClosestElement(userType, '.form-list__field') : null;
      const isUserTypeRequired = userTypeField ? userTypeField.classList.contains('required') : null;
      if (isUserTypeRequired) {
        const userTypeInput = userType.querySelector(".access-select__chosen-option_hidden");
        if (userTypeInput && userTypeInput.value === "") {
          if (flag) {
            scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
            flag = false;
          }
          userType.classList.add("error");
        }
      }

      const houseSearch = contactForm.querySelector("#select2");
      const houseSearchField = houseSearch ? getClosestElement(houseSearch, '.form-list__field') : null;
      const ishouseSearchRequired = houseSearchField ? houseSearchField.classList.contains('required') : null;
      if (ishouseSearchRequired) {
        const houseSearchInput = houseSearch.querySelector(".access-select__chosen-option_hidden");
        if (houseSearchInput && houseSearchInput.value === "") {
          if (flag) {
            scrollTo(nameInput, scrollToErrorDuration, scrollToErrorOffset);
            flag = false;
          }
          houseSearch.classList.add("error");
        }
      }
    }

    // Do scroll on error if form in Lightbox
    if (exchangeData.activeLightboxFormID !== "") {
      const form = $('form#' + exchangeData.activeLightboxFormID);
      smoothScroll(
        form.closest(".lightbox__window"),
        form.querySelector('.form-fieldset.error').offsetTop + 30,
        300);
    }
  };

  const AddDataLayerContact = () => {
    if (window.pageInfo.site == 'ucies') return;
    var useCapture = true;
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      'event': 'form_send',
      'form': 'Contacto',
      'preferenciaContacto': 'teléfono',
    }
      , useCapture);
  };

  function activateLoader(loader) {
    if (loader !== null && loader !== 'undefined') {
      loader.classList.add('active');
    }
  }

  function processFormSubmission(e) {
    if (contactFormTest()) {
      if (contactForm.id === 'contactPage') {
        contactPageAjax(contactForm);
      } else {
        activateLoader(contactFormPtLoader);
        AddDataLayerContact();
        lightboxFormAjax(contactForm, '.contact-form__success');
      }
    } else {
      e.preventDefault();
      contactFormValidate();
    }
  }

  // On submit
  if (contactForm) {
    let isFormValidated = false;
    contactForm.addEventListener('submit', e => {
      if (isAjax) {
        e.preventDefault();
        processFormSubmission(e);
      } else {
        if (!isFormValidated) {
          const test = contactFormTest();
          if (!test) {
            e.preventDefault();
            contactFormValidate();
          } else {
            isFormValidated = true;
            activateLoader(resourceFormLoader);
            activateLoader(newsletterFormLoader);
            activateLoader(ptContactFormLoader);
            activateLoader(contactFormPtLoader);
            contactForm.submit();
          }
        }
      }
    });
  }
};

export default contactForms;
