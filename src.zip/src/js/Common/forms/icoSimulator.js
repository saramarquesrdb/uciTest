export class IcoSimulator {
    constructor(form) {
        this.form = form;
        this.step = 1;
        this.steps = form.querySelectorAll('.steps-nav__list-item').length;
        this.validatedSteps = new Set(); // Para trackear qué pasos ya fueron validados

        this.ensureDependencies().then(() => {
            console.log('Dependencies loaded');
            this.init();
            this.initValidation();
            this.initConditionalFields();
        }).catch(error => {
            console.error('Error loading dependencies:', error);
        });
    }

    async ensureDependencies() {
        console.log('Checking dependencies...');
        console.log('jQuery exists?', typeof jQuery !== 'undefined');

        if (typeof jQuery === 'undefined') {
            console.log('Loading jQuery...');
            await this.loadScript('/sitecore%20modules/Web/ExperienceForms/scripts/jquery-3.4.1.min.js');
            // Esperar a que jQuery esté realmente disponible
            await this.waitForJQuery();
        }

        console.log('jQuery loaded, checking validate...');
        if (typeof jQuery.fn.validate === 'undefined') {
            console.log('Loading jQuery validate...');
            await this.loadScript('/sitecore%20modules/Web/ExperienceForms/scripts/jquery.validate.min.js');
            await this.loadScript('/sitecore%20modules/Web/ExperienceForms/scripts/jquery.validate.unobtrusive.min.js');
            // Esperar a que validate esté disponible
            await this.waitForValidate();
        }
    }

    waitForJQuery() {
        return new Promise(resolve => {
            const checkJQuery = () => {
                if (typeof jQuery !== 'undefined') {
                    resolve();
                } else {
                    setTimeout(checkJQuery, 100);
                }
            };
            checkJQuery();
        });
    }

    waitForValidate() {
        return new Promise(resolve => {
            const checkValidate = () => {
                if (typeof jQuery.fn.validate !== 'undefined') {
                    resolve();
                } else {
                    setTimeout(checkValidate, 100);
                }
            };
            checkValidate();
        });
    }

    loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.type = 'text/javascript';
            script.onload = () => {
                console.log(`Script loaded: ${src}`);
                resolve();
            };
            script.onerror = (error) => {
                console.error(`Error loading script ${src}:`, error);
                reject(error);
            };
            document.head.appendChild(script);
        });
    }

    init() {
        console.log('Initializing events...');
        this.setStep(1);

        const nextButtons = this.form.querySelectorAll('.steps-nav__in-step.next');
        console.log('Found next buttons:', nextButtons.length);

        nextButtons.forEach((el) => {
            el.addEventListener('click', (e) => {
                console.log('Next button clicked');
                e.preventDefault();
                this.validateAndProceed();
            });
        });

        const backButtons = this.form.querySelectorAll('.steps-nav__list-item .link_back');
        console.log('Found back buttons:', backButtons.length);

        backButtons.forEach((el) => {
            el.addEventListener('click', (e) => {
                console.log('Back button clicked');
                e.preventDefault();
                this.setStep(this.step - 1);
            });
        });
    }

    initValidation() {
        const validationConfig = this.buildValidationRules();
        console.log('Validation rules:', validationConfig);

        $(this.form).validate({
            debug: true,
            ignore: ':hidden',
            errorElement: 'span',
            errorClass: 'error-message',
            errorPlacement: (error, element) => {
                console.log('Error placement for:', element.attr('name'), error.text());
                element.closest('.form-list__field').find('.field-bottom__error-message').html(error);
            },
            ...validationConfig,
            invalidHandler: (event, validator) => {
                console.log('Form invalid:', validator.numberOfInvalids(), 'fields are invalid');
            },
            submitHandler: (form, event) => {
                // Aunque en muchos casos no se recibe el evento, si lo recibes puedes llamar a event.preventDefault()
                if (event) {
                    event.preventDefault();
                }
                // Llama a tu método de validación adicional o la lógica de avance de pasos:
                this.validateAndProceed();
                // NOTA: No llames a form.submit() aquí, ya que lo que buscas es controlar el envío.
            }
        });
    }

    initConditionalFields() {
        // Inicializar el estado del campo KidsAmount basado en HasKids
        const hasKidsField = this.form.querySelector('input[name="HasKids"]');
        const kidsAmountContainer = this.form.querySelector('input[name="KidsAmount"]')?.closest('.form-list__item');

        if (hasKidsField && kidsAmountContainer) {
            // Configurar estado inicial
            this.toggleKidsAmount(hasKidsField.checked);

            // Añadir listeners para los cambios
            const radioButtons = this.form.querySelectorAll('input[name="HasKids"]');
            radioButtons.forEach(radio => {
                radio.addEventListener('change', () => {
                    // El valor será true si el radio button con value="true" está seleccionado
                    const hasKids = this.form.querySelector('input[name="HasKids"][value="true"]').checked;
                    console.log('HasKids changed:', hasKids);
                    this.toggleKidsAmount(hasKids);
                });
            });
        }

        // Inicializar el estado de las etiquetas basado en HasSecondaryHolder
        const hasSecondaryHolderRadios = this.form.querySelectorAll('input[name="HasSecondaryHolder"]');
        if (hasSecondaryHolderRadios.length > 0) {
            // Configurar estado inicial
            const initialValue = this.form.querySelector('input[name="HasSecondaryHolder"][value="true"]')?.checked || false;
            this.toggleHolderLabels(initialValue);

            // Añadir listeners para los cambios
            hasSecondaryHolderRadios.forEach(radio => {
                radio.addEventListener('change', () => {
                    const hasSecondaryHolder = this.form.querySelector('input[name="HasSecondaryHolder"][value="true"]').checked;
                    const hasKids = this.form.querySelector('input[name="HasKids"][value="true"]').checked;
                    console.log('HasSecondaryHolder changed:', hasSecondaryHolder);
                    this.toggleHolderLabels(hasSecondaryHolder);
                    this.toggleKidsAmount(hasKids);
                });
            });
        }
    }

    toggleKidsAmount(show) {
        const kidsAmountContainer = this.form.querySelector('input[name="KidsAmount"]')?.closest('.form-list__item');
        if (kidsAmountContainer) {
            kidsAmountContainer.style.display = show ? 'block' : 'none';

            // Si el campo está oculto, limpiamos su valor y errores
            if (!show) {
                const kidsAmountInput = kidsAmountContainer.querySelector('input[name="KidsAmount"]');
                if (kidsAmountInput) {
                    //kidsAmountInput.value = '';
                    // Limpiar los errores del campo específico
                    const validator = $(this.form).validate();
                    if (validator) {
                        validator.resetForm(); // Limpia todos los errores

                        // Remover las clases de error del contenedor
                        const errorWrapper = kidsAmountInput.closest('.form-input');
                        if (errorWrapper) {
                            errorWrapper.classList.remove('error');
                        }

                        // Limpiar el mensaje de error
                        const errorMessage = kidsAmountContainer.querySelector('.field-bottom__error-message');
                        if (errorMessage) {
                            errorMessage.innerHTML = '';
                        }
                    }
                }
            }
        }

        //Para monoparental, solo se muestra si es un titular
        const singleParentContainer = this.form.querySelector('#singleParent')?.closest('.form-list__item');
        var OneHolders = this.form.querySelector('input[name="HasSecondaryHolder"][value="false"]').checked;
        if (singleParentContainer) {
            singleParentContainer.style.display = show && OneHolders ? 'block' : 'none';

            // Si el campo está oculto, limpiamos su valor y errores
            if (!show) {
                const singleParentInput = singleParentContainer.querySelector('#singleParent');
                if (singleParentInput) {
                    singleParentInput.value = '';
                    // Limpiar los errores del campo específico
                    const validator = $(this.form).validate();
                    if (validator) {
                        validator.resetForm(); // Limpia todos los errores

                        // Remover las clases de error del contenedor
                        const errorWrapper = singleParentInput.closest('.form-input');
                        if (errorWrapper) {
                            errorWrapper.classList.remove('error');
                        }

                        // Limpiar el mensaje de error
                        const errorMessage = singleParentContainer.querySelector('.field-bottom__error-message');
                        if (errorMessage) {
                            errorMessage.innerHTML = '';
                        }
                    }
                }
            }
        }

    }

    toggleHolderLabels(hasSecondaryHolder) {
        const singleHolderLabels = this.form.querySelectorAll('[data-holders="1"]');
        const secondaryHolderLabels = this.form.querySelectorAll('[data-holders="2"]');

        singleHolderLabels.forEach(label => {
            label.style.display = hasSecondaryHolder ? 'none' : 'block';
        });

        secondaryHolderLabels.forEach(label => {
            label.style.display = hasSecondaryHolder ? 'block' : 'none';
        });
    }

    buildGroups() {
        const groups = {};
        this.form.querySelectorAll(`[data-step="${this.step}"] .form-radio-group`).forEach(container => {
            const radios = container.querySelectorAll('input[type="radio"]');
            if (radios.length > 0) {
                const name = radios[0].getAttribute('name');
                if (name) {
                    groups[name] = `[name="${name}"]`;
                }
            }
        });
        return groups;
    }

    buildValidationRules() {
        const rules = {};
        const messages = {};

        // Construir reglas para todos los pasos
        for (let currentStep = 1; currentStep <= this.steps; currentStep++) {
            const requiredContainers = this.form.querySelectorAll(
                `.form-distinguisher_columns-form [data-step="${currentStep}"] .form-list__field.required`
            );

            requiredContainers.forEach(container => {
                const inputs = container.querySelectorAll('input, select');

                inputs.forEach(field => {
                    const name = field.getAttribute('name');
                    if (!name || rules[name]) return;

                    rules[name] = {
                        required: true
                    };

                    // Reglas especiales para KidsAmount
                    if (name === 'KidsAmount') {
                        rules[name] = {
                            required: {
                                depends: function (element) {
                                    const hasKidsField = document.querySelector('input[name="HasKids"]');
                                    return hasKidsField && hasKidsField.checked;
                                }
                            }
                        };
                    } else {
                        rules[name] = {
                            required: true
                        };
                    }

                    if (field.hasAttribute('data-min')) {
                        rules[name].min = parseInt(field.getAttribute('data-min'));
                    }
                    if (field.hasAttribute('data-max')) {
                        rules[name].max = parseInt(field.getAttribute('data-max'));
                    }
                    if (field.getAttribute('inputmode') === 'numeric') {
                        rules[name].number = true;
                    }

                    const errorContainer = container.querySelector('.error-message');
                    const defaultErrorMsg = errorContainer?.textContent || 'Este campo es obligatorio';

                    messages[name] = {
                        required: defaultErrorMsg,
                        min: field.getAttribute('data-rangemessage') || `El valor debe ser mayor que ${rules[name].min}`,
                        max: field.getAttribute('data-rangemessage') || `El valor debe ser menor que ${rules[name].max}`,
                        number: 'Debe ser un número válido'
                    };

                    console.log(`Added validation for ${name}:`, rules[name], messages[name]);
                });
            });
        }

        return { rules, messages };
    }

    validateStep(stepNumber) {
        const stepContainer = this.form.querySelector(`.form-distinguisher_columns-form [data-step="${stepNumber}"]`);
        if (!stepContainer) return true;

        console.log(`Validating step ${stepNumber}`);
        let isStepValid = true;
        const validator = $(this.form).validate();

        const requiredContainers = stepContainer.querySelectorAll('.form-list__field.required');
        console.log(`Found ${requiredContainers.length} required containers`);

        requiredContainers.forEach(container => {
            // Para radio groups
            const radioGroup = container.querySelector('.form-radio-group');
            if (radioGroup) {
                const radios = radioGroup.querySelectorAll('input[type="radio"]');
                if (radios.length > 0) {
                    if (!validator.element(radios[0])) { // Validar el primer radio del grupo
                        isStepValid = false;
                        radioGroup.classList.add('error');
                    } else {
                        radioGroup.classList.remove('error');
                    }
                }
            }

            // Para inputs normales
            const normalInputs = container.querySelectorAll('input:not([type="radio"]):not([type="hidden"])');
            normalInputs.forEach(input => {
                if (!validator.element(input)) {
                    isStepValid = false;
                    const errorWrapper = input.closest('.form-input');
                    if (errorWrapper) {
                        errorWrapper.classList.add('error');
                    }
                } else {
                    const errorWrapper = input.closest('.form-input');
                    if (errorWrapper) {
                        errorWrapper.classList.remove('error');
                    }
                }
            });

            // Para access select
            const accessSelects = container.querySelectorAll('div.access-select input[type="hidden"]');
            accessSelects.forEach(input => {
                if (!input.value) {
                    isStepValid = false;
                    const errorWrapper = input.closest('.form-select');
                    if (errorWrapper) {
                        errorWrapper.classList.add('error');
                    }
                } else {
                    const errorWrapper = input.closest('.form-select');
                    if (errorWrapper) {
                        errorWrapper.classList.remove('error');
                    }
                }
            });
        });

        // Si es la primera validación del paso, añadimos los listeners
        if (!this.validatedSteps.has(stepNumber) && !isStepValid) {
            this.validatedSteps.add(stepNumber);
            this.initFieldValidation(stepContainer);
        }

        console.log(`Step ${stepNumber} validation result:`, isStepValid);
        return isStepValid;
    }

    validateField(field) {
        const value = field.value.trim();
        const errorWrapper = field.closest('.form-input') || field.closest('.form-select');
        let isValid = true;

        // Validar valor requerido
        if (!value) {
            isValid = false;
        }
        // Validar rangos si existen
        else if (field.hasAttribute('data-min') || field.hasAttribute('data-max')) {
            const numValue = parseFloat(value);
            const min = field.hasAttribute('data-min') ? parseFloat(field.getAttribute('data-min')) : null;
            const max = field.hasAttribute('data-max') ? parseFloat(field.getAttribute('data-max')) : null;

            if (min !== null && numValue < min) {
                isValid = false;
                console.log(`Value ${numValue} is less than minimum ${min}`);
            }
            if (max !== null && numValue > max) {
                isValid = false;
                console.log(`Value ${numValue} is greater than maximum ${max}`);
            }
        }

        if (errorWrapper) {
            errorWrapper.classList.toggle('error', !isValid);
        }
        return isValid;
    }

    initFieldValidation(stepContainer) {
        // Validación en tiempo real para inputs y selects
        stepContainer.querySelectorAll('input:not([type="radio"]), select').forEach(field => {
            field.addEventListener('change', () => this.validateField(field));
            field.addEventListener('input', () => this.validateField(field));
        });

        // Validación en tiempo real para radio groups
        stepContainer.querySelectorAll('.form-radio-group').forEach(radioGroup => {
            const radios = radioGroup.querySelectorAll('input[type="radio"]');
            radios.forEach(radio => {
                radio.addEventListener('change', () => {
                    if (radio.checked) {
                        radioGroup.classList.remove('error');
                    }
                });
            });
        });
    }

    validateAllSteps() {
        for (let i = 1; i <= this.steps; i++) {
            if (!this.validateStep(i)) {
                this.setStep(i); // Mostrar el paso que tiene errores
                return false;
            }
        }
        return true;
    }

    validateAndProceed() {
        console.log(`Attempting to proceed from step ${this.step}`);
        if (this.validateStep(this.step)) {
            console.log('Step validation passed');
            if (this.step < this.steps) {
                console.log('Moving to next step');
                this.setStep(this.step + 1);
            } else {
                // Si estamos en el último paso, validar todo antes de enviar
                console.log('Last step, validating before submit');
                if (this.validateStep(this.step)) {
                    console.log('Final validation passed, submitting form');
                    this.form.submit();
                } else {
                    console.log('Final validation failed');
                }
            }
        } else {
            console.log('Step validation failed');
        }
    }

    setStep(step) {
        this.step = step;
        this.form.querySelectorAll('[data-step]').forEach(el => {
            el.style.display = el.getAttribute('data-step') === String(this.step) ? 'block' : 'none';
        });

        // Limpiar errores al cambiar de paso
        const oldStepContainers = this.form.querySelectorAll('.form-input.error, .form-radio-group.error');
        oldStepContainers.forEach(container => {
            container.classList.remove('error');
        });
    }
}
