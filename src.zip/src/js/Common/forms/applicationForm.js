import IMask from 'imask';

import getClosestElement from '../../Helpers/getClosestElement';
import { fadeOut, fadeIn } from '../../Helpers/fade';
import scrollTo from '../../Helpers/scrollTo';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import regexTest from '../regexTest';
import selectTest from '../selectTest';
import radioTest from '../radioTest';
import checkboxTest from '../checkboxTest';
import regexValidate from '../regexValidate';
import selectValidate from '../selectValidate';
import radioValidate from '../radioValidate';
import checkboxValidate from '../checkboxValidate';
import { assignmentRequired, assignmentRequiredRegex, isFieldRequired, assignmentNumberRequired, assignmentAllowOnlyLetters } from '../formsFunctions';
import constants from './_constants';
import NumberValidate from '../NumberValidate';
import dniValidate from '../dniValidate';
import googleIdUtmContent from '../../Forms/sitecore-forms/fields/googleIdUtmContent';

const applicationForms = applicationForm => {
  // Numbers' masks
  const prefixMaskOptions = { mask: '{+}000', };
  const phoneNumberMaskOptions = { mask: '000 000 000 000', };
  googleIdUtmContent(applicationForm);

  // Common variables
  const scrollToPosition = 0;
  const fadeDuration = 500; // It is a static value. A real duration is defined in fade.js
  const scrollToErrorDuration = 500;
  const scrollToErrorOffset = 25;
  const errorClassname = 'error';

  // Common regex

  // Functions
  const getFieldset = input => getClosestElement(input, '.form-fieldset');
  const getSelectFieldset = input => (input ? input.querySelector('.form-select') : null);
  const getField = element => getClosestElement(element, '.form-list__field');

  // Variables
  const step1 = applicationForm.querySelector('.application-form__step-1');
  const step2 = applicationForm.querySelector('.application-form__step-2');
  const step1Text = applicationForm.querySelector('.application-form__text_step-1');
  const step2Text = applicationForm.querySelector('.application-form__text_step-2');
  const applicationFormContinueBtn = applicationForm ? applicationForm.querySelector('.form-btn__continue .btn') : null;
  const backBtn = applicationForm ? document.querySelector('.ancho-completo-header__back .link') : null;
  const backBtnForm = applicationForm ? applicationForm.querySelector('.btn_secondary') : null;
  const stepsHeaderStepsList = document.querySelector('.steps-header__steps-list');
  const stepsHeaderStep1 = document.getElementsByClassName('steps-header__steps-item')[0];
  const stepsHeaderStep2 = document.getElementsByClassName('steps-header__steps-item')[1];
  const stepsHeaderStep1Text = stepsHeaderStep1 ? stepsHeaderStep1.querySelector('.steps-header__steps-step') : null;
  const stepsHeaderStep2Text = stepsHeaderStep2 ? stepsHeaderStep2.querySelector('.steps-header__steps-step') : null;
  const stepsHeaderStep1InitialText = stepsHeaderStep1Text ? stepsHeaderStep1Text.innerHTML : null;
  const stepsHeaderStep2InitialText = stepsHeaderStep2Text ? stepsHeaderStep2Text.innerHTML : null;
  const stepsHeaderStep1VisibleText = stepsHeaderStep1Text ? stepsHeaderStep1Text.querySelector('.always-visible').innerHTML : null;
  const stepsHeaderStep2VisibleText = stepsHeaderStep2Text ? stepsHeaderStep2Text.querySelector('.always-visible').innerHTML : null;

  // BackButton
  if (backBtn) {
    backBtn.style.opacity = 0;
  }

  // DNI
  const dniInput = applicationForm.querySelector('.input-distinguisher_dni');
  const dniFieldset = getFieldset(dniInput);
  const isDniRequired = isFieldRequired(dniInput);

  dniInput?.addEventListener('blur', () => {
    dniValidate(dniInput, dniFieldset, isDniRequired, true);
  });

  // Name
  const nameInput = applicationForm.querySelector('.input-distinguisher_name');
  const nameFieldset = getFieldset(nameInput);
  const isNameRequired = isFieldRequired(nameInput);

  if (nameInput) assignmentRequiredRegex(isNameRequired, nameInput, constants.nameRegex, nameFieldset);
  if (nameInput) assignmentAllowOnlyLetters(nameInput);

  // Surname
  const surnameInput = applicationForm.querySelector('.input-distinguisher_surname');
  const surnameFieldset = getFieldset(surnameInput);
  const isSurnameRequired = isFieldRequired(surnameInput);

  if (surnameInput) assignmentRequiredRegex(isSurnameRequired, surnameInput, constants.nameRegex, surnameFieldset);
  if (surnameInput) assignmentAllowOnlyLetters(surnameInput);

  // Prefix
  const prefixInput = applicationForm.querySelector('.input-distinguisher_prefix');
  const prefixFieldset = getFieldset(prefixInput);
  const isPrefixRequired = isFieldRequired(prefixInput);
  const prefixMinLength = prefixInput ? prefixInput.getAttribute('minlength') : null;
  const prefixRegex = prefixInput ? new RegExp(`^[+0-9]{${prefixMinLength},}$`) : null;

  // Mask Prefix
  if (prefixInput) {
    IMask(prefixInput, prefixMaskOptions);
    assignmentRequiredRegex(isPrefixRequired, prefixInput, prefixRegex, prefixFieldset);
  }

  // Prefix (select)
  const prefix = applicationForm.querySelector('.form-select-distinguisher_prefix');
  const prefixChosenOption = prefix ? prefix.querySelector('.access-select__chosen-option') : null;
  const prefixSelectInput = prefix ? prefix.getElementsByClassName('access-select__input') : null;
  const isPrefixSelectRequired = isFieldRequired(prefix);
  if (prefix) assignmentRequired(isPrefixSelectRequired, prefix, prefixSelectInput, 'select');

  // Phone number
  const phoneNumberInput = applicationForm.querySelector('.input-distinguisher_phone-number');
  const phoneNumberFieldset = getFieldset(phoneNumberInput);
  const isPhoneNumberRequired = isFieldRequired(phoneNumberInput);
  const phoneNumberMinLength = phoneNumberInput ? phoneNumberInput.getAttribute('minlength') : null;
  const phoneNumberRegex = phoneNumberInput ? new RegExp(`^[0-9 ]{${phoneNumberMinLength},}$`) : null;

  // Mask Phone
  if (phoneNumberInput) {
    IMask(phoneNumberInput, phoneNumberMaskOptions);
    assignmentRequiredRegex(isPhoneNumberRequired, phoneNumberInput, phoneNumberRegex, phoneNumberFieldset);
  }
  // Email
  const emailInput = applicationForm.querySelector('.input-distinguisher_email');
  const emailFieldset = getFieldset(emailInput);
  const isEmailRequired = isFieldRequired(emailInput);

  if (emailInput) assignmentRequiredRegex(isEmailRequired, emailInput, constants.emailRegex, emailFieldset);

  // Contact type
  const contactType = applicationForm.querySelector('.form-radio-group-distinguisher_contact-type');
  const contactTypeRadio = contactType ? contactType.getElementsByClassName('radio') : null;
  const contactTypeField = getField(contactType);
  const isContactTypeRequired = isFieldRequired(null, contactTypeField);

  if (contactType) assignmentRequired(isContactTypeRequired, contactType, contactTypeRadio, 'radio');

  // Call time
  const callTime = applicationForm.querySelector('.form-select-distinguisher_call-time');
  const callTimeChosenOption = callTime ? callTime.querySelector('.access-select__chosen-option') : null;
  const callTimeSelectInput = callTime ? callTime.getElementsByClassName('access-select__input') : null;
  const isCallTimeRequired = isFieldRequired(callTime);

  if (callTime) assignmentRequired(isCallTimeRequired, callTime, callTimeSelectInput, 'select');

  // More info Text Area Contact Form
  const moreInfoTextarea = applicationForm.querySelector('.input-distinguisher_more-info-textarea');
  const moreInfoTextareaFieldset = getFieldset(moreInfoTextarea);
  const isMoreInfoTextareaRequired = isFieldRequired(moreInfoTextarea);
  const moreInfoTextareaMinLength = moreInfoTextarea ? moreInfoTextarea.getAttribute('minlength') : null;
  const moreInfoTextareaMaxLength = moreInfoTextarea ? moreInfoTextarea.getAttribute('maxlength') : null;
  const moreInfoTextareaRegex = moreInfoTextarea ? new RegExp(`^[\\S\\s]{${moreInfoTextareaMinLength},${moreInfoTextareaMaxLength}}$`) : null;

  // On blur
  if (moreInfoTextarea) assignmentRequiredRegex(isMoreInfoTextareaRequired, moreInfoTextarea, moreInfoTextareaRegex, moreInfoTextareaFieldset);


  // contactThroughPhone - Contact Call CallMeback
  const contactThroughPhone = contactType ? contactType.querySelector('.radio-distinguisher_contact-through-phone') : null;
  const isContactThroughPhoneChecked = () => {
    if (contactThroughPhone && contactThroughPhone.checked) {
      return selectTest(callTimeChosenOption);
    }
    return true;
  };

  const contactThroughEmail = applicationForm.querySelector('.radio-distinguisher_contact-through-email');
  const callTimeSelectField = applicationForm.querySelector('.form-list__field_call-time');
  const contactThroughCallMeNow = applicationForm.querySelector('.radio-distinguisher_contact-through-callme');

  if (contactThroughEmail && contactThroughPhone) {
    contactThroughEmail.addEventListener('click', () => {
      if (!contactThroughPhone.checked) {
        callTimeSelectField.style.display = '';
      }
    });

    contactThroughPhone.addEventListener('click', () => {
      if (contactThroughPhone.checked) {
        callTimeSelectField.style.display = 'block';
      }
    });
    if (contactThroughCallMeNow) {
      contactThroughCallMeNow.addEventListener('click', () => {
        if (!contactThroughPhone.checked) {
          callTimeSelectField.style.display = '';
        }
      });
    }
  }


  // Legal checkboxes
  const contactCheckLegal = applicationForm.querySelector('#checkLegal');
  const checkLegal = contactCheckLegal ? contactCheckLegal.getElementsByClassName('checkbox') : null;
  const checkLegalField = contactCheckLegal ? getClosestElement(contactCheckLegal, '.form-list__field') : null;
  const isCheckRequired = contactCheckLegal ? checkLegalField.classList.contains('required') : null;

  if (contactCheckLegal) {
    // On blur
    if (isCheckRequired) {
      for (let i = 0; i < checkLegal.length; i++) {
        checkLegal[i].addEventListener('blur', () => {
          if (contactCheckLegal.classList.contains('error')) {
            checkboxValidate(checkLegal, contactCheckLegal);
          }
        });
      }
    }
  }
  // Holders
  const holders = applicationForm.querySelector('#holders');
  const holdersRadio = holders ? holders.getElementsByClassName('radio-input') : null;
  const holdersField = holders ? getClosestElement(holders, '.form-list__field') : null;
  const isHoldersRequired = holders ? holdersField.classList.contains('required') : null;

  if (holders) assignmentRequired(isHoldersRequired, holders, holdersRadio, 'radio');

  //Main Age
  var MainAge = applicationForm ? applicationForm.querySelector('#ageRangeInput') : null;
  var parentMainAge = getClosestElement(MainAge, '.form-input');
  var MainAgeInputItem = getClosestElement(MainAge, '.form-list__item');
  var spanErrorMessageMainAge = parentMainAge ? parentMainAge.querySelector(".error-message") : null;
  const isMainAgeRequired = MainAge && parentMainAge ? isFieldRequired(MainAge) : false;

  // Main Age Validations
  var mainAgeMin = MainAge ? MainAge.getAttribute('data-min') : null;
  var mainAgeMax = MainAge ? MainAge.getAttribute('data-max') : null;
  var mainAgeRequiredMessage =  MainAge ? MainAge.getAttribute('data-reqMessage') : "";
  var mainAgeRangeMessage =  MainAge ? MainAge.getAttribute('data-rangeMessage') : "";

  if (MainAge && parentMainAge) assignmentNumberRequired(isMainAgeRequired, mainAgeMin, mainAgeMax, MainAge, parentMainAge, spanErrorMessageMainAge, mainAgeRequiredMessage, mainAgeRangeMessage, MainAgeInputItem);

  //MainHolderInput
  var MainHolderInput = applicationForm ? applicationForm.querySelector('#netRangeInput') : null;
  var parentMainHolderInput = getClosestElement(MainHolderInput, '.form-input');
  var MainHolderInputItem = getClosestElement(MainHolderInput, '.form-list__item');
  var spanErrorMessageMainHolderInput = parentMainHolderInput ? parentMainHolderInput.querySelector(".error-message") : null;
  const isMainHolderInputRequired = MainHolderInput && parentMainHolderInput ? isFieldRequired(MainHolderInput) : false;

  // Main Holder Validations
  var MainHolderInputMin = MainHolderInput ?  MainHolderInput.getAttribute('data-min') : null;
  var MainHolderInputMax = MainHolderInput ? MainHolderInput.getAttribute('data-max') : null;
  var MainHolderInputRequiredMessage = MainHolderInput ? MainHolderInput.getAttribute('data-reqMessage'): "";
  var MainHolderInputRangeMessage = MainHolderInput ? MainHolderInput.getAttribute('data-rangeMessage'): "";

  if (MainHolderInput && parentMainHolderInput) assignmentNumberRequired(isMainHolderInputRequired, MainHolderInputMin, MainHolderInputMax, MainHolderInput, parentMainHolderInput, spanErrorMessageMainHolderInput, MainHolderInputRequiredMessage, MainHolderInputRangeMessage, MainHolderInputItem);

  //Main holder payments
  var PaymentsMainHolder = applicationForm ? applicationForm.querySelector('#paymentsNumberRangeInput') : null;
  var parentPaymentsMainHolder = getClosestElement(PaymentsMainHolder, '.form-input');
  var PaymentsMainHolderItem = getClosestElement(PaymentsMainHolder, '.form-list__item');
  var spanErrorMessagePaymentsMainHolder = PaymentsMainHolder ? parentPaymentsMainHolder.querySelector(".error-message") : null;
  const isPaymentsMainHolderRequired = PaymentsMainHolder && parentPaymentsMainHolder ? isFieldRequired(PaymentsMainHolder) : false;


  var PaymentsMainHolderMin = PaymentsMainHolder ? PaymentsMainHolder.getAttribute('data-min') : null;
  var PaymentsMainHolderMax = PaymentsMainHolder ? PaymentsMainHolder.getAttribute('data-max') : null;
  var PaymentsMainHolderRequiredMessage = PaymentsMainHolder ? PaymentsMainHolder.getAttribute('data-reqMessage') : "";
  var PaymentsMainHolderRangeMessage = PaymentsMainHolder ? PaymentsMainHolder.getAttribute('data-rangeMessage'): "";

  if (PaymentsMainHolder && parentPaymentsMainHolder) assignmentNumberRequired(isPaymentsMainHolderRequired, PaymentsMainHolderMin, PaymentsMainHolderMax, PaymentsMainHolder, parentPaymentsMainHolder, spanErrorMessagePaymentsMainHolder, PaymentsMainHolderRequiredMessage, PaymentsMainHolderRangeMessage, PaymentsMainHolderItem);


  //Main holder payments
  var PaymentsSecondaryHolder = applicationForm ? applicationForm.querySelector('#secondHolderPaymentsNumberRangeInput') : null;
  var parentPaymentsSecondaryHolder = getClosestElement(PaymentsSecondaryHolder, '.form-input');
  var PaymentsSecondaryHolderItem = getClosestElement(PaymentsSecondaryHolder, '.form-list__item');
  var spanErrorMessagePaymentsSecondaryHolder = PaymentsSecondaryHolder ? parentPaymentsSecondaryHolder.querySelector(".error-message") : null;
  const isPaymentsSecondaryHolderRequired = PaymentsSecondaryHolder && parentPaymentsSecondaryHolder ? isFieldRequired(PaymentsSecondaryHolder) : false;


  var PaymentsSecondaryHolderMin = PaymentsSecondaryHolder ? PaymentsSecondaryHolder.getAttribute('data-min'): null;
  var PaymentsSecondaryHolderMax = PaymentsSecondaryHolder ? PaymentsSecondaryHolder.getAttribute('data-max'): null;
  var PaymentsSecondaryHolderRequiredMessage = PaymentsSecondaryHolder ? PaymentsSecondaryHolder.getAttribute('data-reqMessage'): "";
  var PaymentsSecondaryHolderRangeMessage = PaymentsSecondaryHolder ? PaymentsSecondaryHolder.getAttribute('data-rangeMessage'): "";

  if (PaymentsSecondaryHolder && parentPaymentsSecondaryHolder) assignmentNumberRequired(isPaymentsSecondaryHolderRequired, PaymentsSecondaryHolderMin, PaymentsSecondaryHolderMax, PaymentsSecondaryHolder, parentPaymentsSecondaryHolder, spanErrorMessagePaymentsSecondaryHolder, PaymentsSecondaryHolderRequiredMessage, PaymentsSecondaryHolderRangeMessage, PaymentsSecondaryHolderItem);



  // secondary holder input
  var secondaryHolderInput = applicationForm ? applicationForm.querySelector('#secondHolderNetRangeInput') : null;
  var parentsecondaryHolderInput = getClosestElement(secondaryHolderInput, '.form-input');
  var secondaryHolderInputItem = getClosestElement(secondaryHolderInput, '.form-list__item');
  var spanErrorMessagesecondaryHolderInput = parentsecondaryHolderInput ? parentsecondaryHolderInput.querySelector(".error-message") : null;
  const issecondaryHolderInputRequired = secondaryHolderInput && parentsecondaryHolderInput ? isFieldRequired(secondaryHolderInput) : false;

  // Secondary holder Validations
  var secondaryHolderInputMin = secondaryHolderInput ? secondaryHolderInput.getAttribute('data-min'): null;
  var secondaryHolderInputMax = secondaryHolderInput ? secondaryHolderInput.getAttribute('data-max'): null;
  var secondaryHolderInputRequiredMessage = secondaryHolderInput ? secondaryHolderInput.getAttribute('data-reqMessage'): "";
  var secondaryHolderInputRangeMessage = secondaryHolderInput ? secondaryHolderInput.getAttribute('data-rangeMessage'): "";

  if (secondaryHolderInput && parentsecondaryHolderInput) assignmentNumberRequired(issecondaryHolderInputRequired, secondaryHolderInputMin, secondaryHolderInputMax, secondaryHolderInput, parentsecondaryHolderInput, spanErrorMessagesecondaryHolderInput, secondaryHolderInputRequiredMessage, secondaryHolderInputRangeMessage, secondaryHolderInputItem);

  // Employees
  const employees = applicationForm.querySelector('#employees');
  const employeesRadio = employees ? employees.getElementsByClassName('radio-input') : null;
  const employeesField = employees ? getClosestElement(employees, '.form-list__field') : null;
  const isEmployeesRequired = employees ? employeesField.classList.contains('required') : null;

  if (employees) assignmentRequired(isEmployeesRequired, employees, employeesRadio, 'radio');


  // Other loans
  const otherLoans = applicationForm.querySelector('#otherLoans');
  const otherLoansRadio = otherLoans ? otherLoans.getElementsByClassName('radio-input') : null;
  const otherLoansField = otherLoans ? getClosestElement(otherLoans, '.form-list__field') : null;
  const isOtherLoansRequired = otherLoans ? otherLoansField.classList.contains('required') : null;

  if (otherLoans) assignmentRequired(isOtherLoansRequired, otherLoans, otherLoansRadio, 'radio');


  // Other Loans Amount
  var OtherLoansAmountInput = applicationForm ? applicationForm.querySelector('#otherLoansRangeInput') : null;
  var parentOtherLoansAmountInput = getClosestElement(OtherLoansAmountInput, '.form-input');
  var OtherLoansAmountItem = getClosestElement(OtherLoansAmountInput, '.form-list__field');
  var spanErrorMessageOtherLoansAmountInput = parentOtherLoansAmountInput ? parentOtherLoansAmountInput.querySelector(".error-message") : null;
  const isOtherLoansAmountRequired = OtherLoansAmountInput && parentOtherLoansAmountInput ? isFieldRequired(OtherLoansAmountInput) : false;

  // Other Loans Amount Validations
  var OtherLoansAmountInputMin = OtherLoansAmountInput ? OtherLoansAmountInput.getAttribute('data-min'): null;
  var OtherLoansAmountInputMax = OtherLoansAmountInput ? OtherLoansAmountInput.getAttribute('data-max'): null;
  var OtherLoansAmountInputRequiredMessage = OtherLoansAmountInput ? OtherLoansAmountInput.getAttribute('data-reqMessage') : "";
  var OtherLoansAmountInputRangeMessage =  OtherLoansAmountInput ? OtherLoansAmountInput.getAttribute('data-rangeMessage'): "";

  if (OtherLoansAmountInput && parentOtherLoansAmountInput) assignmentNumberRequired(isOtherLoansAmountRequired, OtherLoansAmountInputMin, OtherLoansAmountInputMax, OtherLoansAmountInput, parentOtherLoansAmountInput, spanErrorMessageOtherLoansAmountInput, OtherLoansAmountInputRequiredMessage, OtherLoansAmountInputRangeMessage, OtherLoansAmountItem);


  // Property type
  const propertyType = applicationForm.querySelector('#propertyType');
  const propertyTypeRadio = propertyType ? propertyType.getElementsByClassName('radio-input') : null;
  const propertyTypeField = propertyType ? getClosestElement(propertyType, '.form-list__field') : null;
  const isPropertyTypeRequired = propertyType ? propertyTypeField.classList.contains('required') : null;

  if (propertyType) assignmentRequired(isPropertyTypeRequired, propertyType, propertyTypeRadio, 'radio');

  // Purpose
  const purpose = applicationForm.querySelector('#purpose');
  const purposeRadio = purpose ? purpose.getElementsByClassName('radio-input') : null;
  const purposeField = purpose ? getClosestElement(purpose, '.form-list__field') : null;
  const isPurposeRequired = purpose ? purposeField.classList.contains('required') : null;

  if (purpose) assignmentRequired(isPurposeRequired, purpose, purposeRadio, 'radio');



  // More info checkboxes
  const moreInfo = applicationForm.querySelector('#moreInfo');
  const moreInfoCheckbox = moreInfo ? moreInfo.getElementsByClassName('checkbox-input') : null;
  const moreInfoField = moreInfo ? getClosestElement(moreInfo, '.form-list__field') : null;
  const isMoreInfoRequired = moreInfo ? moreInfoField.classList.contains('required') : null;

  if (moreInfo) {
    // On blur
    if (isMoreInfoRequired) {
      for (let i = 0; i < moreInfoCheckbox.length; i++) {
        moreInfoCheckbox[i].addEventListener('blur', () => {
          if (moreInfo.classList.contains(errorClassname)) {
            checkboxValidate(moreInfoCheckbox, moreInfo);
          }
        });
      }
    }
  }

  // Job status
  const jobStatus = applicationForm.querySelector('#jobStatus');
  const isJobStatusRequired = jobStatus ? getClosestElement(jobStatus, '.form-list__field').classList.contains('required') : null;
  // const jobStatusChosenOption = jobStatus ? jobStatus.querySelector('.access-select__chosen-option') : null;
  const jobStatusSelectInput = jobStatus ? jobStatus.getElementsByClassName('access-select__input') : null;

  if (jobStatus) assignmentRequired(isJobStatusRequired, jobStatus, jobStatusSelectInput, 'select');

  //Valor Compra y capital propio
  var valorCompra = applicationForm ? applicationForm.querySelector('#MortgageHousePrice') : null;
  var parentValorCompra = getClosestElement(valorCompra, '.form-input');
  var valorCompraInputItem = getClosestElement(valorCompra, '.form-list__item');
  var spanErrorMessageValorCompra = parentValorCompra ? parentValorCompra.querySelector(".error-message") : null;
  const isValorCompraRequired = valorCompra && parentValorCompra ? isFieldRequired(valorCompra) : false;

  var capitalPropio = applicationForm ? applicationForm.querySelector('#MortgageSaving') : null;
  var parentCapitalPropio = getClosestElement(capitalPropio, '.form-input');
  var capitalPropioInputItem = getClosestElement(capitalPropio, '.form-list__item');
  var spanErrorMessageCapitalPropio = parentCapitalPropio ? parentCapitalPropio.querySelector(".error-message") : null;
  const iscapitalPropioRequired = capitalPropio && parentCapitalPropio ? isFieldRequired(capitalPropio) : false;

  // Valor Compra validations
  var valorCompraMin = valorCompra ? valorCompra.getAttribute('data-min'): null;
  var valorCompraMax = valorCompra ? valorCompra.getAttribute('data-max'): null;
  var requiredMessage =valorCompra ? valorCompra.getAttribute('data-reqMessage'): "";
  var rangeMessage = valorCompra ? valorCompra.getAttribute('data-rangeMessage'): "";

  //Capital propio validation

  var capitalPropioMin = capitalPropio ?  capitalPropio.getAttribute('data-min'): null;
  var capitalPropioMax = capitalPropio ? capitalPropio.getAttribute('data-max'): null;
  var capitalPropiorequiredMessage = capitalPropio ? capitalPropio.getAttribute('data-reqMessage'): "";
  var capitalPropiorangeMessage = capitalPropio ? capitalPropio.getAttribute('data-rangeMessage'): "";

  if (valorCompra && parentValorCompra) assignmentNumberRequired(isValorCompraRequired, valorCompraMin, valorCompraMax, valorCompra, parentValorCompra, spanErrorMessageValorCompra, requiredMessage, rangeMessage, valorCompraInputItem);
  if (capitalPropio && parentCapitalPropio) assignmentNumberRequired(iscapitalPropioRequired, capitalPropioMin, capitalPropioMax, capitalPropio, parentCapitalPropio, spanErrorMessageCapitalPropio, capitalPropiorequiredMessage, capitalPropiorangeMessage, capitalPropioInputItem);


  // MortgageAmount only for ucimortgages
  var MortgageAmount = applicationForm ? applicationForm.querySelector('#MortgageAmount') : null;
  var parentMortgageAmount = MortgageAmount ? getClosestElement(MortgageAmount, '.form-input') : null;
  var MortgageAmountInputItem = MortgageAmount ? getClosestElement(MortgageAmount, '.form-list__item') : null;
  var spanErrorMessageMortgageAmount = parentMortgageAmount ? parentMortgageAmount.querySelector(".error-message") : null;
  const isMortgageAmountRequired = MortgageAmount && parentMortgageAmount ? isFieldRequired(MortgageAmount) : false;

  var MortgageAmountMin = MortgageAmount ? MortgageAmount.getAttribute('data-min') : 0;
  var MortgageAmountMax = MortgageAmount ? MortgageAmount.getAttribute('data-max') : 0;
  var MortgageAmountrequiredMessage = MortgageAmount ? MortgageAmount.getAttribute('data-reqMessage') : 0;
  var MortgageAmountrangeMessage = MortgageAmount ? MortgageAmount.getAttribute('data-rangeMessage') : 0;

  if (MortgageAmount && parentMortgageAmount) assignmentNumberRequired(isMortgageAmountRequired, MortgageAmountMin, MortgageAmountMax, MortgageAmount, parentMortgageAmount, spanErrorMessageMortgageAmount, MortgageAmountrequiredMessage, MortgageAmountrangeMessage, MortgageAmountInputItem);


  // Other Loans
  const otherLoanYes = applicationForm.querySelector('#otherLoansYes');
  const otherLoanNo = applicationForm.querySelector('#otherLoansNo');
  const otherLoanRange = applicationForm.querySelector('#otherLoansRange');

  if (otherLoanNo && otherLoanYes) {
    otherLoanNo.addEventListener('click', () => {
      if (!otherLoanYes.checked) {
        otherLoanRange.style.display = '';
      }
    });



    otherLoanYes.addEventListener('click', () => {
      if (otherLoanYes.checked) {
        otherLoanRange.style.display = 'flex';
      }
    });
  }

  // Employes Yes
  const employeesYes = applicationForm.querySelector('#employeesYes');
  const employeesNo = applicationForm.querySelector('#employeesNo');
  const employeesNumber = applicationForm.querySelector('#employeesNumber');

  if (employeesNo && employeesYes) {
    employeesNo.addEventListener('click', () => {
      if (!employeesYes.checked) {
        employeesNumber.style.display = '';
      }
    });

    employeesYes.addEventListener('click', () => {
      if (employeesYes.checked) {
        employeesNumber.style.display = 'flex';
      }
    });
  }
  // Resident

  const resident = applicationForm.querySelector('.form-radio-group-distinguisher_resident');
  const residentRadio = resident ? resident.getElementsByClassName('radio-input') : null;
  const residentField = getField(resident);
  const isResidentRequired = isFieldRequired(null, residentField);

  if (resident) assignmentRequired(isResidentRequired, resident, residentRadio, 'radio');

  // Province
  const province = applicationForm.querySelector('.form-select-distinguisher_province');
  const provinceChosenOption = province ? province.querySelector('.access-select__chosen-option_hidden') : null;
  const provinceSelectInput = province ? province.getElementsByClassName('access-select__input') : null;
  const isProvinceRequired = isFieldRequired(province);
  if (province) assignmentRequired(isProvinceRequired, province, provinceSelectInput, 'select');

    // Añadir aqui el requirement de cuando quieres comprar
    const cuandocomprar = applicationForm.querySelector('.form-select-distinguisher_cuando');
  const cuandocomprarChosenOption = cuandocomprar ? cuandocomprar.querySelector('.access-select__chosen-option_hidden') : null;
  const cuandocomprarSelectInput = cuandocomprar ? cuandocomprar.getElementsByClassName('access-select__input') : null;
  const iscuandocomprarRequired = isFieldRequired(cuandocomprar);
  if (cuandocomprar) assignmentRequired(iscuandocomprarRequired, cuandocomprar, cuandocomprarSelectInput, 'select'); 

  // Other country
  const otherCountry = applicationForm.querySelector('.form-list__field-distinguisher_other-country');
  const otherCountryFieldset = getSelectFieldset(otherCountry);
  const otherCountryChosenOption = otherCountry ? otherCountry.querySelector('.access-select__chosen-option') : null;
  const otherCountrySelectInput = otherCountry ? otherCountry.getElementsByClassName('access-select__input') : null;
  const isOtherCountryRequired = isFieldRequired(null, otherCountry);

  if (otherCountry) assignmentRequired(isOtherCountryRequired, otherCountry, otherCountrySelectInput, 'select');

  // Country Ucimortgages
  const CountryUcimortgage = applicationForm.querySelector('.form-select-distinguisher_country');
  const CountryUcimortgageChosenOption = CountryUcimortgage ? CountryUcimortgage.querySelector('.access-select__chosen-option_hidden') : null;
  const CountryUcimortgageSelectInput = CountryUcimortgage ? CountryUcimortgage.getElementsByClassName('access-select__input') : null;
  const isCountryUcimortgageRequired = isFieldRequired(CountryUcimortgage);
  if (CountryUcimortgage) assignmentRequired(isCountryUcimortgageRequired, CountryUcimortgage, CountryUcimortgageSelectInput, 'select');

  // One Holder
  const oneHolderInput = applicationForm.querySelector('#oneHolder');
  const secondHolderItem = applicationForm.getElementsByClassName('form-list__item_second-holder');
  const defaultLabel = applicationForm.getElementsByClassName('form-list__tooltip-label_default');
  const twoHoldersLabel = applicationForm.getElementsByClassName('form-list__tooltip-label_option_2');

  // Resident
  const residentYesInput = resident ? resident.querySelector('.radio-distinguisher_resident-yes') : null;

  // TwoHolders
  const twoHoldersInput = applicationForm.querySelector('#twoHolders');
  const residentNoInput = resident ? resident.querySelector('.radio-distinguisher_resident-no') : null;

  const isCountrySelectNeeded = () => {
    if (residentNoInput && !twoHoldersInput.checked && residentNoInput.checked) {
      return selectTest(otherCountryChosenOption);
    }
    return true;
  };



  // Special conditions for Application form
  if (oneHolderInput && twoHoldersInput) {
    oneHolderInput.addEventListener('click', () => {
      if (!twoHoldersInput.checked) {
        if (residentNoInput && residentNoInput.checked) {
          otherCountry.style.display = 'block';
        }

        for (let i = 0; i < twoHoldersLabel.length; i++) {
          if (defaultLabel[i]) {
            defaultLabel[i].style.display = '';
          }

          twoHoldersLabel[i].style.display = '';
        }

        for (let i = 0; i < secondHolderItem.length; i++) {
          secondHolderItem[i].style.display = '';
        }
      }
    });

    twoHoldersInput.addEventListener('click', () => {
      if (twoHoldersInput.checked) {
        if (otherCountry) {
          otherCountry.style.display = '';
        }

        for (let i = 0; i < twoHoldersLabel.length; i++) {
          if (defaultLabel[i]) {
            defaultLabel[i].style.display = 'none';
          }

          twoHoldersLabel[i].style.display = 'flex';
        }

        for (let i = 0; i < secondHolderItem.length; i++) {
          secondHolderItem[i].style.display = 'block';
        }
      }
    });
  }


  // -----------------------------
  // VALIDATION METHODS
  // -----------------------------
  // Some methods required for validation

  if (residentYesInput && residentNoInput) {
    residentYesInput.addEventListener('click', () => {
      if (!residentNoInput.checked) {
        otherCountry.style.display = '';
        selectValidate(otherCountryChosenOption, otherCountryFieldset, 'error', 'valid', true);
      }
    });

    residentNoInput.addEventListener('click', () => {
      if (twoHoldersInput) {
        if (!twoHoldersInput.checked && residentNoInput.checked) {
          otherCountry.style.display = 'block';
        }
      }
    });
  }



  const ValidateValorCompraRequired = () => {
    if (valorCompra && parentValorCompra) {
      return NumberValidate(valorCompra, parentValorCompra, 'error', 'valid', isValorCompraRequired, valorCompraMin, valorCompraMax, spanErrorMessageValorCompra, requiredMessage, rangeMessage, valorCompraInputItem);
    }
    return true;
  }


  const ValidateCapitalPropioRequired = () => {
    if (capitalPropio && parentCapitalPropio) {
      return NumberValidate(capitalPropio, parentCapitalPropio, 'error', 'valid', iscapitalPropioRequired, capitalPropioMin, capitalPropioMax, spanErrorMessageCapitalPropio, capitalPropiorequiredMessage, capitalPropiorangeMessage, capitalPropioInputItem);
    }

    return true;
  }

  const ValidateMortgageAmountRequired = () => {
    if (MortgageAmount && parentMortgageAmount) {
      return NumberValidate(MortgageAmount, parentMortgageAmount, 'error', 'valid', isMortgageAmountRequired, MortgageAmountMin, MortgageAmountMax, spanErrorMessageMortgageAmount, MortgageAmountrequiredMessage, MortgageAmountrangeMessage, MortgageAmountInputItem);
    }
    return true;
  }

  const ValidateMainAge = () => {
    if (MainAge && parentMainAge) {
      return NumberValidate(MainAge, parentMainAge, 'error', 'valid', isMainAgeRequired, mainAgeMin, mainAgeMax, spanErrorMessageMainAge, mainAgeRequiredMessage, mainAgeRangeMessage, MainAgeInputItem);
    }

    return true;
  }


  const ValidateMainHolderInput = () => {
    if (MainHolderInput && parentMainHolderInput) {
      return NumberValidate(MainHolderInput, parentMainHolderInput, 'error', 'valid', isMainHolderInputRequired, MainHolderInputMin, MainHolderInputMax, spanErrorMessageMainHolderInput, MainHolderInputRequiredMessage, MainHolderInputRangeMessage, MainHolderInputItem);
    }

    return true;
  }


  const ValidateMainHolderPayment = () => {
    if (PaymentsMainHolder && parentPaymentsMainHolder) {
      return NumberValidate(PaymentsMainHolder, parentPaymentsMainHolder, 'error', 'valid', isPaymentsMainHolderRequired, PaymentsMainHolderMin, PaymentsMainHolderMax, spanErrorMessagePaymentsMainHolder, PaymentsMainHolderRequiredMessage, PaymentsMainHolderRangeMessage, PaymentsMainHolderItem);
    }

    return true;
  }

  const ValidateSecondaryHolderPayment = () => {
    if (PaymentsSecondaryHolder && parentPaymentsSecondaryHolder) {
      return NumberValidate(PaymentsSecondaryHolder, parentPaymentsSecondaryHolder, 'error', 'valid', isPaymentsSecondaryHolderRequired, PaymentsSecondaryHolderMin, PaymentsSecondaryHolderMax, spanErrorMessagePaymentsSecondaryHolder, PaymentsSecondaryHolderRequiredMessage, PaymentsSecondaryHolderRangeMessage, PaymentsSecondaryHolderItem);
    }
    return true;
  }

  const ValidateSecondaryHolderInput = () => {
    if (secondaryHolderInput && parentsecondaryHolderInput) {
      return NumberValidate(secondaryHolderInput, parentsecondaryHolderInput, 'error', 'valid', issecondaryHolderInputRequired, secondaryHolderInputMin, secondaryHolderInputMax, spanErrorMessagesecondaryHolderInput, secondaryHolderInputRequiredMessage, secondaryHolderInputRangeMessage, secondaryHolderInputItem);
    }

    return true;
  }

  const ValidateOtherLoansAmountInput = () => {
    if (OtherLoansAmountInput && parentOtherLoansAmountInput) {
      return NumberValidate(OtherLoansAmountInput, parentOtherLoansAmountInput, 'error', 'valid', isOtherLoansAmountRequired, OtherLoansAmountInputMin, OtherLoansAmountInputMax, spanErrorMessageOtherLoansAmountInput, OtherLoansAmountInputRequiredMessage, OtherLoansAmountInputRangeMessage, OtherLoansAmountItem);
    }

    return true;
  }

  // Application form, Step 1
  const validateStep1 = () => {
    if (
      isRequiredTestPass(isHoldersRequired, radioTest(holdersRadio)) &&
      isRequiredTestPass(isOtherLoansRequired, radioTest(otherLoansRadio)) &&
      isRequiredTestPass(
        isProvinceRequired,
        selectTest(provinceChosenOption)
      ) &&
      isRequiredTestPass(
        isCountryUcimortgageRequired,
        selectTest(CountryUcimortgageChosenOption)
      )
      &&
      isRequiredTestPass(
        isPropertyTypeRequired,
        radioTest(propertyTypeRadio)
      ) &&
      isRequiredTestPass(isPurposeRequired, radioTest(purposeRadio)) &&
      isRequiredTestPass(isResidentRequired, radioTest(residentRadio)) &&
      isRequiredTestPass(isOtherCountryRequired, isCountrySelectNeeded()) &&
      isRequiredTestPass(isMoreInfoRequired, checkboxTest(moreInfoCheckbox))
      && ValidateValorCompraRequired()
      && ValidateCapitalPropioRequired()
      && ValidateMortgageAmountRequired()
      && ValidateMainAge()
      && ValidateMainHolderInput()
      && ValidateMainHolderPayment()
      && ValidateSecondaryHolderPayment()
      && ValidateSecondaryHolderInput()
      && ValidateOtherLoansAmountInput()
    ) {
      return true;
    }

    return false;
  };

  const showValidationErrorsStep1 = () => {
    let flag = true;

    if (isHoldersRequired && !radioTest(holdersRadio)) {
      for (let i = 0; i < holdersRadio.length; i++) {
        radioValidate(holdersRadio[i], holders);
      }

      if (flag) {
        scrollTo(holdersField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateMainAge()) {
      if (flag) {
        scrollTo(MainAge, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateMainHolderInput()) {
      if (flag) {
        scrollTo(MainHolderInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateMainHolderPayment()) {
      if (flag) {
        scrollTo(PaymentsMainHolder, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateSecondaryHolderInput()) {
      if (flag) {
        scrollTo(secondaryHolderInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateSecondaryHolderPayment()) {
      if (flag) {
        scrollTo(PaymentsSecondaryHolder, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateOtherLoansAmountInput()) {
      if (flag) {
        scrollTo(OtherLoansAmountInput, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isOtherLoansRequired && !radioTest(otherLoansRadio)) {
      for (let i = 0; i < otherLoansRadio.length; i++) {
        radioValidate(otherLoansRadio[i], otherLoans);
      }

      if (flag) {
        scrollTo(otherLoansField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isProvinceRequired && !selectTest(provinceChosenOption)) {
      selectValidate(provinceChosenOption, province);

      if (flag) {
        scrollTo(province, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

  
    if (isCountryUcimortgageRequired && !selectTest(CountryUcimortgageChosenOption)) {
      selectValidate(CountryUcimortgageChosenOption, CountryUcimortgage);

      if (flag) {
        scrollTo(CountryUcimortgage, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isPropertyTypeRequired && !radioTest(propertyTypeRadio)) {
      for (let i = 0; i < propertyTypeRadio.length; i++) {
        radioValidate(propertyTypeRadio[i], propertyType);
      }

      if (flag) {
        scrollTo(
          propertyTypeField,
          scrollToErrorDuration,
          scrollToErrorOffset
        );
        flag = false;
      }
    }

    if (isPurposeRequired && !radioTest(purposeRadio)) {
      for (let i = 0; i < purposeRadio.length; i++) {
        radioValidate(purposeRadio[i], purpose);
      }

      if (flag) {
        scrollTo(purposeField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateValorCompraRequired()) {
      if (flag) {
        scrollTo(valorCompra, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateCapitalPropioRequired()) {
      if (flag) {
        scrollTo(capitalPropio, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (!ValidateMortgageAmountRequired()) {
      if (flag) {
        scrollTo(MortgageAmount, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isResidentRequired && !radioTest(residentRadio)) {
      for (let i = 0; i < residentRadio.length; i++) {
        radioValidate(residentRadio[i], resident);
      }

      if (flag) {
        scrollTo(residentField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isOtherCountryRequired && !isCountrySelectNeeded()) {
      selectValidate(otherCountryChosenOption, otherCountryFieldset);

      if (flag) {
        scrollTo(
          otherCountryFieldset,
          scrollToErrorDuration,
          scrollToErrorOffset
        );
        flag = false;
      }
    }

    if (isMoreInfoRequired && !checkboxTest(moreInfoCheckbox)) {
      checkboxValidate(moreInfoCheckbox, moreInfo);

      if (flag) {
        scrollTo(moreInfoField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }
  };


  function backForm() {
    fadeOut(step2, fadeIn, step1);
    if (step2Text) { fadeOut(step2Text, fadeIn, step1Text); }
    if(backBtn){
      backBtn.style.opacity = 0;
    }
    stepsHeaderStepsList.style.opacity = 0;

    setTimeout(() => {
      stepsHeaderStep2.classList.remove('active');
      stepsHeaderStep1.classList.add('active');
      stepsHeaderStep1Text.innerHTML = stepsHeaderStep1InitialText;
      stepsHeaderStep2Text.innerHTML = stepsHeaderStep2VisibleText;
      stepsHeaderStepsList.style.opacity = 1;
      window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
      //scrollTo(scrollToPosition, fadeDuration);
    }, fadeDuration);
  }

  if (applicationForm && backBtnForm) {
    backBtnForm.addEventListener('click', e => {
      e.preventDefault();
      backForm();
    });
  }

  if (applicationForm && backBtn) {
    backBtn.addEventListener('click', e => {
      e.preventDefault();
      backForm();
    });
  }

  // Application form, Step 2
  const validateStep2 = () => {
    if (
      (!dniInput || dniValidate(dniInput, dniFieldset, isDniRequired, false)) &&
      isRequiredTestPass(isNameRequired, regexTest(constants.nameRegex, nameInput)) &&
      isRequiredTestPass(
        isSurnameRequired,
        regexTest(constants.nameRegex, surnameInput)
      ) &&
      isRequiredTestPass(
        isPrefixRequired,
        regexTest(prefixRegex, prefixInput)
      ) &&
      isRequiredTestPass(
        isPrefixSelectRequired,
        selectTest(prefixChosenOption)
      ) &&
      isRequiredTestPass(
        isPhoneNumberRequired,
        regexTest(phoneNumberRegex, phoneNumberInput)
      ) &&
      isRequiredTestPass(
        isEmailRequired,
        regexTest(constants.emailRegex, emailInput)
      ) &&
      isRequiredTestPass(
        isContactTypeRequired,
        radioTest(contactTypeRadio)
      ) &&
      isRequiredTestPass(isCallTimeRequired, isContactThroughPhoneChecked())
      && isRequiredTestPass(isCheckRequired, checkboxTest(checkLegal))
    ) {
      return true;
    }


    return false;
  };

  const showValidationErrorsStep2 = () => {
    let inputToScroll = null;

    if (dniInput && !dniValidate(dniInput, dniFieldset, isDniRequired, true)) {
      regexValidate(constants.dniRegex, dniInput, dniFieldset);
      dniValidate(dniInput, dniFieldset);
      inputToScroll = inputToScroll || dniInput;
    }

    if (isNameRequired && !regexTest(constants.nameRegex, nameInput)) {
      regexValidate(constants.nameRegex, nameInput, nameFieldset);
      inputToScroll = inputToScroll || nameInput
    }

    if (isSurnameRequired && !regexTest(constants.nameRegex, surnameInput)) {
      regexValidate(constants.nameRegex, surnameInput, surnameFieldset);
      inputToScroll = inputToScroll || surnameInput
    }

    if (isPrefixRequired && !regexTest(prefixRegex, prefixInput)) {
      regexValidate(prefixRegex, prefixInput, prefixFieldset);
      inputToScroll = inputToScroll || prefixInput
    }

    if (isPrefixSelectRequired && !selectTest(prefixChosenOption)) {
      selectValidate(prefixChosenOption, prefix);
      inputToScroll = inputToScroll || prefix
    }

    if (isPhoneNumberRequired && !regexTest(phoneNumberRegex, phoneNumberInput)
    ) {
      regexValidate(phoneNumberRegex, phoneNumberInput, phoneNumberFieldset);
      inputToScroll = inputToScroll || phoneNumberInput
    }

    if (isEmailRequired && !regexTest(constants.emailRegex, emailInput)) {
      regexValidate(constants.emailRegex, emailInput, emailFieldset);
      inputToScroll = inputToScroll || emailInput
    }

    if (isContactTypeRequired && !radioTest(contactTypeRadio)) {
      for (let i = 0; i < contactTypeRadio.length; i++) {
        radioValidate(contactTypeRadio[i], contactType);
      }

      inputToScroll = inputToScroll || contactTypeField
    }

    if (isCallTimeRequired && !isContactThroughPhoneChecked()) {
      selectValidate(callTimeChosenOption, callTime);
      inputToScroll = inputToScroll || callTime
    }
    if (isCheckRequired && !checkboxTest(checkLegal)) {
      checkboxValidate(checkLegal, contactCheckLegal);
      inputToScroll = inputToScroll || checkLegal
    }

    inputToScroll && scrollTo(inputToScroll, scrollToErrorDuration, scrollToErrorOffset);
  };

  // Application form, Step 2
  const validateLite = () => {
    if (
      (!dniInput || dniValidate(dniInput, dniFieldset, isDniRequired, false)) &&
      isRequiredTestPass(isNameRequired, regexTest(constants.nameRegex, nameInput)) &&
      isRequiredTestPass(
        isSurnameRequired,
        regexTest(constants.nameRegex, surnameInput)
      ) &&
      isRequiredTestPass(
        isPrefixRequired,
        regexTest(prefixRegex, prefixInput)
      ) &&
      isRequiredTestPass(
        isPrefixSelectRequired,
        selectTest(prefixChosenOption)
      ) &&
      isRequiredTestPass(
        isPhoneNumberRequired,
        regexTest(phoneNumberRegex, phoneNumberInput)
      ) &&
      isRequiredTestPass(
        isEmailRequired,
        regexTest(constants.emailRegex, emailInput)
      )&& 
      isRequiredTestPass(
        iscuandocomprarRequired,
        selectTest(cuandocomprarChosenOption)
      )) {
      return true;
    }


    return false;
  };

  const showValidationErrorsLite = () => {
    let inputToScroll = null;

    if (dniInput && !dniValidate(dniInput, dniFieldset, isDniRequired, true)) {
      regexValidate(constants.dniRegex, dniInput, dniFieldset);
      dniValidate(dniInput, dniFieldset);
      inputToScroll = inputToScroll || dniInput;
    }

    if (isNameRequired && !regexTest(constants.nameRegex, nameInput)) {
      regexValidate(constants.nameRegex, nameInput, nameFieldset);
      inputToScroll = inputToScroll || nameInput
    }

    if (isSurnameRequired && !regexTest(constants.nameRegex, surnameInput)) {
      regexValidate(constants.nameRegex, surnameInput, surnameFieldset);
      inputToScroll = inputToScroll || surnameInput
    }

    if (isPrefixRequired && !regexTest(prefixRegex, prefixInput)) {
      regexValidate(prefixRegex, prefixInput, prefixFieldset);
      inputToScroll = inputToScroll || prefixInput
    }

    if (isPrefixSelectRequired && !selectTest(prefixChosenOption)) {
      selectValidate(prefixChosenOption, prefix);
      inputToScroll = inputToScroll || prefix
    }

    if (isPhoneNumberRequired && !regexTest(phoneNumberRegex, phoneNumberInput)
    ) {
      regexValidate(phoneNumberRegex, phoneNumberInput, phoneNumberFieldset);
      inputToScroll = inputToScroll || phoneNumberInput
    }

    if (isEmailRequired && !regexTest(constants.emailRegex, emailInput)) {
      regexValidate(constants.emailRegex, emailInput, emailFieldset);
      inputToScroll = inputToScroll || emailInput
    }
    if (iscuandocomprarRequired && !selectTest(cuandocomprarChosenOption)) {
      selectValidate(cuandocomprarChosenOption, cuandocomprar);
      inputToScroll = inputToScroll || cuandocomprarSelectInput
    }
   

    inputToScroll && scrollTo(inputToScroll, scrollToErrorDuration, scrollToErrorOffset);
  };

  if (stepsHeaderStep2Text) {
    stepsHeaderStep2Text.innerHTML = stepsHeaderStep2VisibleText;
  }


  if (applicationFormContinueBtn) {
    applicationFormContinueBtn.addEventListener('click', () => {
      if (validateStep1()) {
        fadeOut(step1, fadeIn, step2);

        if (step2Text) {
          fadeOut(step1Text, fadeIn, step2Text);
        }
        if (backBtn) backBtn.style.transition = 'opacity 1s';

        stepsHeaderStepsList.style.transition = 'opacity 1s';
        stepsHeaderStepsList.style.opacity = 0;

        setTimeout(() => {
          if (backBtn) {
            backBtn.style.opacity = 1;
          }
          stepsHeaderStep1.classList.remove('active');
          stepsHeaderStep2.classList.add('active');
          stepsHeaderStep1Text.innerHTML = stepsHeaderStep1VisibleText;
          stepsHeaderStep2Text.innerHTML = stepsHeaderStep2InitialText;
          stepsHeaderStepsList.style.opacity = 1;
          window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
          //scrollTo(scrollToPosition, fadeDuration);
        }, fadeDuration);
      } else {
        showValidationErrorsStep1();
      }
    });
  }

  applicationForm.addEventListener('submit', e => {
    if(applicationForm.classList.contains('application-form-lite__form'))
    {
      if (!validateLite()) {
        e.preventDefault();
        showValidationErrorsLite();
      }
    }
    else{
    if (!validateStep1()) {
      e.preventDefault();
      showValidationErrorsStep1();
    } else if (!validateStep2()) {
      e.preventDefault();
      showValidationErrorsStep2();
    }
  }
  });
};
export default applicationForms;
