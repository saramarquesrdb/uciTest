import IMask from 'imask';

import noUiSlider from 'nouislider';
import rangeSlider from '../rangeSlider';
import getClosestElement from '../../Helpers/getClosestElement';
import { fadeOut, fadeIn } from '../../Helpers/fade';
import scrollTo from '../../Helpers/scrollTo';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import regexTest from '../regexTest';
import selectTest from '../selectTest';
import radioTest from '../radioTest';
import checkboxTest from '../checkboxTest';
import regexValidate from '../regexValidate';
import selectValidate from '../selectValidate';
import radioValidate from '../radioValidate';
import checkboxValidate from '../checkboxValidate';

import { assignmentRequired, assignmentRequiredRegex, isFieldRequired } from '../formsFunctions';

const calculatorForms = calculatorForm => {
  // Functions
  const getFieldset = input => getClosestElement(input, '.form-fieldset');

  // Common variables
  const scrollToErrorDuration = 500;
  const scrollToErrorOffset = 25;
  const errorClassname = 'error';


  // Province
  const province = calculatorForm.querySelector('#where');
  const provinceChosenOption = province ? province.querySelector('.access-select__chosen-option') : null;
  const provinceSelectInput = province ? province.getElementsByClassName('access-select__input') : null;
  const isProvinceRequired = isFieldRequired(province);
  if (province) assignmentRequired(isProvinceRequired, province, provinceSelectInput, 'select');

  // MainHolderInput
  const MainHolderInput = calculatorForm.querySelector('#ingresosMes');
  const MainHolderInputFieldset = getFieldset(MainHolderInput);
  const isMainHolderRequired = isFieldRequired(MainHolderInput);


  let calculado = false;
  // if (calculado === true) {
  // document.getElementById('TINRangeSliderInput').focus();
  // }
  let maxDuracion = 0;
  let aportacion = 0;
  let financiamos = 0;
  const FinanciacionMod = 0;
  let importe = 0;
  let Extra = 0;

  function mostrarGastos() {
    calculatorForm.querySelector('#divGastos').style.display = 'block';
  }

  function mostrarFinanciacion() {
    calculatorForm.querySelector('#DivFinanciacion').style.display = 'block';
  }

  function ocultarGastos() {
    calculatorForm.querySelector('#divGastos').style.display = 'none';
  }

  function ocultarFinanciacion() {
    calculatorForm.querySelector('#DivFinanciacion').style.display = 'none';
  }

  function reformaSI() {
    calculatorForm.querySelector('#DivReformaSN').style.display = 'block';
  }
  function reformaNO() {
    calculatorForm.querySelector('#DivReformaSN').style.display = 'none';
    calculatorForm.querySelector('importeReforma').value = '0';
  }

  const validateMainHolderInput = () => {
    // Mandatory province and salary
    if (MainHolderInput.value === '0' || MainHolderInput.value === '' || (parseInt(MainHolderInput.value, 10) < 0 && parseInt(MainHolderInput.value, 10) > 400000)) {
      calculatorForm.querySelector('#ingresos-Mes').classList.add('error');
      console.log(`calculado validateMainHolderInput${calculado}`);
      if (calculado === true) {
        scrollTo(calculatorForm, scrollToErrorDuration, scrollToErrorOffset);
      }
      return false;
    }
    calculatorForm.querySelector('#ingresos-Mes').classList.remove('error');
    return true;
  };

  const validateProvince = () => {
    selectValidate(provinceChosenOption, province);
    if (isProvinceRequired && !selectTest(provinceChosenOption)) {
      console.log(`calculado validateProvince${calculado}`);
      if (calculado === true) {
        scrollTo(province, scrollToErrorDuration, scrollToErrorOffset);
      }
      return false;
    }

    return true;
  };

  const validateCalculator = () => validateMainHolderInput() && validateProvince();

  function calcular() {
    calculatorForm.querySelector('#DivSubmit').style.display = 'none';
    calculatorForm.querySelector('#DivResultados').style.display = 'block';
    const edad = calculatorForm.querySelector('#ageRangeInput').value;
    const ingresos = MainHolderInput - calculatorForm.querySelector('#gastosMes');
    const CargaIngresos = MainHolderInput.value / calculatorForm.querySelector('#gastosMes').value * 100;
    // var provincia = document.getElementById("provinceValue").innerHTML;
    // const provincia = document.getElementsByClassName('access-select__chosen-option_hidden valid')[0].value;


    let IjdValue = 0;
    let ItpValue = 0;

    switch (provinceChosenOption) {
      case 'ALAVA':
        IjdValue = 0;
        ItpValue = 4;
        break;
      case 'ALBACETE':
        IjdValue = 1.5;
        ItpValue = 9;
        break;
      case 'ALICANTE':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'ALMERIA':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'ASTURIAS':
        IjdValue = 1.2;
        ItpValue = 8;
        break;

      case 'AVILA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'BADAJOZ':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'BALEARES':
        IjdValue = 1.2;
        ItpValue = 8;
        break;
      case 'BARCELONA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'BURGOS':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'CACERES':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'CADIZ':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'CANTABRIA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'CASTELLON':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'CEUTA':
        IjdValue = 0.5;
        ItpValue = 6;
        break;
      case 'CIUDAD REAL':
        IjdValue = 1.5;
        ItpValue = 9;
        break;
      case 'CORDOBA':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'CUENCA':
        IjdValue = 1.5;
        ItpValue = 9;
        break;
      case 'GIRONA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'GRANADA':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'GUADALAJARA':
        IjdValue = 1.5;
        ItpValue = 9;
        break;
      case 'GUIPUZCOA':
        IjdValue = 0;
        ItpValue = 4;
        break;
      case 'HUELVA':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'HUESCA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'JAEN':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'LA CORUÑA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'LA RIOJA':
        IjdValue = 1;
        ItpValue = 7;
        break;
      case 'LAS PALMAS':
        IjdValue = 0.4;
        ItpValue = 6.5;
        break;
      case 'LEON':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'LERIDA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'LUGO':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'MADRID':
        IjdValue = 0.7;
        ItpValue = 6;
        break;
      case 'MALAGA':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'MELILLA':
        IjdValue = 0.5;
        ItpValue = 6;
        break;
      case 'MURCIA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'NAVARRA':
        IjdValue = 0.5;
        ItpValue = 6;
        break;
      case 'ORENSE':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'PALENCIA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'PONTEVEDRA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'SALAMANCA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'SEGOVIA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'SEVILLA':
        IjdValue = 1.2;
        ItpValue = 7;
        break;
      case 'SORIA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'TARRAGONA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'TENERIFE':
        IjdValue = 0.4;
        ItpValue = 6.5;
        break;
      case 'TERUEL':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'TOLEDO':
        IjdValue = 1.5;
        ItpValue = 9;
        break;
      case 'VALENCIA':
        IjdValue = 1.5;
        ItpValue = 10;
        break;
      case 'VALLADOLID':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'VIZCAYA':
        IjdValue = 0;
        ItpValue = 4;
        break;
      case 'ZAMORA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;
      case 'ZARAGOZA':
        IjdValue = 1.5;
        ItpValue = 8;
        break;

      default:
        IjdValue = 1.5;
        ItpValue = 9;
        break;
    }

    // var [Ijd] = ['ALAVA/0', 'ALBACETE/1.5', 'ALICANTE/1.5', 'ALMERIA/1.2', 'ASTURIAS/1.2', 'AVILA/1.5', 'BADAJOZ/1.5', 'BALEARES/1.2', 'BARCELONA/1.5', 'BURGOS/1.5', 'CACERES/1.5', 'CADIZ/1.2', 'CANTABRIA/1.5', 'CASTELLON/1.5', 'CEUTA/0.5', 'CIUDAD REAL/1.5', 'CORDOBA/1.2', 'CUENCA/1.5', 'GIRONA/1.5', 'GRANADA/1.2', 'GUADALAJARA/1.5', 'GUIPUZCOA/0', 'HUELVA/1.2', 'HUESCA/1.5', 'JAEN/1.2', 'LA CORUÑA/1.5', 'LA RIOJA/1', 'LAS PALMAS/0.4', 'LEON/1.5', 'LERIDA/1.5', 'LUGO/1.5', 'MADRID/0.7', 'MALAGA/1.2', 'MELILLA/0.5', 'MURCIA/1.5', 'NAVARRA/0.5', 'ORENSE/1.5', 'PALENCIA/1.5', 'PONTEVEDRA/1.5', 'SALAMANCA/1.5', 'SEGOVIA/1.5', 'SEVILLA/1.2', 'SORIA/1.5', 'TARRAGONA/1.5', 'TENERIFE/0.4', 'TERUEL/1.5', 'TOLEDO/1.5', 'VALENCIA/1.5', 'VALLADOLID/1.5', 'VIZCAYA/0', 'ZAMORA/1.5', 'ZARAGOZA/1.5'];


    // for (var n = 0; n < Ijd.length; n++) {
    //    if (Ijd[n].split("/")[0] === provincia) {
    //        IjdValue = Ijd[n].split("/")[1];
    //    }
    // }
    // var [Itp] = ['ALAVA/4', 'ALBACETE/9', 'ALICANTE/10', 'ALMERIA/7', 'ASTURIAS/8', 'AVILA/8', 'BADAJOZ/8', 'BALEARES/8', 'BARCELONA/10', 'BURGOS/8', 'CACERES/8', 'CADIZ/7', 'CANTABRIA/10', 'CASTELLON/10', 'CEUTA/6', 'CIUDAD REAL/9', 'CORDOBA/7', 'CUENCA/9', 'GIRONA/10', 'GRANADA/7', 'GUADALAJARA/9', 'GUIPUZCOA/4', 'HUELVA/7', 'HUESCA/8', 'JAEN/7', 'LA CORUÑA/10', 'LA RIOJA/7', 'LAS PALMAS/6.5', 'LEON/8', 'LERIDA/10', 'LUGO/10', 'MADRID/6', 'MALAGA/7', 'MELILLA/6', 'MURCIA/8', 'NAVARRA/6', 'ORENSE/10', 'PALENCIA/8', 'PONTEVEDRA/10', 'SALAMANCA/8', 'SEGOVIA/8', 'SEVILLA/7', 'SORIA/8', 'TARRAGONA/10', 'TENERIFE/6.5', 'TERUEL/8', 'TOLEDO/9', 'VALENCIA/10', 'VALLADOLID/8', 'VIZCAYA/4', 'ZAMORA/8', 'ZARAGOZA/8'];


    // for (var i = 0; i < Itp.length; i++) {
    //    if (Itp[i].split("/")[0] === provincia) {
    //        ItpValue = Itp[i].split("/")[1];
    //    }
    // }

    let impuesto = 0;
    let tipoImpuesto = '';
    if (document.getElementById('tipoViviendaNueva').checked === true) {
      impuesto = 10;
      if (provinceChosenOption === 'LAS PALMAS' || provinceChosenOption === 'TENERIFE') {
        impuesto = 6.5;
      }
      tipoImpuesto = 'IVA';
    }

    if (document.getElementById('tipoViviendaSegundaMano').checked === true) {
      impuesto = ItpValue;

      tipoImpuesto = 'ITP';
    }


    const valorIAJD = importe * IjdValue / 100;


    const prestamo = parseFloat(document.getElementById('MortgageHousePriceRangeInput').value.replace('.', ''));
    const reforma = parseFloat(document.getElementById('importeReforma').value.replace('.', ''));

    importe = prestamo + reforma;


    const duracion = Math.min((75 - parseInt(document.getElementById('ageRangeInput').value, 10)), parseInt(document.getElementById('MortgageHouseDurationRangeInput').value, 10)) * 12;

    if (Extra === 0) {
      financiamos = Math.min(parseFloat(importe * 90 / 100), 800000);

      document.getElementById('MortgageAmountRangeInput').max = financiamos;
    } else {
      // financiamos = Math.min(financiamos, parseFloat(document.getElementById('MortgageAmountRangeInput').value.replace('.', '')));


      financiamos -= Extra;
    }
    aportacion = importe - financiamos;

    document.getElementById('MortgageAmountRangeInput').value = parseInt(financiamos, 10).toLocaleString('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    // AÑADIR MÁXIMOS FINANCIACIÓN

    document.getElementById('MortgageAmountRangeInput').setAttribute('max', (financiamos).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementById('MortgageAmountRangeInput').setAttribute('max', (financiamos).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementById('MortgageAmountRangeInput').setAttribute('data-default', (financiamos + Extra).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementById('importeprestamo-end').innerText = (financiamos + Extra).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementsByClassName('noUi-handle')[3].setAttribute('aria-valuemax', (financiamos).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementsByClassName('noUi-handle')[3].setAttribute('aria-valuenow', (financiamos + Extra).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementsByClassName('noUi-handle')[3].setAttribute('aria-valuetext', (financiamos + Extra).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));

    // AÑADIR MÁXIMOS APORTACION
    let maxAportacion = 0;
    maxAportacion = parseInt(importe - 80000, 10);

    document.getElementById('MortgageHouseSavingsRangeInput').setAttribute('max', (maxAportacion).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementById('MortgageHouseSavingsRangeInput').setAttribute('data-default', (aportacion).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementById('importeprestamo-end').innerText = (aportacion).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementsByClassName('noUi-handle')[4].setAttribute('aria-valuemax', (maxAportacion).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementsByClassName('noUi-handle')[4].setAttribute('aria-valuenow', (aportacion).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));
    document.getElementsByClassName('noUi-handle')[4].setAttribute('aria-valuetext', (aportacion).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }));


    document.getElementById('MortgageHouseSavingsRangeInput').value = parseInt(aportacion, 10).toLocaleString('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

    let tasacion = 285 * 1.21;

    if (importe > 500000) {
      tasacion = (prestamo * 0.06 / 100) * 1.21;
    }
    const notaria = 1100;


    const registro = 530;
    const gestoria = 391;
    const impuestoPagar = importe * impuesto / 100;
    const gastos = tasacion + notaria + registro + gestoria + impuestoPagar;
    const comisionAperturaPorcentaje = 0;
    const comisionAperturaImporte = importe * (comisionAperturaPorcentaje / 100);


    document.getElementById('divNotaria').innerText = parseFloat(notaria).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divImporteTasacionGastosHipoteca').innerText = parseFloat(tasacion).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divImporteNotariaGastosHipoteca').innerText = parseFloat(notaria).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divImporteRegistroGastosHipoteca').innerText = parseFloat(registro).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divRegistro').innerText = parseFloat(registro).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divImporteGestoriaGastosHipoteca').innerText = parseFloat(gestoria).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divGestoria').innerText = parseFloat(gestoria).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divImpuestosGastosCompraventa').innerText = parseFloat(impuestoPagar).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('divTotalGastos').innerText = parseFloat(notaria + registro + gestoria + impuestoPagar).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('importeGastos').value = parseFloat(gastos + comisionAperturaImporte).toLocaleString('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    document.getElementById('divImporteComisionApertura').innerText = parseFloat(comisionAperturaImporte).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });

    document.getElementById('divImpuestosGastosCompraventa').innerText = parseFloat(gastos).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });

    document.getElementById('DivImportePrestamo').innerText = prestamo.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('DivImporteReforma').innerText = reforma.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    document.getElementById('DivTotalImporte').innerText = (prestamo + reforma).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });

    document.getElementById('DivTotalGastosHipoteca').innerText = parseFloat(tasacion + comisionAperturaImporte).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });


    document.getElementById('divImporteÌmpuestosGastosHipoteca').innerText = `${parseFloat(valorIAJD).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' })} (asumido por la entidad)`;

    document.getElementById('divTotalGastosImpuestos').innerText = parseFloat(notaria + registro + gestoria + impuestoPagar + tasacion + comisionAperturaImporte).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });


    document.getElementById('divImpuestosGastosCompraventa').innerText = parseFloat(impuestoPagar).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });

    const TIN = (parseFloat(document.getElementById('TINRangeSliderInput').value.replace(',', '.')) / 100) / 12;


    let tae = 0;
    const cuota = 0;
    let cuota2 = 0;


    // cuota2 = (importe * TIN) / (1 - Math.pow(((1 + TIN)), -duracion));
    cuota2 = (financiamos * TIN) / (1 - ((1 + TIN) ** (-duracion)));
    let cargaIngresos = 0;
    if (document.getElementById('gastosMes').value === '') {
      cargaIngresos = (parseInt(MainHolderInput.value.replace('.', ''), 10)) * 4 / 10;
    } else {
      cargaIngresos = (parseInt(MainHolderInput.value.replace('.', ''), 10) - parseInt(document.getElementById('gastosMes').value.replace('.', ''), 10)) * 4 / 10;
    }
    if (cuota2 > cargaIngresos) {
      document.getElementById('Capa-cuota').classList.add('alert');
      document.getElementById('features-alert').style.display = 'block';
    } else {
      document.getElementById('Capa-cuota').classList.remove('alert');
      document.getElementById('features-alert').style.display = 'none';
    }

    // cuota = importe * ((TIN * Math.pow(1 + TIN, duracion)) / (Math.pow(1 + TIN, duracion) - 1));


    document.getElementById('Cuota').innerText = parseFloat(cuota2).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });


    document.getElementById('sliderImportePrestamo').value = financiamos;
    document.getElementById('sliderImportePrestamo').setAttribute('max', financiamos);

    document.getElementById('sliderAportacion').value = aportacion;
    document.getElementById('sliderAportacion').setAttribute('min', aportacion);


    // tae = (Math.pow((1 + TIN), 12) - 1) * 100;

    tae = (((1 + TIN) ** 12) - 1) * 100;

    document.getElementById('tae').value = parseFloat(tae).toLocaleString('es-ES', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
    document.getElementById('tae').innerHTML = parseFloat(tae).toLocaleString('es-ES', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
  }

  function changeValueLegalText(collectioninputs, value) {
    collectioninputs.forEach(el => {
      el.innerHTML = value;
    });
  }

  function LegalText() {
    // values to use
    const tasacionString = parseFloat(285 * 1.21).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
    const tasacionNumber = parseFloat(285 * 1.21);

    const reforma = parseFloat(calculatorForm.querySelector('#importeReforma').value.replace('.', '')).toLocaleString();
    const tinValue = calculatorForm.querySelector('#TINRangeSliderInput').value;
    const taevalue = calculatorForm.querySelector('#tae').value;
    const housePriceNumber = parseFloat(calculatorForm.querySelector('#MortgageHousePriceRangeInput').value.replace('.', ''));
    const housePriceString = calculatorForm.querySelector('#MortgageHousePriceRangeInput').value;
    const comisionAperturaPorcentaje = 0;
    const comisionAperturaImporte = parseFloat(housePriceNumber * (comisionAperturaPorcentaje / 100));
    const MortgageDurationYears = calculatorForm.querySelector('#MortgageHouseDurationRangeInput').value;
    const MortgageDurationMonth = MortgageDurationYears * 12;
    const mortgageAmount = parseFloat(housePriceNumber) + parseFloat(reforma);
    const cuotaMensual = parseFloat(calculatorForm.querySelector('#Cuota').innerHTML.replace('&nbsp;', '').replace('€', '').replace(',', '.'));
    const importeAdeudadoNumber = (parseFloat((MortgageDurationMonth * cuotaMensual) + tasacionNumber + comisionAperturaImporte));
    const importeAdeudadoString = (parseFloat((MortgageDurationMonth * cuotaMensual) + tasacionNumber + comisionAperturaImporte)).toLocaleString();
    const importeGastos = (parseFloat(importeAdeudadoNumber - mortgageAmount)).toLocaleString();

    const interesesAdeudado = (parseFloat((MortgageDurationMonth * cuotaMensual) + comisionAperturaImporte) - mortgageAmount).toLocaleString();


    changeValueLegalText(calculatorForm.querySelectorAll('.legalTin'), tinValue);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalTae'), taevalue);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalImporte'), housePriceString);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalPlazo'), MortgageDurationYears);
    changeValueLegalText(calculatorForm.querySelectorAll('.campoCuotaEnd'), MortgageDurationMonth);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalComisionApertura'), comisionAperturaImporte);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalPorcientoComision'), comisionAperturaPorcentaje);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalCosteTasacion'), tasacionString);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalCuotaMensual'), cuotaMensual);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalImporteAdeudado'), importeAdeudadoString);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalImporteGastos'), importeGastos);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalInteresesAdeudado'), interesesAdeudado);
    changeValueLegalText(calculatorForm.querySelectorAll('.legalTasacion'), tasacionString);
  }


  function validarPuntos(evt) {
    evt.currentTarget.value = evt.currentTarget.value.replace(/\D/g, '').replace(/\B(?=(\d{3})+(?!\d)\.?)/g, '.');
  }

  function quitarCero(evt) {
    if (document.getElementById(evt.currentTarget.id).value === '0') {
      document.getElementById(evt.currentTarget.id).value = '';
    }
  }

  function CambiarEdad() {
    maxDuracion = 0;
    maxDuracion = Math.min((75 - parseInt(document.getElementById('ageRangeInput').value, 10)), parseInt(document.getElementById('MortgageHouseDurationRangeInput').value, 10));
    // range Slider
    const rangeageInput = document.getElementById('MortgageHouseDurationRangeInput');
    const rangeageSlider = document.getElementById('MortgageHouseDurationRangeSlider');


    rangeageInput.value = maxDuracion;
    rangeageInput.innerHTML = maxDuracion;
    rangeageInput.setAttribute('max', maxDuracion);
    rangeageInput.setAttribute('data-default', maxDuracion);

    document.getElementById('duracion-end').innerText = `${maxDuracion} años`;

    rangeageSlider.getElementsByClassName('noUi-handle noUi-handle-lower')[0].setAttribute('aria-valuemax', maxDuracion);
    rangeageSlider.getElementsByClassName('noUi-handle noUi-handle-lower')[0].setAttribute('aria-valuenow', maxDuracion);
    rangeageSlider.getElementsByClassName('noUi-handle noUi-handle-lower')[0].setAttribute('aria-valuetext', maxDuracion);

    rangeageSlider.dispatchEvent(new Event('update', { bubbles: true }));
    rangeageInput.dispatchEvent(new Event('change', { bubbles: true }));
  }


  function FullCalculator(e) {
    if (validateCalculator() && calculado === true) {
      e.preventDefault();
      calcular();
      scrollTo(document.getElementById('TINRangeSliderInput'), scrollToErrorDuration, scrollToErrorOffset);
      e.stopPropagation();
      LegalText();
    }
  }

  function validarEdadImporte(e) {
    if (parseInt(document.getElementById('sliderDuracion').value, 10) > parseInt(maxDuracion, 10)) {
      CambiarEdad();
    }
    FullCalculator(e);
  }

  function CambiarFinanciacion(e) {
    Extra = parseInt(document.getElementById('MortgageHouseSavingsRangeInput').value.replace('.', ''), 10) - aportacion;
    document.getElementById('MortgageAmountRangeInput').value = financiamos - Extra;
    FullCalculator(e);
  }

  function CambiarAportacion(e) {
    Extra = financiamos - parseInt(document.getElementById('MortgageAmountRangeInput').value.replace('.', ''), 10);
    document.getElementById('MortgageHouseSavingsRangeInput').value = aportacion + Extra;
    FullCalculator(e);
  }


  calculatorForm.querySelector('#bntCalcular').addEventListener('click', e => {
    calculado = true;
    FullCalculator(e);
  });


  // Eventos
  document.getElementById('reformaSi').addEventListener('click', reformaSI);
  document.getElementById('reformaNo').addEventListener('click', reformaNO);
  document.getElementById('LnkFinanciacion').addEventListener('click', mostrarFinanciacion);
  document.getElementById('LnkGastos').addEventListener('click', mostrarGastos);
  document.getElementById('CloseFinanciacion').addEventListener('click', ocultarFinanciacion);
  document.getElementById('CloseGastos').addEventListener('click', ocultarGastos);


  // campos de texto
  MainHolderInput.addEventListener('focus', quitarCero, true);
  MainHolderInput.addEventListener('keyup', validarPuntos, false);

  MainHolderInput.addEventListener('blur', e => {
    FullCalculator(e);
  });

  document.getElementById('importeReforma').addEventListener('blur', e => {
    FullCalculator(e);
  });


  // document.getElementById('gastosMes').addEventListener('blur', validar);

  document.getElementById('gastosMes').addEventListener('blur', e => {
    FullCalculator(e);
  });

  document.getElementById('gastosMes').addEventListener('blur', e => {
    FullCalculator(e);
  });

  document.getElementById('TINRangeSliderInput').addEventListener('blur', e => {
    FullCalculator(e);
  });


  document.getElementById('ageRangeInput').addEventListener('blur', e => {
    CambiarEdad();
    FullCalculator(e);
  });

  document.getElementById('MortgageHousePriceRangeInput').addEventListener('blur', e => {
    FullCalculator(e);
  });

  document.getElementById('MortgageHouseDurationRangeInput').addEventListener('blur', e => {
    FullCalculator(e);
  });

  document.getElementById('MortgageHouseSavingsRangeInput').addEventListener('blur', e => {
    CambiarFinanciacion(e);
  });

  document.getElementById('MortgageHouseSavingsRangeInput').addEventListener('blur', e => {
    CambiarAportacion(e);
  });


  document.getElementById('importeReforma').addEventListener('focus', quitarCero, true);
  document.getElementById('gastosMes').addEventListener('focus', quitarCero, true);
  // document.getElementById('TINRangeSliderInput').addEventListener('focus', quitarCero, true);


  document.getElementById('importeReforma').addEventListener('keyup', validarPuntos, false);
  document.getElementById('gastosMes').addEventListener('keyup', validarPuntos, false);
  // document.getElementById('TINRangeSliderInput').addEventListener('keyup', validarPuntos, false);


  // RANGE

  // document.getElementById('sliderPrice').addEventListener('mouseup', e => {
  // FullCalculator(e);
  // });


  document.getElementById('sliderDuracion').addEventListener('mouseup', e => {
    validarEdadImporte(e);
  });
  // document.getElementById('sliderImportePrestamo').addEventListener('mousemove', CambiarAportacion);

  document.getElementById('sliderAportacion').addEventListener('mouseup', e => {
    FullCalculator(e);
  });

  document.getElementById('sliderEdad').addEventListener('mouseup', CambiarEdad);
  // RADIOBUTTON
  document.getElementById('tipoViviendaNueva').addEventListener('change', e => {
    FullCalculator(e);
  });

  document.getElementById('tipoViviendaSegundaMano').addEventListener('change', e => {
    FullCalculator(e);
  });

  // SELECT
  // document.getElementsByClassName('access-select__chosen-option_hidden').addEventListener('change', validar);
};

export default calculatorForms;
