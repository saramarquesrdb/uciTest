export default {
    nameRegex : /^\s*([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]{1,}([.,] |[-']| )?)+[A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]+\.?\s*$/,
    emailRegex: /^[-a-z0-9~!$%^&*_=+}{'?]+(\.[-a-z0-9~!$%^&*_=+}{'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i,
    prefixMaskOptions: { mask: '{+}000' },
    phoneNumberMaskOptions: { mask: '000 000 000 000' },
}