import IMask from 'imask';
import getClosestElement from '../../Helpers/getClosestElement';
import scrollTo from '../../Helpers/scrollTo';
import isRequiredTestPass from '../../Helpers/isRequiredTestPass';
import selectTest from '../selectTest';
import radioTest from '../radioTest';
import selectValidate from '../selectValidate';
import radioValidate from '../radioValidate';
import formSubmitPreloader from '../formSubmitPreloader';
import checkboxValidate from '../checkboxValidate';
import checkboxTest from '../checkboxTest';
import regexTest from '../regexTest';
import regexValidate from '../regexValidate';
import { assignmentRequired, assignmentRequiredRegex, isFieldRequired } from '../formsFunctions';


const simulatorForms = simulatorForm => {
  // Common variables
  const scrollToErrorDuration = 500;
  const scrollToErrorOffset = 25;
  // const errorClassname = 'error';


  // Common regex
  const nameRegex = /^\s*([A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]{1,}([.,] |[-']| )?)+[A-Za-z\u00C0-\u00D6\u00D8-\u00f6\u00f8-\u00ff\u0100-\u017f\u0180-\u024f]+\.?\s*$/;
  const emailRegex = /^[-a-z0-9~!$%^&*_=+}{'?]+(\.[-a-z0-9~!$%^&*_=+}{'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;

  // Common functions
  const getFieldset = input => getClosestElement(input, '.form-fieldset');
  // const getSelectFieldset = input => (input ? input.querySelector('.form-select') : null);
  const getField = element => getClosestElement(element, '.form-list__field');

  // Name
  const nameInput = simulatorForm.querySelector('.input-distinguisher_name');
  const nameFieldset = getFieldset(nameInput);
  const isNameRequired = isFieldRequired(nameInput);

  if (nameInput) assignmentRequiredRegex(isNameRequired, nameInput, nameRegex, nameFieldset);

  // Surname
  const surnameInput = simulatorForm.querySelector('.input-distinguisher_surname');
  const surnameFieldset = getFieldset(surnameInput);
  const isSurnameRequired = isFieldRequired(surnameInput);

  if (surnameInput) assignmentRequiredRegex(isSurnameRequired, surnameInput, nameRegex, surnameFieldset);

  const prefixMaskOptions = { mask: '{+}000', };
  const phoneNumberMaskOptions = { mask: '000 000 000', };

  // Prefix
  const prefixInput = simulatorForm.querySelector('.input-distinguisher_prefix');
  const prefixFieldset = getFieldset(prefixInput);
  const isPrefixRequired = isFieldRequired(prefixInput);
  const prefixMinLength = prefixInput ? prefixInput.getAttribute('minlength') : null;
  const prefixRegex = prefixInput ? new RegExp(`^[+0-9]{${prefixMinLength},}$`) : null;
  // Mask Prefix

  if (prefixInput) {
    IMask(prefixInput, prefixMaskOptions);
    assignmentRequiredRegex(isPrefixRequired, prefixInput, prefixRegex, prefixFieldset);
  }


  // Phone number
  const phoneNumberInput = simulatorForm.querySelector('.input-distinguisher_phone-number');
  const phoneNumberFieldset = getFieldset(phoneNumberInput);
  const isPhoneNumberRequired = isFieldRequired(phoneNumberInput);
  const phoneNumberMinLength = phoneNumberInput ? phoneNumberInput.getAttribute('minlength') : null;
  const phoneNumberRegex = phoneNumberInput ? new RegExp(`^[0-9 ]{${phoneNumberMinLength},}$`) : null;

  if (phoneNumberInput) {
    IMask(phoneNumberInput, phoneNumberMaskOptions);
    assignmentRequiredRegex(isPhoneNumberRequired, phoneNumberInput, phoneNumberRegex, phoneNumberFieldset);
  }


  // Email
  const emailInput = simulatorForm.querySelector('.input-distinguisher_email');
  const emailFieldset = getFieldset(emailInput);
  const isEmailRequired = isFieldRequired(emailInput);

  if (emailInput) assignmentRequiredRegex(isEmailRequired, emailInput, emailRegex, emailFieldset);


  // One Holder
  const oneHolderInput = simulatorForm.querySelector('#oneHolder');
  const secondHolderItem = simulatorForm.getElementsByClassName('form-list__item_second-holder');
  const defaultLabel = simulatorForm.getElementsByClassName('form-list__tooltip-label_default');
  const twoHoldersLabel = simulatorForm.getElementsByClassName('form-list__tooltip-label_option_2');

  // TwoHolders
  const twoHoldersInput = simulatorForm.querySelector('#twoHolders');

  // Job status second holder
  const jobStatusSecondHolder = simulatorForm.querySelector('#jobStatusSecondHolder');
  // if second holder is activated changes null to true
  let isJobStatusSecondHolderRequired = null;
  const jobStatusSecondHolderChosenOption = jobStatusSecondHolder ? jobStatusSecondHolder.querySelector('.access-select__chosen-option') : null;
  const jobStatusSecondHolderSelectInput = jobStatusSecondHolder ? jobStatusSecondHolder.getElementsByClassName('access-select__input') : null;

  // Holders
  const holders = simulatorForm.querySelector('#holders');
  const holdersRadio = holders ? holders.getElementsByClassName('radio') : null;
  const holdersField = holders ? getClosestElement(holders, '.form-list__field') : null;
  const isHoldersRequired = holders ? holdersField.classList.contains('required') : null;

  if (holders) assignmentRequired(isHoldersRequired, holders, holdersRadio, 'radio');

  // Employees
  const employees = simulatorForm.querySelector('#employees');
  const employeesRadio = employees ? employees.getElementsByClassName('radio') : null;
  const employeesField = employees ? getClosestElement(employees, '.form-list__field') : null;
  const isEmployeesRequired = employees ? employeesField.classList.contains('required') : null;

  if (employees) assignmentRequired(isEmployeesRequired, employees, employeesRadio, 'radio');

  // Employes Yes
  const employeesYes = simulatorForm.querySelector('#employeesYes');
  const employeesNo = simulatorForm.querySelector('#employeesNo');
  const employeesNumber = simulatorForm.querySelector('#employeesNumber');

  if (employeesNo && employeesYes) {
    employeesNo.addEventListener('click', () => {
      if (!employeesYes.checked) {
        employeesNumber.style.display = '';
      }
    });

    employeesYes.addEventListener('click', () => {
      if (employeesYes.checked) {
        employeesNumber.style.display = 'flex';
      }
    });
  }

  // Job status
  const jobStatus = simulatorForm.querySelector('#jobStatus');
  const isJobStatusRequired = jobStatus ? getClosestElement(jobStatus, '.form-list__field').classList.contains('required') : null;
  const jobStatusChosenOption = jobStatus ? jobStatus.querySelector('.access-select__chosen-option') : null;
  const jobStatusSelectInput = jobStatus ? jobStatus.getElementsByClassName('access-select__input') : null;
  if (jobStatus) assignmentRequired(isJobStatusRequired, jobStatus, jobStatusSelectInput, 'select');

  // Other loans
  const otherLoans = simulatorForm.querySelector('#otherLoans');
  const otherLoansRadio = otherLoans ? otherLoans.getElementsByClassName('radio') : null;
  const otherLoansField = otherLoans ? getClosestElement(otherLoans, '.form-list__field') : null;
  const isOtherLoansRequired = otherLoans ? otherLoansField.classList.contains('required') : null;
  if (otherLoans) assignmentRequired(isOtherLoansRequired, otherLoans, otherLoansRadio, 'radio');

  const otherLoanYes = simulatorForm.querySelector('#otherLoansYes');
  const otherLoanNo = simulatorForm.querySelector('#otherLoansNo');
  const otherLoanRange = simulatorForm.querySelector('#otherLoansRange');

  if (otherLoanNo && otherLoanYes) {
    otherLoanNo.addEventListener('click', () => {
      if (!otherLoanYes.checked) {
        otherLoanRange.style.display = '';
      }
    });

    otherLoanYes.addEventListener('click', () => {
      if (otherLoanYes.checked) {
        otherLoanRange.style.display = 'flex';
      }
    });
  }

  // Legal checkboxes
  const contactCheckLegal = simulatorForm.querySelector('#checkLegal');
  const checkLegal = contactCheckLegal ? contactCheckLegal.getElementsByClassName('checkbox') : null;
  const checkLegalField = contactCheckLegal ? getClosestElement(contactCheckLegal, '.form-list__field') : null;
  const isCheckRequired = contactCheckLegal ? checkLegalField.classList.contains('required') : null;

  if (contactCheckLegal) {
    // On blur
    if (isCheckRequired) {
      for (let i = 0; i < checkLegal.length; i++) {
        checkLegal[i].addEventListener('blur', () => {
          if (contactCheckLegal.classList.contains('error')) {
            checkboxValidate(checkLegal, contactCheckLegal);
          }
        });
      }
    }
  }
  // Special conditions for Simulator Form
  if (oneHolderInput && twoHoldersInput) {
    oneHolderInput.addEventListener('click', () => {
      if (!twoHoldersInput.checked) {
        jobStatusSecondHolder.parentElement.classList.remove('required');
        isJobStatusSecondHolderRequired = null;
        for (let i = 0; i < twoHoldersLabel.length; i++) {
          if (defaultLabel[i]) {
            defaultLabel[i].style.display = '';
          }

          twoHoldersLabel[i].style.display = '';
        }
        for (let i = 0; i < secondHolderItem.length; i++) {
          secondHolderItem[i].style.display = '';
        }
      }
    });

    twoHoldersInput.addEventListener('click', () => {
      if (twoHoldersInput.checked) {
        jobStatusSecondHolder.parentElement.classList.add('required');
        isJobStatusSecondHolderRequired = true;

        for (let i = 0; i < twoHoldersLabel.length; i++) {
          if (defaultLabel[i]) {
            defaultLabel[i].style.display = 'none';
          }
          twoHoldersLabel[i].style.display = 'block';
        }
        for (let i = 0; i < secondHolderItem.length; i++) {
          secondHolderItem[i].style.display = 'block';
        }
      }
    });
  }

  // On blur
  for (let j = 0; j < jobStatusSecondHolderSelectInput.length; j++) {
    jobStatusSecondHolderSelectInput[j].addEventListener('blur', () => {
      selectValidate(jobStatusSecondHolderChosenOption, jobStatusSecondHolder);
    });
  }

  // Test form (Light validation variant without visuals, used in regular validation)
  const simulatorFormTest = () => {
    if (
      isRequiredTestPass(isHoldersRequired, radioTest(holdersRadio)) &&
      isRequiredTestPass(isEmployeesRequired, radioTest(employeesRadio)) &&
      isRequiredTestPass(
        isJobStatusRequired,
        selectTest(jobStatusChosenOption)
      ) &&
      isRequiredTestPass(
        isJobStatusSecondHolderRequired,
        selectTest(jobStatusSecondHolderChosenOption)
      ) &&
      isRequiredTestPass(isOtherLoansRequired, radioTest(otherLoansRadio))
      && isRequiredTestPass(isCheckRequired, checkboxTest(checkLegal))
    ) {
      return true;
    }

    return false;
  };

  // Validate form
  const simulatorFormValidate = () => {
    let flag = true;
    const isEdge = /Edge/.test(navigator.userAgent);

    if (isHoldersRequired && !radioTest(holdersRadio)) {
      for (let i = 0; i < holdersRadio.length; i++) {
        radioValidate(holdersRadio[i], holders);
      }

      if (flag) {
        scrollTo(holdersField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isEmployeesRequired && !radioTest(employeesRadio)) {
      for (let i = 0; i < employeesRadio.length; i++) {
        radioValidate(employeesRadio[i], employees);
      }

      if (flag) {
        scrollTo(employeesField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isJobStatusRequired && !selectTest(jobStatusChosenOption)) {
      selectValidate(jobStatusChosenOption, jobStatus);

      if (flag) {
        if (!isEdge) {
          scrollTo(holders, scrollToErrorDuration, scrollToErrorOffset);
        } else {
          const elementHolders = simulatorForm.querySelector('#holders');
          elementHolders.scrollIntoView();
        }
        flag = false;
      }
    }

    if (isJobStatusSecondHolderRequired && !selectTest(jobStatusSecondHolderChosenOption)) {
      selectValidate(jobStatusSecondHolderChosenOption, jobStatusSecondHolder);

      if (flag) {
        if (!isEdge) {
          scrollTo(holders, scrollToErrorDuration, scrollToErrorOffset);
        } else {
          const elementSecondHolder = simulatorForm.querySelector('#holders');
          elementSecondHolder.scrollIntoView();
        }
        flag = false;
      }
    }

    if (isOtherLoansRequired && !radioTest(otherLoansRadio)) {
      for (let i = 0; i < otherLoansRadio.length; i++) {
        radioValidate(otherLoansRadio[i], otherLoans);
      }

      if (flag) {
        scrollTo(otherLoansField, scrollToErrorDuration, scrollToErrorOffset);
        flag = false;
      }
    }

    if (isCheckRequired && !checkboxTest(checkLegal)) {
      checkboxValidate(checkLegal, contactCheckLegal);
    }
    if (isNameRequired && !regexTest(nameRegex, nameInput)) {
      regexValidate(nameRegex, nameInput, nameFieldset);
    }
    if (isSurnameRequired && !regexTest(nameRegex, surnameInput)) {
      regexValidate(nameRegex, surnameInput, surnameFieldset);
    }

    if (isEmailRequired && !regexTest(emailRegex, emailInput)) {
      regexValidate(emailRegex, emailInput, emailFieldset);
    }

    if (isPrefixRequired && !regexTest(prefixRegex, prefixInput)) {
      regexValidate(prefixRegex, prefixInput, prefixFieldset);
    }

    if (
      isPhoneNumberRequired &&
      !regexTest(phoneNumberRegex, phoneNumberInput)
    ) {
      regexValidate(phoneNumberRegex, phoneNumberInput, phoneNumberFieldset);
    }
  };
  // On submit
  simulatorForm.addEventListener('submit', e => {
    e.preventDefault();
    if (!simulatorFormTest()) {
      simulatorFormValidate();
    } else {
      formSubmitPreloader(simulatorForm, '.simulator-form', [
        'body',
        '.header',
        '.splitter_header-before',
      ]);
    }
  });
};
export default simulatorForms;
