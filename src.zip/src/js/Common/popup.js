const popup = mediaQueryString => {
  const instance = document.getElementsByClassName('popup');

  for (let i = 0; i < instance.length; i++) {
    const activeClassname = 'active';
    const rightClassname = 'popup__window_right';
    const thisPopup = instance[i];
    const popupTrigger = thisPopup.querySelector('.popup__trigger');
    const popupWindow = thisPopup.querySelector('.popup__window');
    const popupLink = thisPopup.getElementsByClassName('popup__link');

    const showPopup = () => {
      popupTrigger.classList.add(activeClassname);

      if (popupWindow.classList.contains(rightClassname)) {
        popupWindow.style.right = '0';
      } else {
        popupWindow.style.left = '50%';
      }
    };

    const hidePopup = () => {
      popupTrigger.classList.remove(activeClassname);

      if (popupWindow.classList.contains(rightClassname)) {
        popupWindow.style.right = '-9999px';
      } else {
        popupWindow.style.left = '-9999px';
      }
    };

    if (mediaQueryString) {
      const doesMediaQueryMatch = mediaQuery => {
        if (mediaQuery.matches) {
          popupTrigger.addEventListener('focus', showPopup);
          popupTrigger.addEventListener('blur', hidePopup);
          popupTrigger.addEventListener('mouseover', showPopup);
          popupTrigger.addEventListener('mouseleave', hidePopup);
          popupWindow.addEventListener('mouseover', showPopup);
          popupWindow.addEventListener('mouseleave', hidePopup);

          for (let j = 0; j < popupLink.length; j++) {
            const thisPopupLink = popupLink[j];

            thisPopupLink.addEventListener('focus', showPopup);
            thisPopupLink.addEventListener('blur', hidePopup);
          }
        } else {
          popupTrigger.removeEventListener('focus', showPopup);
          popupTrigger.removeEventListener('blur', hidePopup);
          popupTrigger.removeEventListener('mouseover', showPopup);
          popupTrigger.removeEventListener('mouseleave', hidePopup);
          popupWindow.removeEventListener('mouseover', showPopup);
          popupWindow.removeEventListener('mouseleave', hidePopup);

          for (let j = 0; j < popupLink.length; j++) {
            const thisPopupLink = popupLink[j];

            thisPopupLink.removeEventListener('focus', showPopup);
            thisPopupLink.removeEventListener('blur', hidePopup);
          }
        }
      };

      const mediaQuery = window.matchMedia(mediaQueryString);
      doesMediaQueryMatch(mediaQuery);
      mediaQuery.addListener(doesMediaQueryMatch);
    } else {
      popupTrigger.addEventListener('focus', showPopup);
      popupTrigger.addEventListener('blur', hidePopup);
      popupTrigger.addEventListener('mouseover', showPopup);
      popupTrigger.addEventListener('mouseleave', hidePopup);
      popupWindow.addEventListener('mouseover', showPopup);
      popupWindow.addEventListener('mouseleave', hidePopup);

      for (let j = 0; j < popupLink.length; j++) {
        const thisPopupLink = popupLink[j];

        thisPopupLink.addEventListener('focus', showPopup);
        thisPopupLink.addEventListener('blur', hidePopup);
      }
    }
  }
};

export default popup;
