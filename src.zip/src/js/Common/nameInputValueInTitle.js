const nameInputValueInTitle = () => {
  const nameInput = document.querySelector('.input-distinguisher_name');
  const namePlaceholder = document.querySelector(
    '.ancho-completo-header__title .placeholder',
  );

  if (nameInput && namePlaceholder) {
    const initialPlaceholder = namePlaceholder.innerHTML;

    nameInput.addEventListener('keyup', () => {
      if (nameInput.value) {
        namePlaceholder.innerHTML = nameInput.value;
      } else {
        namePlaceholder.innerHTML = initialPlaceholder;
      }
    });
  }
};

export default nameInputValueInTitle;
