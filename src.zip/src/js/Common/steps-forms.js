import { fadeOut, fadeIn } from '../Helpers/fade';

const results = [];

function arrayToString(text) {
  let stringResult = '';
  for (let i = 0; i < text.length; i++) {
    stringResult = stringResult.concat(text[i]);
  }
  return stringResult;
}

const stepsForm = document.querySelector('.steps-form');

if (stepsForm) {
  // Steps
  const steps = stepsForm.querySelectorAll('.step-form');
  steps.forEach(step => {
    // Radio groups
    const radioGroups = step.querySelectorAll('.radio-group');

    radioGroups.forEach(radioGroup => {
      const radios = radioGroup.querySelectorAll('.radio-wrapper');

      radios.forEach(radio => {
        const input = radio.querySelector('.radio');
        const label = radio.querySelector('.radio-label');
        const step1 = step;
        const step2 = stepsForm.querySelector(`.test-step-${label.id[0]}`);

        if (step1 && step2) {
          label.addEventListener('click', () => {
            results.push(input.value);
            localStorage.setItem('results', `R${arrayToString(results)}`);
            fadeOut(step1, fadeIn, step2);

            step2.querySelector('.steps-form__nav-back').onclick = () => {
              results.pop();
              localStorage.setItem('results', `R${arrayToString(results)}`);
              fadeOut(step2, fadeIn, step1);
            };
          });
        }
      });
    });
  });
}
