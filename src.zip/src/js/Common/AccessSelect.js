const AccessSelect = () => {
  const activeClassnameString = 'list-is-open';
  const checkedInputString = 'checked';
  const accessSelects = document.querySelectorAll('.access-select');

  if (accessSelects.length == 0) return;

  const handleClick = (e) => {
    for (let i = 0; i < accessSelects.length; i++) {
      const thisAccessSelect = accessSelects[i];
      const thisChosen = thisAccessSelect.querySelector('.access-select__chosen');
      const thisChosenOption = thisAccessSelect.querySelector('.access-select__chosen-option');
      const thisChosenOptionHidden = thisAccessSelect.querySelector('.access-select__chosen-option_hidden');
      const thisSelectList = thisAccessSelect.querySelector('.access-select__list');
      const theseInputs = thisAccessSelect.getElementsByClassName('access-select__input');
      const parentSelector = thisAccessSelect.parentNode;
      const errorValidation = parentSelector.getElementsByClassName('error-message');
      const errorValidationField = parentSelector.querySelector('.field-validation-error');

      const isClickedInsideAccessSelect = e ? thisAccessSelect.contains(e.target) : false;
      const isClickedInsideChosen = e ? thisChosen.contains(e.target) : false;

      if (isClickedInsideChosen) {
        if (!thisChosen.classList.contains(activeClassnameString)) {
          thisChosen.classList.add(activeClassnameString);
          thisSelectList.style.height = 'auto';
        } else {
          thisChosen.classList.remove(activeClassnameString);
          thisSelectList.style.height = '';
        }
      }

      if (!isClickedInsideAccessSelect) {
        thisChosen.classList.remove(activeClassnameString);
        thisSelectList.style.height = '';
      }

      if (isClickedInsideAccessSelect && !isClickedInsideChosen) {
        thisChosen.classList.remove(activeClassnameString);
        thisSelectList.style.height = '';
        const anchorText = e.srcElement.textContent.trim();
        const chosenOptionDiv = thisChosen.querySelector('.access-select__option.access-select__chosen-option');
        if (chosenOptionDiv) {
          chosenOptionDiv.textContent = anchorText;
        }
      }

      for (let j = 0; j < theseInputs.length; j++) {
        const specificInput = theseInputs[j];
        if (specificInput.checked) {
          specificInput.classList.add(checkedInputString);
          if (!thisChosen.classList.contains('active')) {
            setTimeout(() => {
              // El widget de accesibilidad cambia 'title' por 'data-ind-title' en modo contraste
              thisChosenOption.innerHTML = specificInput.title || specificInput.getAttribute('data-ind-title') || '';
              if (thisChosenOptionHidden !== null) {
                thisChosenOptionHidden.value = specificInput.value;
                thisChosenOptionHidden.classList.remove('input-validation-error');
                thisChosenOptionHidden.classList.add('valid');
              }
              if (errorValidationField !== null) {
                errorValidationField.classList.remove('field-validation-error');
                errorValidationField.classList.add('field-validation-valid');
                errorValidationField.remove();
              }
              if (thisChosenOption.innerHTML === '') {
                parentSelector.classList.add('error');
              } else {
                parentSelector.classList.remove('error');
              }
            }, 150);
          } else {
            // El widget de accesibilidad cambia 'title' por 'data-ind-title' en modo contraste
            thisChosenOption.innerHTML = specificInput.title || specificInput.getAttribute('data-ind-title') || '';
            if (thisChosenOptionHidden !== null) {
              thisChosenOptionHidden.value = specificInput.value;
              thisChosenOptionHidden.classList.remove('input-validation-error');
              thisChosenOptionHidden.classList.add('valid');
            }
            if (errorValidationField !== null) {
              errorValidationField.classList.remove('field-validation-error');
              errorValidationField.classList.add('field-validation-valid');
              errorValidationField.remove();
            }
            if (thisChosenOption.innerHTML === '') {
              parentSelector.classList.add('error');
            } else {
              parentSelector.classList.remove('error');
            }
          }
          thisChosen.classList.add('active');
        } else {
          specificInput.classList.remove(checkedInputString);
        }
      }
    }
  }

  handleClick(null);
  document.addEventListener('click', e => handleClick(e));

  for (let i = 0; i < accessSelects.length; i++) {
    const keyboardControlClassname = 'keyboard-control';
    const thisAccessSelect = accessSelects[i];
    const parentSelector = thisAccessSelect.parentNode;
    const thisChosen = thisAccessSelect.querySelector('.access-select__chosen');
    const thisChosenOption = thisAccessSelect.querySelector('.access-select__chosen-option');
    const thisSelectList = thisAccessSelect.querySelector('.access-select__list');
    const theseInputs = thisAccessSelect.getElementsByClassName('access-select__input');
    const allItems = thisAccessSelect.querySelectorAll('.access-select__item');

    for (let j = 0; j < theseInputs.length; j++) {
      const specificInput = theseInputs[j];

      specificInput.addEventListener('click', () => {
        if (!thisChosen.classList.contains(keyboardControlClassname)) {
          thisChosen.classList.remove(activeClassnameString);
          thisSelectList.style.height = '';
        } else {
          thisChosen.classList.remove(keyboardControlClassname);
        }
      });

      specificInput.addEventListener('focus', () => {
        thisChosen.classList.add(activeClassnameString);
        thisSelectList.style.height = 'auto';
      });

      specificInput.addEventListener('keydown', e => {
        if (e.keyCode === 9) {
          thisChosen.classList.remove(activeClassnameString);
          thisSelectList.style.height = '';
          thisChosen.classList.remove(keyboardControlClassname);
        }

        if (
          e.keyCode === 37 ||
          e.keyCode === 38 ||
          e.keyCode === 39 ||
          e.keyCode === 40
        ) {
          thisChosen.classList.add(keyboardControlClassname);
        }

        if (thisChosenOption.innerHTML === '') {
          parentSelector.classList.add('error');
        } else {
          parentSelector.classList.remove('error');
        }
      });
    }

    // KEYBOARD LETTER SEARCH
    let searchBuffer = '';
    let bufferTimeout;

    document.addEventListener('keydown', function (e) {
      if (!thisChosen.classList.contains(activeClassnameString)) return;

      const char = e.key.toLowerCase();

      // Procesa letras y números
      if (char.length === 1 && /[a-z0-9áéíóúüñ]/i.test(char)) {
        // Acumula las teclas
        searchBuffer += char;

        // Reinicia buffer tras 800ms sin teclear
        clearTimeout(bufferTimeout);
        bufferTimeout = setTimeout(() => {
          searchBuffer = '';
        }, 800);

        for (const item of allItems) {
          let label = item.querySelector('label').textContent.trim().toLowerCase();

          if (/^[a-záéíóúüñ]/i.test(searchBuffer[0])) {
            // Si el buffer empieza con letra: eliminar + y números iniciales
            label = label.replace(/^\+?[\d\s]+/, '').trim();
          } else {
            // Si buffer empieza con número: eliminar solo +
            label = label.replace(/^\+/, '').trim();
          }

          if (label.startsWith(searchBuffer)) {
            item.scrollIntoView({ behavior: 'smooth', block: 'center' });
            item.querySelector('input').focus();
            break;
          }
        }
      }
    });



  }
};

export default AccessSelect;