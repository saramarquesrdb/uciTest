import radioValidate from './radioValidate';
import selectValidate from './selectValidate';
import regexValidate from './regexValidate';
import getClosestElement from '../Helpers/getClosestElement';
import NumberValidate from './NumberValidate';
import valorCompraValidate from './ValorCompraValidate';
import { localeFormatNumber } from '../Helpers/_helpers';

export const assignmentRequired = (required, element, classType, type) => {
  // Definimos las funciones de manejo para cada tipo
  const handleBlurRadio = (event) => {
    radioValidate(event.target, element);
  };

  const handleBlurSelect = (event) => {
    selectValidate(event.target, element);
  };

  // Función de ayuda para agregar o quitar manejadores
  const updateEventListeners = (action, listeners) => {
    for (let i = 0; i < classType.length; i++) {
      const method = action === 'add' ? 'addEventListener' : 'removeEventListener';
      classType[i][method]('blur', listeners[type]);
    }
  };

  // Diccionario de funciones manejadoras según el tipo
  const eventListeners = {
    radio: handleBlurRadio,
    select: handleBlurSelect,
  };

  // Agregar o eliminar manejadores según el valor de 'required'
  if (required) {
    updateEventListeners('add', eventListeners);
  } else {
    updateEventListeners('remove', eventListeners);
  }
};


export const assignmentNumberRequired = (required, min, max, elementInput, elementparent, spanErrorMessageElement, requiredMessage, rangeMessage, inputItem) => {
  elementInput.addEventListener('blur', () => {
    NumberValidate(elementInput, elementparent, 'error', 'valid', required, min, max, spanErrorMessageElement, requiredMessage, rangeMessage, inputItem);
    elementInput.value = localeFormatNumber(elementInput.value).toString();
  });
};


export const assignmentValidateDownpayment = (inputValorCompra, inputCapitalPropio, fieldValidationCapitalPropio, percentage, CapitalPropioSpanErrorMessage, percentageErrorMessage, isAdquisicion) => {

  inputCapitalPropio.addEventListener('blur', () => {
    valorCompraValidate(inputValorCompra, inputCapitalPropio, fieldValidationCapitalPropio, percentage, CapitalPropioSpanErrorMessage, percentageErrorMessage, isAdquisicion);
    inputCapitalPropio.value = localeFormatNumber(inputCapitalPropio.value).toString();
  });

};

export const assigmentValidatePhoneLandings = (input) => {
  input.addEventListener('focusout', e => {

    validatePhoneNumber(input);

});


}

function validatePhoneNumber(inputElement) {
  /* ─ Parámetros de longitud ─ */
  const minLength = parseInt(inputElement.getAttribute('data-val-length-min'), 10);
  const maxLength = parseInt(inputElement.getAttribute('data-val-length-max'), 10);
  const rawValue  = inputElement.value.replace(/\s+/g, '');

  /* ─ Elementos de UI ─ */
  const formFieldset = inputElement.closest('.form-fieldset');
  const errorDiv     = formFieldset?.querySelector('.error-message');
  if (!formFieldset || !errorDiv) return;

  const msgLongitud = inputElement.getAttribute('data-val-length') ||
                      'Número de teléfono con longitud incorrecta.';

  /* ─ ¿Hay error de igualdad activo? ─ */
  const equalityActive = inputElement.classList.contains('input-validation-error-equality');

  /* ─ Reset selectivo ─ */
  // Quita cualquier marca de “válido”
  inputElement.classList.remove('valid', 'input-validation-valid');

  // Si no hay error de igualdad, limpia también la clase genérica de error
  if (!equalityActive) {
    inputElement.classList.remove('input-validation-error');
  }

  /* ─ Validar longitud ─ */
  const invalidLength = rawValue.length < minLength || rawValue.length > maxLength;

  if (invalidLength) {
    /* ─── Error de longitud ─── */
    inputElement.classList.add('input-validation-error');   // ← pone borde rojo
    formFieldset.classList.add('has-error');
    inputElement.setAttribute('aria-invalid', 'true');

    // Muestra SIEMPRE el mensaje de longitud (prioridad sobre igualdad)
    errorDiv.textContent   = msgLongitud;
    errorDiv.style.display = 'block';
  } else {
    /* ─── Longitud correcta ─── */
    if (!equalityActive) {
      // Ya no queda ningún error → limpiar por completo
      inputElement.classList.remove('input-validation-error');
      inputElement.classList.add('valid');                   // ← marca como válido
      errorDiv.textContent   = '';
      errorDiv.style.display = 'none';
      formFieldset.classList.remove('has-error');
      inputElement.setAttribute('aria-invalid', 'false');
    } else {
      // Solo persiste el error de igualdad → deja visible su mensaje
      errorDiv.style.display = 'inline';
    }
  }
}


export const assigmentMillionslandings = (input) => {
  
  input.addEventListener('focusout', e => {
    //Añadirle los . en los miles
    input.value =   input.value.replace(/\D/g, '') // Elimina cualquier carácter que no sea número
    .replace(/\B(?=(\d{3})+(?!\d))/g, '.'); // Añade un punto como separador de miles
});

  input.addEventListener('input', e => {


     // Reemplaza todo lo que no sea un número (es decir, no \d) con una cadena vacía
     e.target.value = input.value.replace(/\D/g, '');
    ValidateNumberLanding(input);

  
  });


}


export const ValidateNumberLanding = (input) => {
  ValidateNumber(input);
}


function ValidateNumber(input)
{

  const valor = input.value;
  const formFieldset = input.closest('.form-fieldset');

  const errorDiv = formFieldset.querySelector('.error-message');
  const numero = parseInt(valor.replace(/\D/g, ''));

  const min = parseInt(input.getAttribute('min'));
  const max = parseInt(input.getAttribute('max'));
  const mensajeRango = input.getAttribute('data-val-range');
  const mensajeNumero = input.getAttribute('data-val-required');

    // Resetear el mensaje de error
  errorDiv.style.display = 'none';
  errorDiv.innerText = '';
   // Eliminar ambas clases antes de la validación
  input.classList.remove('input-validation-valid', 'input-validation-error');

  // Validar si es un número
  if (isNaN(numero) || numero === "") {
    errorDiv.innerText = mensajeNumero;
    errorDiv.style.display = 'block';
         // Añadir clase de error
    input.classList.add('input-validation-error');
    return;
}

// Validar si está dentro del rango
if (numero < min || numero > max) {
    errorDiv.innerText = mensajeRango;
    errorDiv.style.display = 'block';
      // Añadir clase de error
    input.classList.add('input-validation-error');
    return;
}

   // Añadir clase de validación exitosa
   input.classList.add('input-validation-valid');
}

export const assignmentAllowOnlyLetters = (elementInput) => {

  elementInput.addEventListener('input', e => {
    if (/\d/.test(elementInput.value)) {
      // Borra el contenido del input si es un número
      e.target.value = elementInput.value.replace(/\d/g, '');
    }
  });

};


export const assignmentRequiredRegex = (required, elementInput, elementRegex, field) => {
  if (required) {
    elementInput.addEventListener('blur', () => {
      regexValidate(elementRegex, elementInput, field);
    });

  }

};

export const isFieldRequired = (input, field) => {
  if (input) {
    return getClosestElement(input, '.form-list__field').classList.contains('required');
  }
  return (field) ? field.classList.contains('required') : false;
}

export const getFieldset = input => getClosestElement(input, '.form-fieldset');
export const getField = element => getClosestElement(element, '.form-list__field');
