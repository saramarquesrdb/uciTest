const radioTest = radio => {
  if (radio) {
    for (let i = 0; i < radio.length; i++) {
      const thisRadio = radio[i];

      if (!thisRadio.checked) {
        if (i === radio.length - 1) {
          return false;
        }
      } else {
        return true;
      }
    }
  }
  return false;
};

export default radioTest;
