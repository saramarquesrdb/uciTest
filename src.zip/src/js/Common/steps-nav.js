const stepsNav = () => {
  // Buttons
  const elementSteps = Array.from(document.querySelectorAll('.steps-nav__list-item-step'));
  const continueButton = document.getElementById('form-steps-continue');

  // Contents
  const containerSteps = Array.from(document.querySelectorAll('.steps-nav__body .content-item .detail'));

  function clearState() {
    elementSteps.forEach(ele => {
      ele.parentElement.classList.remove('active');
    });
    containerSteps.forEach(ele => {
      ele.parentElement.classList.remove('visibility');
    });
  }

  function loadFirstStep() {
    const bloque = document.getElementById('content-1');
    bloque.classList.add('visibility');
    const form = bloque.closest('form');
    const mobileForm = form.getElementsByClassName('.mobile-form-steps');
    if (mobileForm !== null && mobileForm !== 'undefined' && !window.matchMedia('(min-width: 1024px)').matches) {
      form.querySelector("button[type='submit']").style.display = 'none';
    }
  }

  function setState() {
    elementSteps.forEach((ele, index, array) => {
      const spanTotal = document.querySelector('.steps-nav__breadcrumb_total');
      spanTotal.innerHTML = array.length;
      // const spanSubtitle = document.querySelector('.steps-nav__breadcrumb_subtitle');
      // spanSubtitle.innerHTML = ele.textContent;
      if (!ele.parentElement.classList.contains('disabled')) {
        ele.parentElement.addEventListener('click', () => {
          clearState();
          ele.parentElement.classList.add('active');

          const bloque = document.getElementById(`content-${index + 1}`);
          bloque.classList.add('visibility');
          // Breadcrumb
          if (parseInt(spanTotal.innerHTML, 10) === index + 1) {
            const form = bloque.closest('form');
            form.querySelector("button[type='submit']").style.display = 'inline-block';
          } else {
            const form = bloque.closest('form');
            form.querySelector("button[type='submit']").style.display = 'none';
          }
          const spanStep = document.querySelector('.steps-nav__breadcrumb_step');
          spanStep.innerHTML = index + 1;
          const spanSubtitle = document.querySelector('.steps-nav__breadcrumb_subtitle');
          spanSubtitle.innerHTML = ele.textContent;
        });
      }
    });

    if (continueButton !== null && continueButton !== 'undefined') {
      continueButton.addEventListener('click', () => {
        clearState();
        elementSteps[1].parentElement.classList.add('active');
        const bloque = document.getElementById('content-2');
        bloque.classList.add('visibility');
        const spanStep = document.querySelector('.steps-nav__breadcrumb_step');
        spanStep.innerHTML = 2;
        const spanSubtitle = document.querySelector('.steps-nav__breadcrumb_subtitle');
        spanSubtitle.innerHTML = elementSteps[1].textContent;
        const form = bloque.closest('form');
        form.querySelector("button[type='submit']").style.display = 'inline-block';
      });
    }
  }


  function init() {
    loadFirstStep();
    setState(elementSteps);
  }

  init();
};

export default stepsNav;
