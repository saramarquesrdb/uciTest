const inputLabel = () => {
  const fieldset = document.getElementsByClassName('fieldset');
  const activeClassname = 'active';

  for (let i = 0; i < fieldset.length; i++) {
    const thisFieldset = fieldset[i];
    const thisInput = thisFieldset.querySelector('.input');
    const thisTextarea = thisFieldset.querySelector('.textarea');

    if (thisInput) {
      if (thisInput.value.trim().length) {
        thisFieldset.classList.add(activeClassname);
      }

      thisInput.addEventListener('focus', () => {
        thisFieldset.classList.add(activeClassname);
      });

      thisInput.addEventListener('blur', () => {
        if (!thisInput.value.trim().length) {
          thisFieldset.classList.remove(activeClassname);
        }
      });
    }

    if (thisTextarea) {
      if (thisTextarea.value.trim().length) {
        thisFieldset.classList.add(activeClassname);
      }

      thisTextarea.addEventListener('focus', () => {
        thisFieldset.classList.add(activeClassname);
      });

      thisTextarea.addEventListener('blur', () => {
        if (!thisTextarea.value.trim().length) {
          thisFieldset.classList.remove(activeClassname);
        }
      });
    }
  }
};

export default inputLabel;
