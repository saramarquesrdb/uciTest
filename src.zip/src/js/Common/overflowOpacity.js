import isElementBound from '../Helpers/isElementBound';

const overflowOpacity = (parentSelector, childSelector, wrapperPadding) => {
  const parent = document.querySelectorAll(parentSelector);
  const child = document.querySelectorAll(childSelector);

  const checkBounding = (par, chi, padding) => {
    for (let j = 0; j < chi.length; j++) {
      if (!isElementBound(par, chi[j], padding)) {
        chi[j].style.opacity = '0.5';
      } else {
        chi[j].style.opacity = '1';
      }
    }
  };

  for (let i = 0; i < parent.length; i++) {
    checkBounding(parent[i], child, wrapperPadding);

    parent[i].addEventListener('scroll', () => {
      checkBounding(parent[i], child, wrapperPadding);
    });

    window.addEventListener('resize', () => {
      checkBounding(parent[i], child, wrapperPadding);
    });
  }
};

export default overflowOpacity;
