import scrollTo from '../Helpers/scrollTo';

const anchor = (linkClassname, animationType) => {
  const link = document.getElementsByClassName(linkClassname);

  for (let i = 0; i < link.length; i++) {
    link[i].addEventListener('click', e => {
      e.preventDefault();

      const that = link[i];
      const href = that.getAttribute('href');
      if (href.indexOf('#') !== -1) {
        const target = document.querySelector(href);
        if (document.getElementById(href.replace('#', ''))) scrollTo(target, 200, 120, animationType);
        else scrollTo(target, 200, 1, animationType);
      } else {
        window.location.href = href;
      }
    });
  }
};

export default anchor;
