const stickyBetter = (watchElement, targetElement) => {
  // Only for header: no need using a header clone, so we hide it
  if (document.querySelector('.header__cta-btn.sticky')) {
    const stickyClone = document.querySelector('.header__cta-btn.sticky.sticky-clone');
    if (stickyClone) {
      if (window.matchMedia('(max-width: 1023px)').matches) {
        stickyClone.remove();
      }
    }
  }

  window.addEventListener('scroll', () => {
    const rect = watchElement.getBoundingClientRect();
    if (rect.top < -watchElement.offsetHeight) {
      targetElement?.classList.add('stick-to-top');
    } else {
      targetElement?.classList.remove('stick-to-top');
    }
  });
};

export default stickyBetter;
