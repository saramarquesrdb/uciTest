const dropdown = (
  selectorClassname,
  triggerClassname,
  targetClassname,
  mouseleaveElementSelector,
  mediaQueryString,
  additionalElementsArray,
  activeClassname = 'active',
  isHoverEnabled = true
) => {
  const selector = document.querySelectorAll(selectorClassname);
  const trigger = document.querySelectorAll(
    `${selectorClassname} ${triggerClassname}`
  );
  const target = document.querySelectorAll(targetClassname);
  const mouseleaveElement = document.querySelector(mouseleaveElementSelector);

  for (let i = 0; i < selector.length; i++) {
    const thisTrigger = selector[i].querySelector(triggerClassname);
    const thisTarget = target[i];

    const changeActiveStateForClick = () => {
      for (let j = 0; j < selector.length; j++) {
        if (trigger[j] !== thisTrigger) {
          trigger[j].classList.remove(activeClassname);
        }

        if (target[j] && target[j] !== thisTarget) {
          target[j].classList.remove(activeClassname);
        }
      }

      if (!thisTrigger.classList.contains(activeClassname)) {
        thisTrigger.classList.add(activeClassname);
      } else {
        thisTrigger.classList.remove(activeClassname);
      }

      if (thisTarget && !thisTarget.classList.contains(activeClassname)) {
        thisTarget.classList.add(activeClassname);
      } else if (thisTarget) {
        thisTarget.classList.remove(activeClassname);
      }

      if (additionalElementsArray) {
        for (let j = 0; j < selector.length; j++) {
          if (
            trigger[j].classList.contains(activeClassname) &&
            !additionalElementsArray[0].classList.contains(activeClassname)
          ) {
            additionalElementsArray.map(el =>
              el.classList.add(activeClassname));
            return;
          }

          if (
            trigger[j].classList.contains(activeClassname) &&
            additionalElementsArray[0].classList.contains(activeClassname)
          ) {
            return;
          }

          if (
            !trigger[j].classList.contains(activeClassname) &&
            additionalElementsArray[0].classList.contains(activeClassname)
          ) {
            additionalElementsArray.map(el =>
              el.classList.remove(activeClassname));
          }
        }
      }

      const dataBtnLink = thisTrigger.getAttribute('data-btn-link');
      if (dataBtnLink) {
        window.location.href = dataBtnLink;
      }
    };

    const changeActiveStateForHover = () => {
      for (let j = 0; j < selector.length; j++) {
        if (trigger[j] !== thisTrigger) {
          trigger[j].classList.remove(activeClassname);
        }

        if (target[j] && target[j] !== thisTarget) {
          target[j].classList.remove(activeClassname);
        }
      }

      if (!thisTrigger.classList.contains(activeClassname)) {
        thisTrigger.classList.add(activeClassname);
      }

      if (thisTarget && !thisTarget.classList.contains(activeClassname)) {
        thisTarget.classList.add(activeClassname);
      }

      if (additionalElementsArray) {
        for (let j = 0; j < selector.length; j++) {
          if (
            trigger[j].classList.contains(activeClassname) &&
            !additionalElementsArray[0].classList.contains(activeClassname)
          ) {
            additionalElementsArray.map(el =>
              el.classList.add(activeClassname));
            return;
          }

          if (
            trigger[j].classList.contains(activeClassname) &&
            additionalElementsArray[0].classList.contains(activeClassname)
          ) {
            return;
          }
        }
      }
    };

    const changeActiveStateForMouseleave = () => {
      if (thisTrigger.classList.contains(activeClassname)) {
        thisTrigger.classList.remove(activeClassname);
      }

      if (thisTarget.classList.contains(activeClassname)) {
        thisTarget.classList.remove(activeClassname);
      }

      if (
        additionalElementsArray &&
        additionalElementsArray[0].classList.contains(activeClassname)
      ) {
        additionalElementsArray.map(el => el.classList.remove(activeClassname));
      }
    };

    if (mediaQueryString) {
      const doesMediaQueryMatch = mediaQuery => {
        if (mediaQuery.matches) {
          thisTrigger.addEventListener('click', changeActiveStateForClick);

          if (isHoverEnabled) {
            thisTrigger.addEventListener(
              'mouseover',
              changeActiveStateForHover
            );
            mouseleaveElement.addEventListener(
              'mouseleave',
              changeActiveStateForMouseleave
            );
          }
        } else {
          thisTrigger.removeEventListener('click', changeActiveStateForClick);

          if (isHoverEnabled) {
            thisTrigger.removeEventListener(
              'mouseover',
              changeActiveStateForHover
            );
            mouseleaveElement.removeEventListener(
              'mouseleave',
              changeActiveStateForMouseleave
            );
          }
        }
      };

      const mediaQuery = window.matchMedia(mediaQueryString);
      doesMediaQueryMatch(mediaQuery);
      mediaQuery.addListener(doesMediaQueryMatch);
    } else {
      thisTrigger.addEventListener('click', changeActiveStateForClick);

      if (isHoverEnabled) {
        thisTrigger.addEventListener('mouseover', changeActiveStateForHover);
        mouseleaveElement.addEventListener(
          'mouseleave',
          changeActiveStateForMouseleave
        );
      }
    }
  }
};

export default dropdown;
