const selectTest = chosenOption => {
  if (chosenOption && (chosenOption.value == "" || chosenOption.value == undefined)) {
    return false;
  }

  return true;
};

export default selectTest;
