const checkboxValidate = (
  checkbox,
  parent,
  errorClassname = 'error',
  validClassname = 'valid',
) => {
  for (let i = 0; i < checkbox.length; i++) {
    const thisCheckbox = checkbox[i];

    if (!thisCheckbox.checked) {
      if (!parent.classList.contains(errorClassname)) {
        parent.classList.remove(validClassname);
        parent.classList.add(errorClassname);
      }

      return false;
    }
    if (i === checkbox.length - 1) {
      if (parent.classList.contains(errorClassname)) {
        parent.classList.remove(errorClassname);
      }

      parent.classList.add(validClassname);
    }
  }
};

export default checkboxValidate;
