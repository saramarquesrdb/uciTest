const callMeF = () => {
  const callMe = document.querySelector('.call-me');
  let timeoutCallMeClose;

  if (document.querySelector('body:not(.touch-device)')) {
    callMe.addEventListener('mouseenter', () => {
      callMe.querySelector('.wrap').classList.replace('fade-out', 'fade-in');
    });
    callMe.addEventListener('mouseleave', () => {
      callMe.querySelector('.wrap').classList.replace('fade-in', 'fade-out');
    });
  } else {
    callMe.addEventListener('click', () => {
      if (callMe.querySelector('.wrap').classList.contains('fade-out')) {
        callMe.querySelector('.wrap').classList.replace('fade-out', 'fade-in');
        timeoutCallMeClose = setTimeout(() => {
          callMe.querySelector('.wrap').classList.replace('fade-in', 'fade-out');
        }, 3000);
      } else if (callMe.querySelector('.wrap').classList.contains('fade-in')) {
        clearTimeout(timeoutCallMeClose);
        timeoutCallMeClose = null;
        callMe.querySelector('.wrap').classList.replace('fade-in', 'fade-out');
      }
    });
  }
};

export default callMeF;
