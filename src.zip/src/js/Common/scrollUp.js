import scrollTo from '../Helpers/scrollTo';

if (document.body.classList.contains('scrollUp')) {
  const scrollUp = document.createElement('div');
  scrollUp.style.display = 'none';
  scrollUp.innerHTML = '<span class="go-top__inner pointer"></span>';
  scrollUp.addEventListener('click', () => {
    scrollTo(document.body);
  });
  document.body.appendChild(scrollUp);

  document.addEventListener('scroll', () => {
    scrollUp.style.display = (window.scrollY > window.innerHeight) ? 'block' : 'none';
  });
}
