import scrollTo from '../Helpers/scrollTo';
import getClosestElement from '../Helpers/getClosestElement';

const formSubmitPreloader = (
  form,
  wrapperSelector,
  additionalUniqueElements
) => {
  const activeClassname = 'active';
  const wrapper = getClosestElement(form, wrapperSelector);
  if (wrapper === null) {
    return;  
}

  const preloader = wrapper.querySelector('.preloader');

  scrollTo(
    wrapper.offsetTop,
    500,
    -(wrapper.getBoundingClientRect().height / 4)
  );

  if (additionalUniqueElements) {
    additionalUniqueElements.map(el => {
      const thisEl = document.querySelector(el);

      if (thisEl) {
        thisEl.classList.add(activeClassname);
      }
    });
  }

  wrapper.classList.add(activeClassname);
  preloader.classList.add(activeClassname);

  setTimeout(() => {
    form.submit();
  }, 1000);
};

export default formSubmitPreloader;
