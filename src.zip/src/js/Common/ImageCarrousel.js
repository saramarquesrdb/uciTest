import Swiper from 'swiper';

const imageCarrousel = () => {
    const htmlElements = {
        slides: document.querySelectorAll('.image-carrousel__img'),
        closeButton: document.getElementById('imageCarrouselClose'),
    };

    if (htmlElements.slides) {
        // Add 'active' class when image is clicked
        htmlElements.slides.forEach(img => {
            img.addEventListener('click', () => {
                const overlay = document.querySelector('.image-carrousel.image-carrousel__overlay');
                if (overlay) {
                    overlay.classList.add('active');
                    // image-carrousel
                    document.querySelectorAll('.image-carrousel-overlay .swiper-container').forEach(slider => new Swiper(slider, {
                        slidesPerView: "auto",
                        effect: slider.dataset.effect ?? 'swipe',
                        // centeredSlides: true,
                        pagination: {
                            el: slider.querySelector('.swiper-pagination'),
                            clickable: true,
                        },
                        autoplay: (slider.dataset.autoplay === '1') ? { delay: slider.dataset.delay } : false,
                        navigation: {
                            nextEl: slider.querySelector('.swiper-button-next'),
                            prevEl: slider.querySelector('.swiper-button-prev'),
                        },
                        breakpoints: {
                            40000: {
                                slidesPerView: 1,
                                slidesPerGroup: 1,
                                spaceBetween: 0,
                            }
                        }
                    }))
                }
            });
        });
    }

    if (htmlElements.closeButton) {
        htmlElements.closeButton.addEventListener('click', () => {
            const overlay = document.querySelector('.image-carrousel__overlay');
            if (overlay) {
                overlay.classList.remove('active');
            }
        });
    }
};

export default imageCarrousel;