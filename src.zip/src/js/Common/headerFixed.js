if (document.querySelector('header.header-fixed') && window.innerWidth > 1023) {
    if (window.location.href.indexOf("/blog") < 0) {
        const header = document.querySelector('header');
        const wrapper = header.querySelector('.header-fixed__wrapper');
        const headWrapper = header.querySelector('.header-fixed__head-wrapper');
        const headWrapperRect = headWrapper?.getBoundingClientRect();
        const ctaBtn = wrapper.querySelector('.header-fixed__cta-btn.sticky');
        const container = document.createElement('div');
        container.style.display = 'none';
        container.style.position = 'relative';
        header.appendChild(container);

        const clonedCtaBtn = ctaBtn.cloneNode(true);
        clonedCtaBtn.style.display = 'none';
        clonedCtaBtn.style.position = 'absolute';

        container.appendChild(clonedCtaBtn);

        let lastScrollTop = 0;

        window.addEventListener('scroll', function () {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            if (scrollTop > lastScrollTop) {
                wrapper.style.transform = 'translateY(-100%)';
                container.style.display = 'block';
                clonedCtaBtn.style.display = 'flex';
                clonedCtaBtn.style.top = `${-(header.getBoundingClientRect().height + 1)}px`;
                clonedCtaBtn.style.right = `${document.documentElement.clientWidth - (headWrapperRect?.left + headWrapperRect?.width)}px`;
                clonedCtaBtn.querySelectorAll('.btn').forEach(btn => btn.style.display = 'block');
            } else {
                wrapper.style.transform = 'translateY(0)';
                container.style.display = 'none';
                clonedCtaBtn.style.display = 'none';
                clonedCtaBtn.querySelectorAll('.btn').forEach(btn => btn.style.display = 'none');
            }
            lastScrollTop = scrollTop;
        });

        const mediaQuery = window.matchMedia('(max-width: 1024px)');
        mediaQuery.addEventListener('change', function (e) {
            if (e.matches) {
                if (header.contains(container)) {
                    header.removeChild(container);
                }
            } else {
                if (!header.contains(container)) {
                    header.appendChild(container);
                }
            }
        });
    }
    else {
        const header = document.querySelector('header');
        header.style.position = "absolute";
        header.style.top = "0";
    }
}