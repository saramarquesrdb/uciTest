const lockTwoRangeSliders = (
  firstSliderSelector,
  firstSliderChosenValueSelector,
  secondSliderSelector,
  secondSliderChosenValueSelector,
) => {
  const firstSlider = document.querySelector(firstSliderSelector);
  const secondSlider = document.querySelector(secondSliderSelector);
  const firstSliderChosenValue = document.querySelector(
    firstSliderChosenValueSelector,
  );
  const secondSliderChosenValue = document.querySelector(
    secondSliderChosenValueSelector,
  );
  const lockedFirstSliderValue = firstSliderChosenValue
    ? firstSliderChosenValue.dataset.default
    : null;
  const lockedSecondSliderValue = secondSliderChosenValue
    ? secondSliderChosenValue.dataset.default
    : null;
  let lockedValues = lockedFirstSliderValue && lockedSecondSliderValue
    ? [lockedFirstSliderValue, lockedSecondSliderValue]
    : null;

  const setLockedValues = () => {
    lockedValues = [
      Number(firstSlider.noUiSlider.get()),
      Number(secondSlider.noUiSlider.get()),
    ];
  };

  const crossUpdate = (value, slider) => {
    const a = firstSlider === slider ? 0 : 1;
    const b = a ? 0 : 1;

    value -= lockedValues[b] - lockedValues[a];
    slider.noUiSlider.set(value);
  };

  if (firstSlider && secondSlider) {
    firstSlider.noUiSlider.on('change', setLockedValues);
    secondSlider.noUiSlider.on('change', setLockedValues);

    firstSlider.noUiSlider.on('slide', (values, handle) => {
      crossUpdate(values[handle], secondSlider);
    });

    secondSlider.noUiSlider.on('slide', (values, handle) => {
      crossUpdate(values[handle], firstSlider);
    });
  }
};

export default lockTwoRangeSliders;
