const radioValidate = (
  radio,
  parent,
  errorClassname = 'error',
  validClassname = 'valid',
) => {
  if (!radio.checked) {
    if (!parent.classList.contains(errorClassname)) {
      parent.classList.remove(validClassname);
      parent.classList.add(errorClassname);
    }
  } else {
    if (parent.classList.contains(errorClassname)) {
      parent.classList.remove(errorClassname);
    }

    parent.classList.add(validClassname);
  }
};

export default radioValidate;
