import scrollTo from "../Helpers/scrollTo";
import getClosestElement from "../Helpers/getClosestElement";

const showMore = (
  parentClassname,
  childClassname,
  triggerSelector,
  slideDownDuration = 300,
) => {
  const parents = document.getElementsByClassName(parentClassname);

  Array.from(parents).forEach((parent) => {
    const numberOfVisible = parseInt(parent.dataset.numberOfVisibleElements, 10);
    const children = Array.from(parent.getElementsByClassName(childClassname));
    const triggers = parent.querySelectorAll(triggerSelector);
    const triggersLess = parent.querySelectorAll(`${triggerSelector}_less`);

    // Ocultar los hijos que exceden el límite visible
    children.forEach((child, index) => {
      child.style.display = index < numberOfVisible ? '' : 'none';
    });

    // Mostrar botón solo si hay más elementos de los visibles
    triggers.forEach((trigger, index) => {
      const triggerLess = triggersLess[index];

      if (children.length <= numberOfVisible) {
        trigger.style.display = 'none';
        if (triggerLess) triggerLess.style.display = 'none';
        return;
      }

      trigger.style.display = 'inline-block';
      if (triggerLess) triggerLess.style.display = 'none';

      // Evento para mostrar más
      trigger.addEventListener('click', () => {
        trigger.style.display = 'none';
        if (triggerLess) triggerLess.style.display = 'inline-block';

        children.slice(numberOfVisible).forEach((child) => {
          child.style.display = ''; // O 'block', 'flex' si aplica
        });
      });

      // Evento para mostrar menos
      if (triggerLess) {
        triggerLess.addEventListener('click', () => {
          trigger.style.display = 'inline-block';
          triggerLess.style.display = 'none';

          children.forEach((child, index) => {
            child.style.display = index < numberOfVisible ? '' : 'none';
          });

          const topElement = getClosestElement(parent, '.link_more_top');
          if (topElement) {
            scrollTo(topElement, 200, 100);
          }
        });
      }
    });
  });
};

export default showMore;
