import 'lazysizes';
import 'lazysizes/plugins/respimg/ls.respimg';

document.addEventListener('lazybeforeunveil', e => {
  const bgData = e.target.getAttribute('data-bg');
  const bgDataArray = bgData ? bgData.split(',') : null;

  if (bgDataArray) {
    const srcArray = bgDataArray.map(el => {
      const elArray = el.trim().split(' ');
      const src = elArray[0];

      return src;
    });

    const widthArray = bgDataArray.map(el => {
      const elArray = el.trim().split(' ');
      const width = elArray[1];

      return width;
    });

    const doesItMatch = () => {
      if (
        widthArray[0] &&
        window.matchMedia(`(max-width: ${widthArray[0]})`).matches
      ) {
        e.target.style.backgroundImage = `url("${srcArray[0]}")`;
      } else if (
        widthArray[1] &&
        window.matchMedia(`(max-width: ${widthArray[1]})`).matches
      ) {
        e.target.style.backgroundImage = `url("${srcArray[1]}")`;
      } else if (
        widthArray[2] &&
        window.matchMedia(`(max-width: ${widthArray[2]})`).matches
      ) {
        e.target.style.backgroundImage = `url("${srcArray[2]}")`;
      } else if (
        widthArray[3] &&
        window.matchMedia(`(max-width: ${widthArray[3]})`).matches
      ) {
        e.target.style.backgroundImage = `url("${srcArray[3]}")`;
      } else if (
        widthArray[4] &&
        window.matchMedia(`(max-width: ${widthArray[4]})`).matches
      ) {
        e.target.style.backgroundImage = `url("${srcArray[4]}")`;
      } else if (srcArray[4]) {
        e.target.style.backgroundImage = `url("${srcArray[4]}")`;
      } else if (srcArray[3]) {
        e.target.style.backgroundImage = `url("${srcArray[3]}")`;
      } else if (srcArray[2]) {
        e.target.style.backgroundImage = `url("${srcArray[2]}")`;
      } else if (srcArray[1]) {
        e.target.style.backgroundImage = `url("${srcArray[1]}")`;
      } else if (srcArray[0]) {
        e.target.style.backgroundImage = `url("${srcArray[0]}")`;
      }
    };

    doesItMatch();
    window.matchMedia('(max-width: 767px)').addListener(doesItMatch);
    window.matchMedia('(max-width: 1023px)').addListener(doesItMatch);
    window.matchMedia('(max-width: 1279px)').addListener(doesItMatch);
    window.matchMedia('(max-width: 1679px)').addListener(doesItMatch);
  }
});
