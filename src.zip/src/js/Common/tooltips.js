const tooltips = () => {
  const settings = {
    debug: 0
  };
  const allTooltips = [...document.querySelectorAll('.tooltip')];

  // Loop all tooltips
  allTooltips.forEach((tooltip, i) => {
    const tooltipMsg = tooltip.querySelector('.msg-tooltip');
    tooltip.addEventListener('mouseenter', () => {
      // Dimensions Viewport
      const viewportHeight = innerHeight;
      const viewportWidth = innerWidth;

      // Dimensions Tooltip Msg Box
      const tooltipMsgHeight = tooltipMsg.getBoundingClientRect().height;
      const tooltipMsgWidth = tooltipMsg.getBoundingClientRect().width;

      // Distances from border
      const { top } = tooltip.getBoundingClientRect();
      const bottom = viewportHeight - tooltip.getBoundingClientRect().bottom - 16;
      const { left } = tooltip.getBoundingClientRect();
      const right = viewportWidth - tooltip.getBoundingClientRect().right - 16;
      if (settings.debug === 0) {
        if (i === 0) { // First Item
          // console.log('Viewport width: ', viewportWidth);
          // console.log('Viewport height: ', viewportHeight);
          // console.log('Tooltip Msg Height : ', tooltipMsgHeight);
          // console.log('Dist TOP: ', top);
          // console.log('Dist BOTTOM: ', bottom);
          // console.log('Dist LEFT: ', left);
          // console.log('Dist RIGHT: ', right);
          // console.log('Tooltip coordinates', tooltip.getBoundingClientRect());
        }
      }
      // TOP Collision
      if (top < tooltipMsgHeight) {
        if (tooltip.classList.contains('under')) {
          tooltip.classList.remove('under');
        }
      }
      // BOTTOM Collision
      if (bottom < tooltipMsgHeight) {
        tooltip.classList.add('under');
      }
      // LEFT Collision
      if (left < tooltipMsgWidth) {
        if (left < tooltipMsgWidth / 2) {
          if (tooltip.classList.contains('right')) {
            tooltip.classList.replace('right', 'left');
        } else {
            tooltip.classList.add('left');
          }
        }
      }
      // RIGHT Collision
      if (right < tooltipMsgWidth) {
        if (right < tooltipMsgWidth / 2) {
          if (tooltip.classList.contains('left')) {
            tooltip.classList.replace('left', 'right');
        } else {
            tooltip.classList.add('right');
          }
        }
      }
    });
  });
};

export default tooltips;
