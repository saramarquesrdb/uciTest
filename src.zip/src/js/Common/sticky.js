const sticky = (
  stickyElement,
  offset = 200,
  secondStickyElement,
  extraElement,
  extraClassname,
  stickyHeaderButtonScroll = null,
) => {
  const activeClassname = 'visible';
  const fromTop = stickyElement.offsetTop;
  const { height } = stickyElement.getBoundingClientRect();
  const clone = stickyHeaderButtonScroll || stickyElement.cloneNode(true);
  let previousScrollTopValue = 0;

  if (!stickyHeaderButtonScroll) {
    clone.classList.add('sticky-clone');
    stickyElement.insertBefore(clone, stickyElement.firstChild);
  }
  const manageVisibility = () => {
    if (window.pageYOffset >= fromTop + height + offset) {
      if (!clone.classList.contains(activeClassname)) {
        clone.classList.add(activeClassname);
      }
    } else {
      if (clone.classList.contains(activeClassname)) {
        clone.classList.remove(activeClassname);
      }
    }
  };

  const manageVisibilityInBothDirections = () => {
    if (
      (document.body.scrollTop >= fromTop + height + offset ||
        document.documentElement.scrollTop >= fromTop + height + offset) &&
      (document.body.scrollTop > previousScrollTopValue ||
        document.documentElement.scrollTop > previousScrollTopValue)
    ) {
      if (extraElement && !extraElement.classList.contains(extraClassname)) {
        if (!clone.classList.contains(activeClassname)) {
          clone.classList.add(activeClassname);
        }

        if (secondStickyElement.classList.contains(activeClassname)) {
          secondStickyElement.classList.remove(activeClassname);
        }
      } else if (extraElement) {
        return;
      } else {
        if (!clone.classList.contains(activeClassname)) {
          clone.classList.add(activeClassname);
        }

        if (secondStickyElement.classList.contains(activeClassname)) {
          secondStickyElement.classList.remove(activeClassname);
        }
      }
    } else if (
      (document.body.scrollTop >= fromTop + height + offset ||
        document.documentElement.scrollTop >= fromTop + height + offset) &&
      (document.body.scrollTop < previousScrollTopValue ||
        document.documentElement.scrollTop < previousScrollTopValue)
    ) {
      if (extraElement && !extraElement.classList.contains(extraClassname)) {
        if (clone.classList.contains(activeClassname)) {
          clone.classList.remove(activeClassname);
        }

        if (!secondStickyElement.classList.contains(activeClassname)) {
          secondStickyElement.classList.add(activeClassname);
        }
      } else if (extraElement) {
        return;
      } else {
        if (clone.classList.contains(activeClassname)) {
          clone.classList.remove(activeClassname);
        }

        if (!secondStickyElement.classList.contains(activeClassname)) {
          secondStickyElement.classList.add(activeClassname);
        }
      }
    } else {
      if (extraElement && !extraElement.classList.contains(extraClassname)) {
        if (clone.classList.contains(activeClassname)) {
          clone.classList.remove(activeClassname);
        }

        if (secondStickyElement.classList.contains(activeClassname)) {
          secondStickyElement.classList.remove(activeClassname);
        }
      } else if (extraElement) {
        return;
      } else {
        if (clone.classList.contains(activeClassname)) {
          clone.classList.remove(activeClassname);
        }

        if (secondStickyElement.classList.contains(activeClassname)) {
          secondStickyElement.classList.remove(activeClassname);
        }
      }
    }

    previousScrollTopValue =
      document.body.scrollTop || document.documentElement.scrollTop;
  };

  if (secondStickyElement) {
    window.addEventListener('scroll', manageVisibilityInBothDirections);
  } else {
    window.addEventListener('scroll', manageVisibility);
  }
};

export default sticky;
