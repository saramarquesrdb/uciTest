const digitalJourney = () => {
  const htmlElements = {
    popups: Array.from(document.querySelectorAll('.popup')),
    icons: Array.from(document.querySelectorAll('.popup__header-close')),
    rememberPass: document.querySelector('.remember-pass'),
    loginForm: document.querySelector('.login.lightbox_content'),
    resetPassForm: document.querySelector('.reset-password'),
    lightboxOverlay: document.querySelector('.lightbox__overlay'),
    lightboxClose: document.querySelector('.lightbox__close'),
    lightboxOpen: document.querySelector('.lightbox__trigger button'),
    submitResetPass: document.querySelector('.button-reset button'),
    submitLogin: document.querySelector('.login-form button'),
    resetPassContainer: document.querySelector('#reset-pass .form-fieldset'),
    sendInfo: document.querySelector('.sendinfo')
  };

  function mobileMenuPopUp() {
    /* Open */
    htmlElements.popups.forEach(popup => {
      popup.addEventListener('click', () => {
        const popWindow = popup.querySelector('.popup__window');
        popup.previousElementSibling.classList.add('active2');
        if (popWindow.classList.contains('closed')) {
          popWindow.classList.remove('closed');
        }
      });
    });

    /* Close */
    htmlElements.icons.forEach(icon => {
      icon.addEventListener('click', function () {
        icon.classList.remove('active2');
        htmlElements.icons.forEach(ele => ele.classList.remove('active2'));
        const popWindow = this.nextElementSibling.querySelector('.popup__window');
        popWindow.classList.add('closed');
      });
    });
  }

  function showResetPassword() {
    htmlElements.rememberPass.addEventListener('click', () => {
      htmlElements.resetPassForm.classList.add('show');
      htmlElements.loginForm.classList.add('hide');
    });
  }

  function openLightbox() {
    htmlElements.lightboxOpen.addEventListener('click', () => {
      if (htmlElements.resetPassForm) {
        htmlElements.resetPassForm.classList.remove('show');
      }
      htmlElements.loginForm.classList.remove('hide');
      htmlElements.sendInfo.classList.remove('show');
      Array.from(document.querySelectorAll('.form-fieldset')).forEach(ele => {
        if (ele.querySelector('input')) {
          ele.querySelector('input').value = '';
        }
        ele.querySelector('.fieldset').classList.remove('active');
        if (ele.classList.contains('valid')) {
          ele.classList.remove('valid');
        }
        if (ele.classList.contains('error')) {
          ele.classList.remove('error');
        }
      });
    });
  }

  // Load Functions if element
  if (document.querySelector('.lightbox')) {
    openLightbox();
  }
  if (document.querySelector('.popup')) {
    mobileMenuPopUp();
  }
  if (document.querySelector('.remember-pass')) {
    showResetPassword();
  }
};

export default digitalJourney;
