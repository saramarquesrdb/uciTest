const userAccessAjax = {
  htmlElements: {
    loginForm: document.getElementById('login-form'),
    loginFormSubmit: document.querySelector('#login-form .form-btn__submit button'),
    loginFormUsername: document.querySelector('#login-form #login-email'),
    loginFormPass: document.querySelector('#login-form #login-password'),
    resetPassForm: document.getElementById('reset-pass'),
    resetPassFormSubmit: document.querySelector('#reset-pass .form-btn__submit button'),
    resetPassInput: document.querySelector('input#reset-pass'),
    changePassForm: document.getElementById('change-pass-form'),
    changePassFormPassInput: document.querySelector('#change-pass-form #insert-pass'),
    changePassFormSubmit: document.querySelector('.form-btn__submit a'),
    sendInfo: document.querySelector('.sendinfo'),
    apiEndpoint: 'https://upload-file.getsandbox.com/users' /* Dummy, Just returns OK */
  },

  loginObj: {
    userName: '',
    pass: ''
  },

  resetPassObj: {
    userName: ''
  },

  changePassObj: {
    userId: 'demo123',
    pass: ''
  },


  sendLogin() {
    // Collect Data
    userAccessAjax.loginObj.userName = userAccessAjax.htmlElements.loginFormUsername.value;
    userAccessAjax.loginObj.pass = userAccessAjax.htmlElements.loginFormPass.value;
    // Send search request
    fetch(userAccessAjax.htmlElements.apiEndpoint, {
      method: 'post',
      headers: {
        'Content-type': 'application/json',
      },
      body: JSON.stringify(userAccessAjax.loginObj),
    })
      .then(response => {
        if (response.status === 200) {
          userAccessAjax.htmlElements.loginForm.submit();
        }
      })
      .catch(error => {
        console.log('Request failed', error);
      });
  },
  resetPass() {
    // Collect Data
    userAccessAjax.resetPassObj.userName = userAccessAjax.htmlElements.resetPassInput.value;

    // Send search request
    fetch(userAccessAjax.htmlElements.apiEndpoint, {
      method: 'post',
      headers: {
        'Content-type': 'application/json',
      },
      body: JSON.stringify(userAccessAjax.resetPassObj),
    })
      .then(response => {
        if (response.status === 200) {
          // userAccessAjax.htmlElements.resetPassForm.submit();
        }
      })
      .catch(error => {
        console.log('Request failed', error);
      });
  },
  changePass(changePassForm) {
    userAccessAjax.htmlElements.changePassFormSubmit.addEventListener('click', e => {
      e.preventDefault();
      // Collect Data
      userAccessAjax.changePassObj.pass = userAccessAjax.htmlElements.changePassFormPassInput.value;

      // Send search request
      fetch(userAccessAjax.htmlElements.apiEndpoint, {
        method: 'post',
        headers: {
          'Content-type': 'application/json',
        },
        body: JSON.stringify(userAccessAjax.changePassObj),
      })
        .then(response => {
          if (response.status === 200) {
            changePassForm.submit();
          }
        })
        .catch(error => {
          console.log('Request failed', error);
        });
    });
  }
};

export default userAccessAjax;
