import docUploads from '@/js/Pages/digitalJourney/customerDocs/docUpload';

const docs = () => {
  const htmlElements = {
    boxesForm: Array.from(document.querySelectorAll('form.box')),
    boxesAllInput: Array.from(document.querySelectorAll('form.box .box__input input')),
    boxesAllLabel: Array.from(document.querySelectorAll('form.box .box__input label')),
    boxesUpload: Array.from(document.querySelectorAll('.box .box__input:not(.box.warning .box__input,.box.default .box__input)'))
  };

  // Prevent click events on completed forms
  htmlElements.boxesUpload.forEach(ele => {
    ele.style.pointerEvents = 'none';
  });

  // add attributes forms
  htmlElements.boxesForm.forEach((ele, index) => {
    ele.setAttribute('id', `10${index + 1}`);
  });

  // add attributes inputs
  htmlElements.boxesAllInput.forEach((ele, index) => {
    ele.setAttribute('data-index', index);
    ele.setAttribute('data-id', `10${index + 1}`);
    ele.setAttribute('id', `file-${index}`);
  });

  // add attributes labels
  htmlElements.boxesAllLabel.forEach((ele, index) => {
    ele.setAttribute('for', `file-${index}`);
  });


  docUploads();
};

export default docs;
