import lib from '@/js/Pages/digitalJourney/customerDocs/lib';
import docListing from '@/js/Pages/digitalJourney/customerDocs/docListing';

const docDelete = (input, form) => {
  form.classList.add('is-deleting');

  // Fill delete object
  lib.deleteObj.dataType = input.getAttribute('data-type');
  lib.deleteObj.dataId = input.getAttribute('data-id');
  lib.deleteObj.deleteDoc = true;

  // Ajax delete doc
  fetch('https://list-documents.getsandbox.com/delete-document', {
    method: 'post',
    headers: {
      'Content-type': 'application/json',
    },
    body: JSON.stringify(lib.deleteObj),
  })
    .then(lib.json)
    .then(data => {
      // console.log('Data sent in post request:', lib.deleteObj);
      // console.log('API delete response:', data);
      docListing();
    })
    .catch(error => {
      // console.error('Fetch error', error);
    });
};

export default docDelete;
