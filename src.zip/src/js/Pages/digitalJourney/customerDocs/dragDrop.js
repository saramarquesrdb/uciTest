import lib from '@/js/Pages/digitalJourney/customerDocs/lib';

const dragDrop = (droppedFiles, form, label, input) => {
  // preventing the unwanted behaviours
  ['drag', 'dragstart', 'dragend', 'dragover', 'dragenter', 'dragleave', 'drop'].forEach(event => {
    form.addEventListener(event, e => {
      e.preventDefault();
      e.stopPropagation();
    });
  });

  // add "is-dragover" class
  ['dragover', 'dragenter'].forEach(event => {
    form.addEventListener(event, () => {
      form.classList.add('is-dragover');
    });
  });

  // remove "is-dragover" class
  ['dragleave', 'dragend', 'drop'].forEach(event => {
    form.addEventListener(event, () => {
      form.classList.remove('is-dragover');
    });
  });

  // Action when files are added to the form
  const showFiles = function (files) {
    form.classList.add('awaiting-validation');
    form.classList.remove('default');
    label.textContent = files.length > 1 ? (input.getAttribute('data-multiple-caption') || '')
      .replace('{count}', files.length) : files[0].name;
    label.classList.add('visibility');

    // Get Data from file to send
    const file = input.files[0];
    const formData = new FormData(form);
    formData.append('dataType', input.getAttribute('data-type'));
    formData.append('dataId', input.getAttribute('data-id'));
    formData.append('file', file);
    // console.log(' --------> Data in form to send (FormData)');
    // [...formData.entries()].forEach(row => {
    //  console.log(row);
    // });
    // console.log('---------> End FormData');
    lib.postObj.formData = formData;
  };

  // Trigger submit event
  const triggerFormSubmit = function () {
    const event = document.createEvent('HTMLEvents');
    event.initEvent('submit', true, false);
    form.dispatchEvent(event);
  };

  // Automatically submit the form on drop file
  form.addEventListener('drop', e => {
    if (form.classList.contains('default')
        || form.classList.contains('warning')
        || form.classList.contains('cancelled')) {
      droppedFiles = e.dataTransfer.files;
      showFiles(droppedFiles);
      triggerFormSubmit();
      form.querySelector('.state').style.display = 'none';
    }
  });

  // Automatically submit the form on file select
  input.addEventListener('change', e => {
    showFiles(e.target.files);
    triggerFormSubmit();
  });
};

export default dragDrop;
