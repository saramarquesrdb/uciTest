import lib from '@/js/Pages/digitalJourney/customerDocs/lib';
import docDelete from '@/js/Pages/digitalJourney/customerDocs/docDelete';
import dragDrop from '@/js/Pages/digitalJourney/customerDocs/dragDrop';

const docUploads = () => {
  (function (document, window, index) {
    // applying the effect for every form
    const forms = document.querySelectorAll('.box');
    Array.prototype.forEach.call(forms, form => {
      const input = form.querySelector('input[type="file"]');
      const label = form.querySelector('.document-name');
      const deleteIcon = form.querySelector('.btn-icon-delete');
      const droppedFiles = false;
      let ajaxPost = true;

      // Set type of post
      if (document.querySelector('form.upload-document-form') || document.querySelector('form.upload-document-form')) {
        ajaxPost = false;
      }
      // Drag & drop
      dragDrop(droppedFiles, form, label, input);

      // Form Submit
      form.addEventListener('submit', e => {
        // preventing the duplicate submissions if the current one is in progress
        if (form.classList.contains('is-uploading')) return false;
        form.classList.add('is-uploading');
        form.classList.remove('is-error');
        e.preventDefault();
        if (!ajaxPost) {
          setInterval(() => {
            form.classList.remove('is-uploading');
            // Success Message
            form.querySelector('.date').style.display = 'none';
            form.querySelector('.msg').style.display = 'block';
            form.querySelector('.btn-icon-delete').style.display = 'block';
            form.querySelector('.btn-icon-download').style.display = 'block';
            form.querySelector('.state').innerHTML = 'Pendiente';
            form.querySelector('.item-upload').classList.add('remove-warning');
          }, 1000);
        } else {
          // Ajax POST doc
          fetch('https://list-documents.getsandbox.com/post-document', {
            method: 'post',
            headers: {
              'Content-type': 'application/json',
            },
            body: JSON.stringify(lib.postObj),
          })
            .then(lib.json)
            .then(data => {
              // console.log('Data sent in post request:', lib.postObj);
              // console.log('Ajax POST doc response:', data);
              setInterval(() => {
                form.classList.remove('is-uploading');

                // Success Message
                form.querySelector('.date').style.display = 'none';
                form.querySelector('.msg').style.display = 'block';
                form.querySelector('.btn-icon-delete').style.display = 'block';
                form.querySelector('.btn-icon-download').style.display = 'block';
                form.querySelector('.state').innerHTML = 'Pendiente';
                form.querySelector('.item-upload').classList.add('remove-warning');
              }, 1000);
            })
            .catch(error => {
              // console.error('Fetch error', error);
            });
        }
      });

      // Get Data to delete
      deleteIcon.addEventListener('click', () => {
        docDelete(input, form);
      });
    });
  }(document, window, 0));
};

export default docUploads;
