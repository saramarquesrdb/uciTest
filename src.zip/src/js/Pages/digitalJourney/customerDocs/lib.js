const lib = {
  // AJAX Check response
  status(response) {
    if (response.status >= 200 && response.status < 300) {
      return Promise.resolve(response);
    }
    return Promise.reject(new Error(response.statusText));
  },

  // AJAX Parse JSON
  json(response) {
    return response.json();
  },

  postObj: {
    formData: ''
  },

  deleteObj: {
    dataType: '',
    dataId: '',
    deleteDoc: false
  }
};

export default lib;
