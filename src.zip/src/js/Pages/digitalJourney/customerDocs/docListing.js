import docUploads from '@/js/Pages/digitalJourney/customerDocs/docUpload';

const docListing = () => {
  const allForms = Array.from(document.querySelectorAll('.document-list-content .document-upload'));

  fetch('https://list-documents.getsandbox.com/list-documents').then(response => response.json()).then(data => {
    if (data) {
      const initialData = (typeDoc, suffix, index) => {
        let itemContainer = '';
        if (typeDoc !== undefined) {
          if (!typeDoc.nameFile) {
            if (typeDoc.nameFile === '') {
              typeDoc.nameFile = typeDoc.placeholderText;
            }
          }
        } else {
          typeDoc = {
            state: '',
          };
        }

        itemContainer = `
                    <div class="drop-file-upload document-upload">
                        <form action="/upload" class="box${` ${typeDoc.state}`}" id="${typeDoc.id}"  name="formBox" novalidate="">
                            <div class="box__input item-upload">
                                <input data-index="${index}" data-id="${typeDoc.id}" data-type="${suffix}" type="file" name="file" id="file-${index}" class="box__file" data-multiple-caption="{count} files selected" multiple="">
                                <label for="file-${index}" class="btn btn-upload">
                                    <p class="input-placeholder">${typeDoc.placeholderText}</p>
                                    <p class="document-name">${typeDoc.nameFile}</p>
                                </label>
                            </div>
                            <div class="item-upload-info">
                                <span class="btn-icon-delete">
                                        <svg class="icon icon-delete">
                                            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/dist/icons/icons.svg#delete"></use>
                                        </svg>
                                </span>
                                <a href="${typeDoc.pathToFile}">
                                  <span class="btn-icon-download">
                                          <svg class="icon
                                              icon-download">
                                              <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/dist/icons/icons.svg#download"></use>
                                          </svg>

                                  </span>
                                </a>

                            </div>
                            <div class="box__deleting">Borrando archivo…</div>
                            <div class="box__uploading">Subiendo archivo…</div>
                            <div class="info">
                                  <span class="size bodycopy-xs">${typeDoc.textEstado}</span>
                                  <span class="date bodycopy-s">Subido por ${typeDoc.userName} el <span>${typeDoc.date}</span> a las <span>${typeDoc.time}</span></span>
                                  <span class="state bodycopy-xs">Estado: ${typeDoc.textEstado}</span>
                              </div>
                        <input type="hidden" name="ajax" value="1"></form>
                    </div>
                    `;
        document.querySelector(`.document-list-content.${suffix}`).innerHTML += itemContainer;
      };

      // Get nominas data
      if (data.nominas) {
        data.nominas.forEach((ele, index) => {
          initialData(data.nominas[index], 'nominas', index);
        });
      }
      // Get DNI data
      if (data.dni) {
        data.dni.forEach((ele, index) => {
          initialData(data.dni[index], 'dni', index);
        });
      }
      // Get Bank Docs data
      if (data.bankDocs) {
        data.bankDocs.forEach((ele, index) => {
          initialData(data.bankDocs[index], 'bank-docs', index);
        });
      }

      // Prevent click events on completed forms
      const htmlElements = {
        boxesInput: Array.from(document.querySelectorAll('.box .box__input:not(.box.warning .box__input,.box.cancelled .box__input,.box.default .box__input)'))
      };
      htmlElements.boxesInput.forEach(ele => {
        ele.style.pointerEvents = 'none';
      });
      docUploads();
    }
  }).catch(err => {
    // console.log(err);
  });
};

export default docListing;
