const changePassword = () => {
  const requiredRegExp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
  const specialCharsRegExp = /(?=.*?[#?!@$%^&*-])/;

  // combined o f two above
  const strongRegExp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z#?!@$%^&*-]{8,}$/;
  const whitespaceRegExp = /^$|\s+/;

  const htmlElements = {
    passwordInsert: document.querySelector('.password.insert'),
    passwordInsertErrorText: document.querySelector('.password.insert .error-message'),
    iconShowInsert: document.querySelector('.password.insert .form-list__show-password'),
    inputInsert: document.querySelector('.password.insert input'),
    iconShowDuplicate: document.querySelector('.password.duplicate .form-list__show-password'),
    passwordDuplicate: document.querySelector('.password.duplicate'),
    inputDuplicate: document.querySelector('.password.duplicate input'),
    strengthMeter: document.querySelector('.change-password_security'),
    submitBtn: document.querySelector('.change-password .form-btn__submit a'),
    textContainer: document.querySelector('.security-text'),
    sendInfo: document.querySelector('.change-password-page .send-info'),
    changePasswordWrapper: document.querySelector('.change-password__wrapper'),
    passEqualContainer: document.querySelector('.pass-equal'),
    passNotSafe: 'Tu contraseña no es segura',
    passSafe: 'Tu contraseña es segura',
    passVerySafe: 'Tu contraseña es muy segura',
    passNotEqual: 'Las contraseñas deben ser iguales',
    passEqual: 'Las contraseñas son iguales',
    noWhiteSpaces: 'La contraseña no pueden tener espacios en blanco'
  };
  function showPassword(showIcon, inputType) {
    showIcon.addEventListener('click', () => {
      showIcon.classList.toggle('show');
      if (showIcon.classList.contains('show')) {
        inputType.type = 'text';
      }
      if (!showIcon.classList.contains('show')) {
        inputType.type = 'password';
      }
    });
  }

  function resetStrengthMeter() {
    htmlElements.strengthMeter.classList.remove('danger', 'warning', 'valid');
  }

  function areEqualAndValid(inputDuplicate, inputInsert, submitBtn) {
    if ((inputDuplicate.value === inputInsert.value)
      && (inputInsert.value.match(requiredRegExp) || inputInsert.value.match(strongRegExp))) {
      // Pass OK, and Equal
      submitBtn.classList.remove('disabled');
      htmlElements.passEqualContainer.innerHTML = htmlElements.passEqual;
      // Pass OK, but are not Equal
    } else if ((inputDuplicate.value !== inputInsert.value)
      && (inputInsert.value.match(requiredRegExp) || inputInsert.value.match(strongRegExp))) {
      htmlElements.passEqualContainer.innerHTML = htmlElements.passNotEqual;
      submitBtn.classList.add('disabled');
    } else {
      submitBtn.classList.add('disabled');
    }
  }

  function checkStrength() {
    htmlElements.inputInsert.oninput = function () {
      htmlElements.inputInsert.value = htmlElements.inputInsert.value.trim();
      areEqualAndValid(htmlElements.inputDuplicate, htmlElements.inputInsert, htmlElements.submitBtn);
      if (htmlElements.inputInsert.value.match(requiredRegExp)) {
        // Valid requirements
        resetStrengthMeter();
        htmlElements.strengthMeter.classList.add('warning');
        htmlElements.textContainer.innerHTML = htmlElements.passSafe;
      } else if (htmlElements.inputInsert.value.match(strongRegExp)) {
        // Strong Pass
        resetStrengthMeter();
        htmlElements.strengthMeter.classList.add('valid');
        htmlElements.textContainer.innerHTML = htmlElements.passVerySafe;
      } else if (htmlElements.inputInsert.value === '') {
        // Pass is empty
        resetStrengthMeter();
      } else {
        // Pass not valid
        resetStrengthMeter();
        htmlElements.strengthMeter.classList.add('danger');
        htmlElements.textContainer.innerHTML = htmlElements.passNotSafe;
      }
      if (htmlElements.inputInsert.value.match(whitespaceRegExp)) {
        htmlElements.textContainer.innerHTML = htmlElements.noWhiteSpaces;
        htmlElements.submitBtn.classList.add('disabled');
      }
    };
  }


  function areEqualAndValidOnSubmit() {
    htmlElements.inputDuplicate.oninput = function () {
      htmlElements.inputDuplicate.value = htmlElements.inputDuplicate.value.trim();
      areEqualAndValid(htmlElements.inputDuplicate, htmlElements.inputInsert, htmlElements.submitBtn);
    };
  }

  function sendInfo() {
    htmlElements.sendInfo.style.display = 'none';
    htmlElements.submitBtn.addEventListener('click', () => {
      htmlElements.sendInfo.style.display = 'block';
      htmlElements.changePasswordWrapper.style.display = 'none';
    });
  }

  showPassword(htmlElements.iconShowInsert, htmlElements.inputInsert);
  showPassword(htmlElements.iconShowDuplicate, htmlElements.inputDuplicate);
  areEqualAndValidOnSubmit();
  checkStrength();
  // sendInfo();
};

export default changePassword;
