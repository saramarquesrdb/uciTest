const digitalJourneyTrackingDemo = () => {
  // Buttons
  const elementSteps = Array.from(document.querySelectorAll('.tracking-steps__head .step'));

  // Contents
  const containerSteps = Array.from(document.querySelectorAll('.tracking-steps__body .content .tracking-steps-detail'));

  // Pointer
  const pointerSteps = Array.from(document.querySelectorAll('.tracking-steps__body .pointer-item'));

  function clearState() {
    elementSteps.forEach(ele => {
      ele.parentElement.classList.remove('clicked');
    });
    containerSteps.forEach(ele => {
      ele.style.display = 'none';
    });
    pointerSteps.forEach(ele => {
      ele.classList.remove('active', 'verify');
    });
  }

  function setState() {
    elementSteps.forEach((ele, index) => {
      if (!ele.parentElement.classList.contains('disabled')) {
        ele.parentElement.addEventListener('click', () => {
          clearState();
          ele.parentElement.classList.add('clicked');
          ele.closest('.tracking-steps').querySelector(`.tracking-steps__body .content .tracking-steps-detail:nth-child(${index + 1})`).style.display = 'flex';
          ele.closest('.tracking-steps').querySelector(`.tracking-steps__body .pointer-item:nth-child(${index + 1})`).classList.add('active');
        });
      }
    });
  }

  function init() {
    setState(elementSteps);
  }

  init();
};

export default digitalJourneyTrackingDemo;
