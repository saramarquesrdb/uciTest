Variantes: Disabled, Error, BG Transparent, BG AccentLight, Hidden, With lightbox.
Permite configurar id del campo, id, title y value del input, for para el label e id para el date