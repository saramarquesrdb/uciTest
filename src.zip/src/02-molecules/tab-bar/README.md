<h1>Notes: Tab bar</h1>
<p>Tab more items: </p>
<p>The hidden layer with the 4th and other items is activated with the "drawer--open" class at the level of the "drawer--modal" class.</p>
<p>Example:<br/>- Hidden: class="drawer drawer--modal"></br>- Show: class="drawer drawer--modal drawer--open">