Se incluyen estilos concreto para el uso de html sin clases para el blog de hipotecas en las variantes:
<ul>
<li>- wysiwyg-block--without-class</li>
<li>- wysiwyg-block--without-class-hipotecas</li>
<ul>
<p>&nbsp;</p>
<h2>Título h2</h2>
<h3>subTítulo h3</h3>
<p>¿Te estás planteando vender o <a href="#">alquilar tu casa</a>? Para que puedas obtener la mayor rentabilidad</p>
