// This is the global JS file that will be accessible from any component

/*
Dependencies to make work ES6 JS features (Async/Await)
import 'core-js/stable';
import 'regenerator-runtime/runtime';
*/


// Services
import { DatalayerService } from '@/js/services/datalayer.service';
import { GoalsService } from '@/js/services/goals.service';
import { StickyService } from '@/js/services/sticky.service';
import { UrlService } from '@/js/services/url.service';
import { AlertService } from '@/js/services/alert.service';

// Common
import changeH1ToH2 from '@/js/Helpers/changeH1toH2Blog';
import '../js/Common/lazyload';
import '../js/Common/slider';
import djForm from '@/js/Forms/djForm/djForm';
import tooltips from '@/js/Common/tooltips';
import callMeF from '@/js/Common/callMe';
import anchor from '../js/Common/anchor';
import activeIfVisible from '../js/Common/activeIfVisible';
import showMore from '../js/Common/showMore';
import overflowOpacity from '../js/Common/overflowOpacity';
import tabs from '../js/Common/tabs';
import AccessSelect from '../js/Common/AccessSelect';
import imageCarrousel from '../js/Common/ImageCarrousel';
import rangeSlider from '../js/Common/rangeSlider';
import inputLabel from '../js/Common/inputLabel';
import valueBannerRangeSlider from '../js/Common/valueBannerRangeSlider';
import lockTwoRangeSliders from '../js/Common/lockTwoRangeSliders';
import lightbox from '../js/Common/lightbox';
import simplebarInit from '../js/Common/simplebarInit';
import nameInputValueInTitle from '../js/Common/nameInputValueInTitle';
import forms from '../js/Common/forms';
import accordion from '../js/Common/accordion';
import singleAccordion from '../js/Common/singleAccordion';
import dropdown from '../js/Common/dropdown';
import popup from '../js/Common/popup';
import moveLast from '../js/Common/moveLast';
import '../js/Common/scrollUp';
import '../js/Common/steps-forms';
import '../js/Common/forms/prequalifierForm';
import '../js/Common/forms/calculatorform';
import '../js/Common/forms/calculatorform-max-finance';
import stepsNav from '../js/Common/steps-nav';
import initPagination from '../js/Common/pagination';
import initSitecoreForms from '../js/Forms/sitecore-forms/init';
import landingUrl from '../js/Common/landingUrl';
// ucipt
import '../js/Common/ucipt-slider';
import '../js/Common/headerFixed';

// Module specific
import { Header } from '@/js/Modules/header/header';
import glossarySearch from '../js/Modules/glossary/glossarySearch';
import postHeadlineStickyActive from '../js/Modules/postHeadline/stickyActive';
import postHeadlineScrollIndicator from '../js/Modules/postHeadline/scrollIndicator';
import mobileMenuOpenHide from '../js/Modules/mobileMenu/openHide';
import mobileMenuOpenHideFixed from '../js/Modules/mobileMenu/openHideFixed';
import changePassword from '../js/Pages/digitalJourney/changePassword';
import pendingDocuments from '../js/Modules/pendingDocuments/pendingDocuments';
import docs from '../js/Pages/digitalJourney/customerDocs/docs';
import digitalJourneyTrackingDemo from '../js/Pages/digitalJourney/digital-journey-tracking-demo';
import digitalJourney from '../js/Pages/digitalJourney/digital-journey';
import sticky from '../js/Common/sticky';
import journeySliderStickyActive from '../js/Modules/journeySlider/stickyActive';
import resourcesCenter from '../js/Modules/resourcesCenter/resourcesCenter';
import subsidyFinder from '../js/Modules/subsidyFinder/subsidy-finder';
import stickyBetter from "@/js/Common/stickyBetter";
import initLightboxes from '@/js/Modules/lightbox-new/init';
import initRecaptcha from '../js/Modules/recaptcha/recaptcha';
import initPostsGrid from '@/js/Modules/blog/postsGrid/init';
import progressBar from '../js/Modules/progressBar/progressBar';
import initMenuTab from '@/js/Modules/menuTab/init';
import initShareApa from '@/js/Modules/share-apa/init';
import initSidebarContentTable from '@/js/Modules/sidebarContentTable/init';
import initTabs from '@/js/Modules/tabs/init';

// Initialize debug mode
(function () {
  const hostname = window.location.hostname;
  if (/^(int|qa|cm)\./.test(hostname) || /\.local$/.test(hostname)) {
    window.debug = 1;
  } else {
    window.debug = 0;
  }
})();

// Initialize Services
window.datalayerService = new DatalayerService();
window.goalsService = new GoalsService();
window.stickyService = new StickyService();
window.alertService = new AlertService();

UrlService.combineAndPersistQueryStrings();

window.header = new Header();

// Check if the device supports touch events
if (window.matchMedia('(hover: none)').matches) {
  document.body.classList.add('touch-device');
}

if (document.querySelector('.call-me')) {
  callMeF();
}

// subsidyFinder (on top to load before forms)
const subsidyFinderElement = document.querySelector('.subsidy-finder');
if (subsidyFinderElement?.dataset?.goals) {
  subsidyFinder(subsidyFinderElement);
}

if (document.querySelector('.tooltip')) {
  tooltips();
}

if (document.getElementById('digitalJourneyApplicationForm')) {
  djForm();
}

if (document.getElementsByClassName('graph-pending').length > 0) {
  pendingDocuments();
}

if (document.getElementsByClassName('progress-bar-documents').length > 0) {
  progressBar();
}

if (document.querySelector('.digital-journey_header') || document.querySelector('.digital-journey_lightbox')) {
  digitalJourney();
}

if (document.querySelector('.tracking-steps')) {
  digitalJourneyTrackingDemo();
}

if (document.querySelector('.change-password')) {
  changePassword();
}

if (document.querySelector('.document-list')) {
  docs();
}
if (document.querySelector('.steps-nav')) {
  stepsNav();
}
// Change Tabs on hover in the Access Report
tabs(
  'access-report__nav-radio',
  'access-report__nav-input',
  'access-report__nav-label',
  'report',
  'visible',
  true
);

// Change opacity of a nav label, if an element is cut off in the Access Report
overflowOpacity('.access-report__nav', '.access-report__nav-label', 60);

// An accordion for the F.A.Q.
accordion('accordion', 'accordion__trigger', 'accordion__item-content');

// Subsidy Accordion
accordion('accordion-subsidy', 'accordion__trigger-subsidy', 'accordion__item-content-subsidy');

// An accordion for the new F.A.Q component composed by 3 types of accordions
accordion('faqs-component__stacker-categoriesBox-categoriesList-categoryAccordion',
  'faqs-component__stacker-categoriesBox-categoriesList-categoryAccordion__trigger',
  'faqs-component__stacker-categoriesBox-categoriesList-categoryAccordion__item-content');

accordion('faqs-component__display-subCategoryBox-accordionList-singleAccordion',
  'faqs-component__display-subCategoryBox-accordionList-singleAccordion-trigger',
  'faqs-component__display-subCategoryBox-accordionList-singleAccordion-item-content');

/* accordion('faqs-component__stacker-dropdown',
  'faqs-component__stacker-dropdown-trigger',
  'faqs-component__stacker-dropdown-item-content'); */

// A single accordion for the UCI PT Advantages.
singleAccordion('singleAccordion', 'singleAccordion__trigger', 'singleAccordion__item-content');

// Sticky blocks
const tileHighlightSticky = document.querySelector('.tile-highlight_sticky');
const productButtons = document.querySelector('.product-buttons');
const iconsNav = document.querySelector('.icons-nav');
const blogCategories = document.querySelector('.blog-categories');
const postHeadline = document.querySelector('.post-headline__head');
const stickyHeader = document.querySelector('.header');
const stickyHeaderButton = document.querySelector('.header__cta-btn.sticky');
const stickyHeaderButtonScroll = document.querySelector('.header__cta-btn.sticky.sticky-clone');
const headerBodyMainOverlay = document.querySelector(
  '.header__body-main-overlay'
);
const stickyHeaderFixed = document.querySelector('.header-fixed');
const stickyHeaderFixedButton = document.querySelector('.header-fixed__cta-btn.sticky');
const headerFixedBodyMainOverlay = document.querySelector(
  '.header-fixed__body-main-overlay'
);
const mobileMenuActive = 'mobile-menu-is-open';
const journeySliderSticky = document.querySelector('.journey-slider');
const faqsComponent = document.querySelector('.faqs-component__stacker');

if (tileHighlightSticky) {
  sticky(tileHighlightSticky);
}

if (productButtons) {
  sticky(productButtons);
}

if (iconsNav) {
  sticky(iconsNav);
}

if (blogCategories) {
  sticky(blogCategories);
}

if (journeySliderSticky) {
  sticky(journeySliderSticky);

  // A sticky behaviour with active state control for the Post headline module
  journeySliderStickyActive();
}

if (postHeadline) {
  sticky(postHeadline);

  // A sticky behaviour with active state control for the Post headline module
  postHeadlineStickyActive();

  // Scroll indicator (reading progress bar)
  postHeadlineScrollIndicator();

  // Fix Double H1 Blog
  changeH1ToH2();
}

// if (faqsComponent) {
// console.log('it gets on app js');
// sticky(faqsComponent);
// A sticky behaviour with active state control for the FAQs Component module
// faqsStackerStickyActive();
// }

if (
  stickyHeaderButton &&
  stickyHeader &&
  !tileHighlightSticky &&
  !productButtons &&
  !iconsNav &&
  !blogCategories &&
  !postHeadline
) {
  sticky(
    stickyHeaderButton,
    0,
    stickyHeader,
    headerBodyMainOverlay,
    mobileMenuActive,
    stickyHeaderButtonScroll
  );
}

if (
  stickyHeaderFixedButton &&
  stickyHeaderFixed &&
  !tileHighlightSticky &&
  !productButtons &&
  !iconsNav &&
  !blogCategories &&
  !postHeadline
) {
  sticky(
    stickyHeaderFixedButton,
    0,
    stickyHeaderFixed,
    headerFixedBodyMainOverlay,
    mobileMenuActive
  );
}



// Move legal text at last splitter
moveLast('interest-rates__legal-splitter', 'splitter', 'active', 'wrapper');

// Move splitter to the end
moveLast('scroll-up-splitter', 'splitter', 'active', 'wrapper');

// Product buttons anchor to Products
anchor('product-button__link', 'easeInQuad');

// Icon button anchor to icons nav
anchor('icon-button__link', 'easeInQuad');

// Go-top and btn to anchor
// anchor('btn', 'easeInQuad');
anchor('go-top', 'easeInQuad');

// Active legal text gotop only if legal visisble
activeIfVisible('interest-rates__legal', '.go-top');

// Active gotop at the end of the page
activeIfVisible('scroll-up', '.go-top');

// Product buttons change their active state depending on which Product is visible on the screen
activeIfVisible('product', '.sticky-clone .product-button__link');

// Icons nav change their active state depending on which icon is visible on the screen
// activeIfVisible('icon', '.sticky-clone .icon-button__link');

// Change opacity of a product button, if an element is cut off in the sticky bar
overflowOpacity(
  '.product-buttons.sticky-clone',
  '.sticky-clone .product-button',
  0
);

// Change opacity of a icon nav, if an element is cut off in the sticky bar
overflowOpacity(
  '.icons-nav.sticky-clone',
  '.sticky-clone .icons-nav',
  0
);

// Show more button for items in a Glossary list
showMore('glossary-list', 'glossary-list__item', '.glossary-list__link .link');

// Show more button for items in a Access Product component
showMore('access-product__products', 'access-product__products__item', '.products-list__link .link_more');

// Show more button for items in a Cards Grid component
showMore('cards-grid__cards--more', 'cards-grid__cards__item', '.cards-list__link .link_more');

// Show more button for items in a Latest component
showMore('latest__cards', 'latest__cards__item', '.latest__link .link_more');

// Show more button for items in a Dedicated Links component
showMore('dedicated-links__list', 'dedicated-links__item', '.dedicated-links__bottom-link .link_more');

// Change opacity of a letter, if an element is cut off in the Alpha menu
overflowOpacity('.alpha-menu__list', '.alpha-menu__label', 12.5);

// Change Tabs in the Glossary
tabs(
  'alpha-menu__radio',
  'alpha-menu__input',
  'alpha-menu__label',
  'glossary-list',
  'visible',
  false,
  'letter'
);

// Activate glossary search with a set of custom rules
glossarySearch();

// Change opacity of a category, if an element is cut off in the Blog categories
overflowOpacity('.col > .blog-categories', '.blog-categories__item', -1);
overflowOpacity(
  '.blog-categories.sticky-clone',
  '.sticky-clone .blog-categories__item',
  -1
);

// Change opacity of a tag, if an element is cut off in the Tags links
overflowOpacity('.tags-links__list', '.tags-links__item', -1);

// Accessible common select
AccessSelect();

imageCarrousel();

// A label moving behaviour on focus and, if an input is not empty
inputLabel();

// Range sliders in forms
rangeSlider(
  '#ageRangeSlider .range-slider__slider',
  '#ageRangeSlider .range-slider__input'
);
rangeSlider(
  '#netRangeSlider .range-slider__slider',
  '#netRangeSlider .range-slider__input',
);
rangeSlider(
  '#secondHolderNetRangeSlider .range-slider__slider',
  '#secondHolderNetRangeSlider .range-slider__input'
);
rangeSlider(
  '#paymentsNumberRangeSlider .range-slider__slider',
  '#paymentsNumberRangeSlider .range-slider__input'
);
rangeSlider(
  '#secondHolderPaymentsNumberRangeSlider .range-slider__slider',
  '#secondHolderPaymentsNumberRangeSlider .range-slider__input'
);
rangeSlider(
  '#otherLoansRangeSlider .range-slider__slider',
  '#otherLoansRangeSlider .range-slider__input'
);
rangeSlider(
  '#moneyRequestRangeSlider .range-slider__slider',
  '#moneyRequestRangeSlider .range-slider__input'
);
rangeSlider(
  '#MortgageHousePriceRangeSlider .range-slider__slider',
  '#MortgageHousePriceRangeSlider .range-slider__input',
  500
);
rangeSlider(
  '#MortgageHousePriceRangeSliderCalculator .range-slider__slider',
  '#MortgageHousePriceRangeSliderCalculator .range-slider__input',
  100
);
rangeSlider(
  '#MortgageHouseSavingsRangeSlider .range-slider__slider',
  '#MortgageHouseSavingsRangeSlider .range-slider__input',
  500
);
rangeSlider(
  '#MortgageHouseSavingsRangeSliderCalculator .range-slider__slider',
  '#MortgageHouseSavingsRangeSliderCalculator .range-slider__input',
  100
);
rangeSlider(
  '#MortgageHouseDurationRangeSlider .range-slider__slider',
  '#MortgageHouseDurationRangeSlider .range-slider__input'
);
rangeSlider(
  '#MortgageAmountRangeSlider .range-slider__slider',
  '#MortgageAmountRangeSlider .range-slider__input'
);
rangeSlider(
  '#TINRangeSlider .range-slider__slider',
  '#TINRangeSlider .range-slider__input',
  1
);

// Value banners at the Simulator results page
valueBannerRangeSlider('#fixedFinancing .value-banner__chosen-value');
valueBannerRangeSlider(
  '#housePrice .value-banner__chosen-value',
  '#housePrice .value-banner__slider',
);
valueBannerRangeSlider(
  '#clientInput .value-banner__chosen-value',
  '#clientInput .value-banner__slider',
);

// Range sliders locking at the Simulator results page
lockTwoRangeSliders(
  '#housePrice .value-banner__slider',
  '#housePrice .value-banner__chosen-value',
  '#clientInput .value-banner__slider',
  '#clientInput .value-banner__chosen-value'
);

// Title update, based on the name input value at the Application form page
nameInputValueInTitle();

// Visibility conditions, nested fields rules, numbers' masks and validation rules for form fields
forms();

// Open/close a lightbox
lightbox();

// Simplebar
simplebarInit();

// Mobile menu open/hide behaviour
mobileMenuOpenHide();
mobileMenuOpenHideFixed();

// Mobile menu accordion
accordion(
  'header__body-main-content',
  'header__body-main-link_trigger',
  'header__body-main-submenu',
  '(max-width: 1023px)'
);

accordion(
  'header-fixed__body-main-content',
  'header-fixed__body-main-link_trigger',
  'header-fixed__body-main-submenu',
  '(max-width: 1023px)'
);

// Desktop menu dropdowns
dropdown(
  '.header__body-main-menu .header__body-main-link_trigger',
  '.header__body-main-btn',
  '.header__body-main-menu .header__body-main-submenu',
  '.header',
  '(min-width: 1024px)',
  [
    document.querySelector('.header'),
    document.querySelector('.header__body'),
    document.querySelector('body'),
  ]
);

dropdown(
  '.header-fixed__body-main-menu .header-fixed__body-main-link_trigger',
  '.header-fixed__body-main-btn',
  '.header-fixed__body-main-menu .header-fixed__body-main-submenu',
  '.header-fixed',
  '(min-width: 1024px)',
  [
    document.querySelector('.header-fixed'),
    document.querySelector('.header-fixed__body'),
    document.querySelector('body'),
  ]
);

// Common popups
popup();

// Resources Center
const resourcesCenterElement = document.querySelector('.resources-center-wrapper');
if (resourcesCenterElement) {
  resourcesCenter(resourcesCenterElement);
}

// Setup saved values for forms fields
window.addEventListener('load', () => {
  document.querySelectorAll('.fieldset input').forEach(x => {
    if (x.value && !x.parentElement.classList.contains('active')) {
      x.parentElement.classList.add('active');
    }
  });
});

// Canonical urls for blog pagination
if (document.querySelector('.blog-pagination')) {
  document.querySelector("link[rel='canonical']").setAttribute('href', window.location.href);
}

// Load Sticky Better
if (document.querySelector('.header__cta-btn')) {
  stickyBetter(document.querySelector('.header__head-wrapper'), document.querySelector('.header__cta-btn.sticky'))
}

initLightboxes()

// init components navigation
initPagination()

// init user url tracking
landingUrl()

//init recaptchas
initRecaptcha()

// init sitecore forms
initSitecoreForms()

// init blog's posts grid
initPostsGrid()

// init menu tab
initMenuTab()

//init share-apa
initShareApa()

//init sidebar content table
initSidebarContentTable()

//init tabs
initTabs()
