Variantes: Default, Sticky false, Has subtitle.
Se puede configurar el href de cada social.