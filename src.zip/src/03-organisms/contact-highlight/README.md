Variantes: Default, Opening, Under Header, Image visible in all views, Accent BG, Accent Dark BG, Reversed, Without tooltip labels, Wide.
Se puede configurar el src de la imagen.
<ul>
    <li>Por defecto el título es un H2. Puede situarse en cualquier parte de la página excepto abriéndola. Tiene una variable a nivel de átomo que permite que sea "accent dark", "accent", "dark" o "light" si así se necesita.</li>
    <li>La variante "Opening" pinta el título como H1 y se usa cuando el componente abre la página (para abrir páginas con Header Reduced). También cambia la posición del cuadro con respecto a la imagen en la parte superior para que no sobresalga.</li>
    <li>La variante "Under Header" incluye la variante Opening de forma que el título también es H1 e incluye un margen superior para separar el componente del Header en caso de utilizarse debajo de este.</li>
    <li>La variante "isVisibleAllViews" hace visible la imagen en todas las resoluciones. Por defecto a partir de 1023 hacia abajo desaparece.</li>
    <li>Tiene variante "reversed" como en otros componentes Highlight.</li>
    <li>Tiene variante "isWide" para hacer el cuadro más ancho.</li>
    <li>Tiene variante "form-without-tooltip-label" para ocultar los Tooltip Labels del formulario.</li>
    <li>Tiene variante "Accent BG" para cambiar el color de fondo a Accent y "Accent Dark BG" para cambiarlo a Accent Dark.</li>
</ul>

