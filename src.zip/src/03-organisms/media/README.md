Variantes: Default, Blog, Video, Accent Light, Cover in mobile, Cover in mobile accent light.
Pueden configurarse la url de la imágen y del vídeo.