Variantes: Default, With white bg
Permite definir id y value a cada input de la navegación, hacer visible o no cada label y configurar su id también