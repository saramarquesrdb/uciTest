Variantes: Default, Check.
Permite configurar id del form general, y para el form list.