Variantes: Default, Accent, Blog, with Google Translate, without ctas, only logo, logo and popups list, logo, popups list and header body, landing header, tramitación header, New header Accent Design System.
***** Se añade una variante fractal que no se debe integrar, para visualizar el header en fractal ****
En el menú mobile permite configurar el texto y enlace de los idiomas

***** Nueva variane Header Accent del sisterma de diseño. No se elimina la antigua header Accent a la espera de la integración de la nueva cabecera.

