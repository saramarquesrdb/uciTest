Variantes: Default, Alert, Gastos, Asterisk and Link Cuota
Permite configurar id, title, name y value de campo e id de label de gastos y de cuota, clases extra para la cuota