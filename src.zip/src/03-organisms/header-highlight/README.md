Variantes: Default, Hipotecas featured, Resersed, Without a button, Accent Dark Box, Small Padding Box, Home UCIPt
Permite configurar src y alt de la imagen