Variantes: Default, No button, For FAQ details, Reversed
Se puede configurar el data-bg. El number y label sobre la imagen son opcionales.