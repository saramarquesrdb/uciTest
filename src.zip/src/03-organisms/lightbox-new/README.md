Variantes: Default, Medium box, Small box, Modal empty, Modal media video, Modal legals, Modal resources form, Modal result form, Modal success.
Permite configurar el id de la modal y dentro del div.modal-container se cargan los componentes para cada uso específico.


* The code is explained here but the values are passed in a more easy way by the JSON properties, check them out in the JSON component samples.
* The link to the modal and the modal are independent.

--------------------------

###### Code block to link modal:

```
<a href='#' class='modal-toggle' data-modal='modalOne'>Link to 'modalOne'</a>
```

- Works adding a class 'modal-toggle' and the attribute 'data-modal' with th ID of the modal window you want to call.

--------------------------

###### Code block modal content

```
<div class="lightbox-new modalOne-container">
    <div id="modalOne" class="modal">...</div>
</div>
```

- The top wrapper div needs the 'lightbox-new' class to load the component.
- The next div needs the ID with the unique name of the modal (in this sample 'modalOne') and the class 'modal'.

