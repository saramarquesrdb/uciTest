Variantes: Default, One element, Only two elements

