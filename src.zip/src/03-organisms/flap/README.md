Variantes: Sticky, Dark, White, Grey, Accent, With Link, With Button, With Title (h3), With Title (h2), With bodycopy, With icon in title, With img before title, Alert

