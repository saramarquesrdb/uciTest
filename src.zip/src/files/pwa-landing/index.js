const addBtn = document.querySelector('#install-landing');
const pwaInstalledTitle = document.querySelector('#pwa-app-installed-title');
const pwaNotInstalledTitle = document.querySelector('#pwa-app-not-installed-title');
const pwaNotInstalledSubTitle = document.querySelector('#pwa-app-not-installed-subtitle');

if (addBtn) {

  // Register service worker to control making site work offline
  const pathSw = '/dist/files/pwa-landing/sw.js'
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker
      .register(pathSw)
      .then(() => { console.log('Service Worker Registered'); });
  }

  addBtn.style.display = 'none';
  pwaNotInstalledTitle.style.display = 'none';
  pwaNotInstalledSubTitle.style.display = 'none';

  // Save Model.Web and Model.Landing to localStorage
  let qrImageUrl;
  const qrImage = document.getElementById('share-qr-apa');
  if (qrImage) {
    qrImageUrl = qrImage.src;
  }
  const landingUrl = document.getElementById('share-apa-link').href;

  const currentUrl = window.location.href;
  const match = currentUrl.match(/APA@(\d+)/);
  const code = match ? match[1] : null;

  if (qrImageUrl) {
    let qrKey = 'qrApaImageUrl' + code
    localStorage.setItem(qrKey, qrImageUrl);
    console.log("Added QR value:");
  }
  if (landingUrl) {
    let landingKey = 'landingApaUrl' + code
    localStorage.setItem(landingKey, landingUrl);
    console.log("Added landing value:");
  }

  // Load values from localStorage
  const storedQrImageUrl = localStorage.getItem('qrApaImageUrl' + code);
  const storedLandingUrl = localStorage.getItem('landingApaUrl' + code);

  console.log("QR value:");
  console.log(storedQrImageUrl);

  console.log("Landing value:");
  console.log(storedLandingUrl);

  if (storedQrImageUrl) {
    document.getElementById('share-qr-apa').src = storedQrImageUrl;
  }
  if (storedLandingUrl) {
    document.getElementById('whatsapp-qr-share').href = `https://wa.me/?text=${encodeURIComponent(storedLandingUrl)}`;
    document.getElementById('share-apa-link').href = storedLandingUrl;
  }


  // Code to handle install prompt on desktop
  let deferredPrompt;
  window.addEventListener('beforeinstallprompt', (e) => {
    // Prevent Chrome 67 and earlier from automatically showing the prompt
    e.preventDefault();
    // Stash the event so it can be triggered later.
    deferredPrompt = e;
    // Update UI to notify the user they can add to home screen
    addBtn.style.display = 'block';
    pwaNotInstalledTitle.style.display = 'block';
    pwaNotInstalledSubTitle.style.display = 'block';
    pwaInstalledTitle.style.display = 'none';

    addBtn.addEventListener('click', () => {
      // hide our user interface that shows our A2HS button
      addBtn.style.display = 'none';
      // Show the prompt
      deferredPrompt.prompt();
      // Wait for the user to respond to the prompt
      deferredPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the A2HS prompt');
        } else {
          console.log('User dismissed the A2HS prompt');
        }
        deferredPrompt = null;
      });
    });
  });
}

