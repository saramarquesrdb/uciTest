const CACHE_NAME = 'my-cache-v1';
const urlsToCache = [
  '/',
  '/dist/files/pwa-landing/index.js',
  '/dist/css/master.min.css',
  '/dist/scripts/app.bundle.js',
  '/dist/scripts/manifest.bundle.js',
  '/dist/scripts/vendor.bundle.js'
  // Add more files as needed
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Opened cache');
      return cache.addAll(urlsToCache);
    })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
